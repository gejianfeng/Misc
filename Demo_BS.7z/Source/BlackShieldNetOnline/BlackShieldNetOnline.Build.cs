// Fill out your copyright notice in the Description page of Project Settings.

using UnrealBuildTool;
using System.Collections.Generic;

namespace UnrealBuildTool.Rules
{
    public class BlackShieldNetOnline : ModuleRules
    {
        public BlackShieldNetOnline(TargetInfo Target)
        {
            PublicIncludePaths.AddRange(
                new string[] {
                "BlackShieldNetOnline/Public",
                });

            PrivateIncludePaths.Add("BlackShieldNetOnline/Private");

            PrivateDependencyModuleNames.AddRange(
                new string[] {
                "Core",
                "CoreUObject",
                "Engine",
                "Sockets",
                "Json",
                "JsonUtilities",
                "OnlineSubSystemUtils",
                }
                );

            PublicDependencyModuleNames.AddRange(new string[] {  "InputCore" });
        }
    }
}
