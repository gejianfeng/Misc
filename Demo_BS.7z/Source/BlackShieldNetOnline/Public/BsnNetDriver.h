
#pragma once

#include "IpNetDriver.h"
#include "BsnNetDriver.generated.h"

class FBSNOnline;
class UMsgBody;

UCLASS(config=Game)
class BLACKSHIELDNETONLINE_API UBsnNetDriver : public UNetDriver
{
	GENERATED_UCLASS_BODY()
public:
	virtual class ISocketSubsystem* GetSocketSubsystem() override;
	virtual bool IsAvailable() const override;
	virtual bool InitBase(bool bInitAsClient, FNetworkNotify* InNotify, const FURL& URL, bool bReuseAddressAndPort, FString& Error) override;
	virtual bool InitConnect(FNetworkNotify* InNotify, const FURL& ConnectURL, FString& Error) override;
	virtual void Shutdown() override;
	virtual bool IsNetResourceValid() override;
	virtual FSocket * CreateSocket();
	void SendMsg(const TCHAR *InMessageType, UMsgBody *Message);
	FSocket *GetBsnSocket() { return BsnSocket; }
	void Startup(FBSNOnline *InOnline);
	void SendJson(TSharedPtr<FJsonObject> JsonMsg);
protected:
	void SendJson(const FString &InJson);
	void DefaultTimer();
public:
	UPROPERTY(config)
	FString ServerName;
	UPROPERTY(config)
	FString	GameType;
	UPROPERTY(config)
	FString Host;
	UPROPERTY(config)
	uint16  Port;
protected:
	FSocket *BsnSocket;
	TSharedPtr<FInternetAddr> RemoteAddr;
	int32	MaxPortCountToTry;
	class FBsnJsonPacketReciver *JsonPacketReciver;
	FTimerHandle	TimerHandle_RecivePacket;
	FBSNOnline		*Online;
};

