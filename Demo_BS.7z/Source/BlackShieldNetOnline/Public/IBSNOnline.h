
#pragma once

#include "BsnDefs.h"
#include "JsonUtil.h"

#define BSNONLINE_MODULE_NAME "BSNONLINE"

DECLARE_MULTICAST_DELEGATE_TwoParams(FOnlineMessageDelegate, class UMsgBody **, uint32)

class IBNSOnline : public IModuleInterface
{
public:
	static inline IBNSOnline& Get()
	{
		return FModuleManager::LoadModuleChecked<IBNSOnline>("BlackShieldNetOnline");
	}
	virtual bool Init() = 0;
	virtual void UnInit() = 0;
	virtual bool Startup(UWorld *MyWorld) = 0;
	virtual void Shutdown() = 0;
	virtual UWorld *GetWorld() = 0;
	virtual bool RegisterMsgType(const FString &InName, UClass *InMessageClass, bool bArray = false) = 0;
	virtual FOnlineMessageDelegate &GetOnlineDelegate(const FString &InMessageName) = 0;
};

namespace Online
{
	extern void SendJson(TSharedPtr<FJsonObject> JsonMsg);

	template<class T0>
	void SendMsg(const FString &InName, const FString &InKey, const T0 &InValue)
	{
		TSharedPtr<FJsonObject> JsonMsg = MakeShareable(new FJsonObject);
		JsonSetFieldTrait<FString>(JsonMsg, MSG_NAME, InName);

		TSharedPtr<FJsonObject> JsonBody = MakeShareable(new FJsonObject);
		JsonSetFieldTrait<TSharedPtr<FJsonObject>>(JsonMsg, MSG_BODY, JsonBody);

		JsonSetFieldTrait<T0>(JsonBody, InKey, InValue);
		
		SendJson(JsonMsg);
	}

	template<class T0, class T1>
	void SendMsg(const FString &InName, const FString &InKey0, const T0 &InValue0, const FString &InKey1, const T1 &InValue1)
	{
		TSharedPtr<FJsonObject> JsonMsg = MakeShareable(new FJsonObject);
		JsonSetFieldTrait<FString>(JsonMsg, MSG_NAME, InName);

		TSharedPtr<FJsonObject> JsonBody = MakeShareable(new FJsonObject);
		JsonSetFieldTrait<TSharedPtr<FJsonObject>>(JsonMsg, MSG_BODY, JsonBody);

		JsonSetFieldTrait<T0>(JsonBody, InKey0, InValue0);
		JsonSetFieldTrait<T1>(JsonBody, InKey1, InValue1);

		SendJson(JsonMsg);
	}

	template<class T0, class T1, class T2>
	void SendMsg(const FString &InName, const FString &InKey0, const T0 &InValue0, const FString &InKey1, const T1 &InValue1, const FString &InKey2, const T2 &InValue2)
	{
		TSharedPtr<FJsonObject> JsonMsg = MakeShareable(new FJsonObject);
		JsonSetFieldTrait<FString>(JsonMsg, MSG_NAME, InName);

		TSharedPtr<FJsonObject> JsonBody = MakeShareable(new FJsonObject);
		JsonSetFieldTrait<TSharedPtr<FJsonObject>>(JsonMsg, MSG_BODY, JsonBody);

		JsonSetFieldTrait<T0>(JsonBody, InKey0, InValue0);
		JsonSetFieldTrait<T1>(JsonBody, InKey1, InValue1);
		JsonSetFieldTrait<T2>(JsonBody, InKey2, InValue2);

		SendJson(JsonMsg);
	}

	template<class T0, class T1, class T2, class T3>
	void SendMsg(const FString &InName, const FString &InKey0, const T0 &InValue0, const FString &InKey1, const T1 &InValue1, const FString &InKey2, const T2 &InValue2, const FString &InKey3, const T3 &InValue3)
	{
		TSharedPtr<FJsonObject> JsonMsg = MakeShareable(new FJsonObject);
		JsonSetFieldTrait<FString>(JsonMsg, MSG_NAME, InName);
		
		TSharedPtr<FJsonObject> JsonBody = MakeShareable(new FJsonObject);
		JsonSetFieldTrait<TSharedPtr<FJsonObject>>(JsonMsg, MSG_BODY, JsonBody);

		JsonSetFieldTrait<T0>(JsonBody, InKey0, InValue0);
		JsonSetFieldTrait<T1>(JsonBody, InKey1, InValue1);
		JsonSetFieldTrait<T2>(JsonBody, InKey2, InValue2);
		JsonSetFieldTrait<T3>(JsonBody, InKey3, InValue3);

		SendJson(JsonMsg);
	}

	template<class T0, class T1, class T2, class T3, class T4>
	void SendMsg(const FString &InName, const FString &InKey0, const T0 &InValue0, const FString &InKey1, const T1 &InValue1, const FString &InKey2, const T2 &InValue2, const FString &InKey3, const T3 &InValue3, const FString &InKey4, const T4 &InValue4)
	{
		TSharedPtr<FJsonObject> JsonMsg = MakeShareable(new FJsonObject);
		JsonSetFieldTrait<FString>(JsonMsg, MSG_NAME, InName);

		TSharedPtr<FJsonObject> JsonBody = MakeShareable(new FJsonObject);
		JsonSetFieldTrait<TSharedPtr<FJsonObject>>(JsonMsg, MSG_BODY, JsonBody);

		JsonSetFieldTrait<T0>(JsonBody, InKey0, InValue0);
		JsonSetFieldTrait<T1>(JsonBody, InKey1, InValue1);
		JsonSetFieldTrait<T2>(JsonBody, InKey2, InValue2);
		JsonSetFieldTrait<T3>(JsonBody, InKey3, InValue3);
		JsonSetFieldTrait<T4>(JsonBody, InKey4, InValue4);
		
		SendJson(JsonMsg);
	}

	template<class T0, class T1, class T2, class T3, class T4, class T5>
	void SendMsg(const FString &InName, const FString &InKey0, const T0 &InValue0, const FString &InKey1, const T1 &InValue1, const FString &InKey2, const T2 &InValue2, const FString &InKey3, const T3 &InValue3, const FString &InKey4, const T4 &InValue4, const FString &InKey5, const T5 &InValue5)
	{
		TSharedPtr<FJsonObject> JsonMsg = MakeShareable(new FJsonObject);
		JsonSetFieldTrait<FString>(JsonMsg, MSG_NAME, InName);

		TSharedPtr<FJsonObject> JsonBody = MakeShareable(new FJsonObject);
		JsonSetFieldTrait<TSharedPtr<FJsonObject>>(JsonMsg, MSG_BODY, JsonBody);

		JsonSetFieldTrait<T0>(JsonBody, InKey0, InValue0);
		JsonSetFieldTrait<T1>(JsonBody, InKey1, InValue1);
		JsonSetFieldTrait<T2>(JsonBody, InKey2, InValue2);
		JsonSetFieldTrait<T3>(JsonBody, InKey3, InValue3);
		JsonSetFieldTrait<T4>(JsonBody, InKey4, InValue4);
		JsonSetFieldTrait<T5>(JsonBody, InKey5, InValue5);

		SendJson(JsonMsg);
	}

	template<class T0, class T1, class T2, class T3, class T4, class T5, class T6>
	void SendMsg(const FString &InName, const FString &InKey0, const T0 &InValue0, const FString &InKey1, const T1 &InValue1, const FString &InKey2, const T2 &InValue2, const FString &InKey3, const T3 &InValue3, const FString &InKey4, const T4 &InValue4, const FString &InKey5, const T5 &InValue5, const FString &InKey6, const T6 &InValue6)
	{
		TSharedPtr<FJsonObject> JsonMsg = MakeShareable(new FJsonObject);
		JsonSetFieldTrait<FString>(JsonMsg, MSG_NAME, InName);

		TSharedPtr<FJsonObject> JsonBody = MakeShareable(new FJsonObject);
		JsonSetFieldTrait<TSharedPtr<FJsonObject>>(JsonMsg, MSG_BODY, JsonBody);

		JsonSetFieldTrait<T0>(JsonBody, InKey0, InValue0);
		JsonSetFieldTrait<T1>(JsonBody, InKey1, InValue1);
		JsonSetFieldTrait<T2>(JsonBody, InKey2, InValue2);
		JsonSetFieldTrait<T3>(JsonBody, InKey3, InValue3);
		JsonSetFieldTrait<T4>(JsonBody, InKey4, InValue4);
		JsonSetFieldTrait<T5>(JsonBody, InKey5, InValue5);
		JsonSetFieldTrait<T6>(JsonBody, InKey6, InValue6);

		SendJson(JsonMsg);
	}

	template<class T0, class T1, class T2, class T3, class T4, class T5, class T6, class T7>
	void SendMsg(const FString &InName, const FString &InKey0, const T0 &InValue0, const FString &InKey1, const T1 &InValue1, const FString &InKey2, const T2 &InValue2, const FString &InKey3, const T3 &InValue3, const FString &InKey4, const T4 &InValue4, const FString &InKey5, const T5 &InValue5, const FString &InKey6, const T6 &InValue6, const FString &InKey7, const T7 &InValue7)
	{
		TSharedPtr<FJsonObject> JsonMsg = MakeShareable(new FJsonObject);
		JsonSetFieldTrait<FString>(JsonMsg, MSG_NAME, InName);

		TSharedPtr<FJsonObject> JsonBody = MakeShareable(new FJsonObject);
		JsonSetFieldTrait<TSharedPtr<FJsonObject>>(JsonMsg, MSG_BODY, JsonBody);

		JsonSetFieldTrait<T0>(JsonBody, InKey0, InValue0);
		JsonSetFieldTrait<T1>(JsonBody, InKey1, InValue1);
		JsonSetFieldTrait<T2>(JsonBody, InKey2, InValue2);
		JsonSetFieldTrait<T3>(JsonBody, InKey3, InValue3);
		JsonSetFieldTrait<T4>(JsonBody, InKey4, InValue4);
		JsonSetFieldTrait<T5>(JsonBody, InKey5, InValue5);
		JsonSetFieldTrait<T6>(JsonBody, InKey6, InValue6);
		JsonSetFieldTrait<T7>(JsonBody, InKey7, InValue7);

		SendJson(JsonMsg);
	}

	template<class T0, class T1, class T2, class T3, class T4, class T5, class T6, class T7, class T8>
	void SendMsg(const FString &InName, const FString &InKey0, const T0 &InValue0, const FString &InKey1, const T1 &InValue1, const FString &InKey2, const T2 &InValue2, const FString &InKey3, const T3 &InValue3, const FString &InKey4, const T4 &InValue4, const FString &InKey5, const T5 &InValue5, const FString &InKey6, const T6 &InValue6, const FString &InKey7, const T7 &InValue7, const FString &InKey8, const T8 &InValue8)
	{
		TSharedPtr<FJsonObject> JsonMsg = MakeShareable(new FJsonObject);
		JsonSetFieldTrait<FString>(JsonMsg, MSG_NAME, InName);

		TSharedPtr<FJsonObject> JsonBody = MakeShareable(new FJsonObject);
		JsonSetFieldTrait<TSharedPtr<FJsonObject>>(JsonMsg, MSG_BODY, JsonBody);

		JsonSetFieldTrait<T0>(JsonBody, InKey0, InValue0);
		JsonSetFieldTrait<T1>(JsonBody, InKey1, InValue1);
		JsonSetFieldTrait<T2>(JsonBody, InKey2, InValue2);
		JsonSetFieldTrait<T3>(JsonBody, InKey3, InValue3);
		JsonSetFieldTrait<T4>(JsonBody, InKey4, InValue4);
		JsonSetFieldTrait<T5>(JsonBody, InKey5, InValue5);
		JsonSetFieldTrait<T6>(JsonBody, InKey6, InValue6);
		JsonSetFieldTrait<T7>(JsonBody, InKey7, InValue7);
		JsonSetFieldTrait<T8>(JsonBody, InKey8, InValue8);

		SendJson(JsonMsg);
	}

	template<class T0, class T1, class T2, class T3, class T4, class T5, class T6, class T7, class T8, class T9>
	void SendMsg(const FString &InName, const FString &InKey0, const T0 &InValue0, const FString &InKey1, const T1 &InValue1, const FString &InKey2, const T2 &InValue2, const FString &InKey3, const T3 &InValue3, const FString &InKey4, const T4 &InValue4, const FString &InKey5, const T5 &InValue5, const FString &InKey6, const T6 &InValue6, const FString &InKey7, const T7 &InValue7, const FString &InKey8, const T8 &InValue8, const FString &InKey9, const T9 &InValue9)
	{
		TSharedPtr<FJsonObject> JsonMsg = MakeShareable(new FJsonObject);
		JsonSetFieldTrait<FString>(JsonMsg, MSG_NAME, InName);

		TSharedPtr<FJsonObject> JsonBody = MakeShareable(new FJsonObject);
		JsonSetFieldTrait<TSharedPtr<FJsonObject>>(JsonMsg, MSG_BODY, JsonBody);

		JsonSetFieldTrait<T0>(JsonBody, InKey0, InValue0);
		JsonSetFieldTrait<T1>(JsonBody, InKey1, InValue1);
		JsonSetFieldTrait<T2>(JsonBody, InKey2, InValue2);
		JsonSetFieldTrait<T3>(JsonBody, InKey3, InValue3);
		JsonSetFieldTrait<T4>(JsonBody, InKey4, InValue4);
		JsonSetFieldTrait<T5>(JsonBody, InKey5, InValue5);
		JsonSetFieldTrait<T6>(JsonBody, InKey6, InValue6);
		JsonSetFieldTrait<T7>(JsonBody, InKey7, InValue7);
		JsonSetFieldTrait<T8>(JsonBody, InKey8, InValue8);
		JsonSetFieldTrait<T9>(JsonBody, InKey9, InValue9);

		SendJson(JsonMsg);
	}

	template<class T0, class T1, class T2, class T3, class T4, class T5, class T6, class T7, class T8, class T9, class T10>
	void SendMsg(const FString &InName, const FString &InKey0, const T0 &InValue0, const FString &InKey1, const T1 &InValue1, const FString &InKey2, const T2 &InValue2, const FString &InKey3, const T3 &InValue3, const FString &InKey4, const T4 &InValue4, const FString &InKey5, const T5 &InValue5, const FString &InKey6, const T6 &InValue6, const FString &InKey7, const T7 &InValue7, const FString &InKey8, const T8 &InValue8, const FString &InKey9, const T9 &InValue9, const FString &InKey10, const T10 &InValue10)
	{
		TSharedPtr<FJsonObject> JsonMsg = MakeShareable(new FJsonObject);
		JsonSetFieldTrait<FString>(JsonMsg, MSG_NAME, InName);

		TSharedPtr<FJsonObject> JsonBody = MakeShareable(new FJsonObject);
		JsonSetFieldTrait<TSharedPtr<FJsonObject>>(JsonMsg, MSG_BODY, JsonBody);

		JsonSetFieldTrait<T0>(JsonBody, InKey0, InValue0);
		JsonSetFieldTrait<T1>(JsonBody, InKey1, InValue1);
		JsonSetFieldTrait<T2>(JsonBody, InKey2, InValue2);
		JsonSetFieldTrait<T3>(JsonBody, InKey3, InValue3);
		JsonSetFieldTrait<T4>(JsonBody, InKey4, InValue4);
		JsonSetFieldTrait<T5>(JsonBody, InKey5, InValue5);
		JsonSetFieldTrait<T6>(JsonBody, InKey6, InValue6);
		JsonSetFieldTrait<T7>(JsonBody, InKey7, InValue7);
		JsonSetFieldTrait<T8>(JsonBody, InKey8, InValue8);
		JsonSetFieldTrait<T9>(JsonBody, InKey9, InValue9);
		JsonSetFieldTrait<T10>(JsonBody, InKey10, InValue10);

		SendJson(JsonMsg);
	}
}


