
#pragma once

#include "BsnDefs.generated.h"

struct FMsgHeader
{
	FMsgHeader()
		:PacketLen(0)
		,ProtoType(2)
		,HeadLen(0)
		,Header(nullptr)
		,Body(nullptr)
	{
	}
	uint16 PacketLen;
	uint16 ProtoType;
	uint16 HeadLen;
	uint8 *Header;
	uint8 *Body;
};

UCLASS()
class UMsgBody :public UObject
{
	GENERATED_BODY()
public:
	UMsgBody() { Entry = NULL; }
	struct FMessageEntry *Entry;
};

UCLASS()
class UServerInfo :public UMsgBody
{
	GENERATED_BODY()
public:
	UPROPERTY()
	FString ServerName;
	UPROPERTY()
	FString GameType;
	UPROPERTY()
	FString Host;
	UPROPERTY()
	uint16	Port;
	UPROPERTY()
	FString MapName;
};

#define  MSG_NAME TEXT("name")
#define  MSG_BODY TEXT("content")

