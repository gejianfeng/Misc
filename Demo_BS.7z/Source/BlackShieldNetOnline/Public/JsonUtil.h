
#pragma once

#include "JsonObject.h"

template<class T>
struct JsonSetFieldTrait
{
	JsonSetFieldTrait(TSharedPtr<FJsonObject> Json, const FString &InKey, const T &Value) {}
};

template<> struct JsonSetFieldTrait<FString>
{
	JsonSetFieldTrait(TSharedPtr<FJsonObject> Json, const FString &InKey, const FString &Value)
	{
		TSharedPtr<FJsonValueString> StrValue = MakeShareable(new FJsonValueString(Value));
		Json->SetField(InKey, StrValue);
	}
};

template<> struct JsonSetFieldTrait<bool>
{
	JsonSetFieldTrait(TSharedPtr<FJsonObject> Json, const FString &InKey, const bool &Value)
	{
		TSharedPtr<FJsonValueBoolean> BoolValue = MakeShareable(new FJsonValueBoolean(Value));
		Json->SetField(InKey, BoolValue);
	}
};

template<> struct JsonSetFieldTrait<double>
{
	JsonSetFieldTrait(TSharedPtr<FJsonObject> Json, const FString &InKey, const double &Value)
	{
		TSharedPtr<FJsonValueNumber> DoubleValue = MakeShareable(new FJsonValueNumber(Value));
		Json->SetField(InKey, DoubleValue);
	}
};

template<> struct JsonSetFieldTrait<uint16>
{
	JsonSetFieldTrait(TSharedPtr<FJsonObject> Json, const FString &InKey, const uint16 &Value)
	{
		TSharedPtr<FJsonValueNumber> Uint16Value = MakeShareable(new FJsonValueNumber(Value));
		Json->SetField(InKey, Uint16Value);
	}
};

template<> struct JsonSetFieldTrait<uint32>
{
	JsonSetFieldTrait(TSharedPtr<FJsonObject> Json, const FString &InKey, const uint32 &Value)
	{
		TSharedPtr<FJsonValueNumber> Uint32Value = MakeShareable(new FJsonValueNumber(Value));
		Json->SetField(InKey, Uint32Value);
	}
};

template<> struct JsonSetFieldTrait<float>
{
	JsonSetFieldTrait(TSharedPtr<FJsonObject> Json, const FString &InKey, const float &Value)
	{
		TSharedPtr<FJsonValueNumber> FloatValue = MakeShareable(new FJsonValueNumber(Value));
		Json->SetField(InKey, FloatValue);
	}
};

template<> struct JsonSetFieldTrait<int32>
{
	JsonSetFieldTrait(TSharedPtr<FJsonObject> Json, const FString &InKey, const int32 &Value)
	{
		TSharedPtr<FJsonValueNumber> Int32Value = MakeShareable(new FJsonValueNumber(Value));
		Json->SetField(InKey, Int32Value);
	}
};

template<> struct JsonSetFieldTrait< TSharedPtr<FJsonObject> >
{
	JsonSetFieldTrait(TSharedPtr<FJsonObject> Json, const FString &InKey, const TSharedPtr<FJsonObject> &Value)
	{
		TSharedPtr<FJsonValueObject> ObjValue = MakeShareable(new FJsonValueObject(Value));
		Json->SetField(InKey, ObjValue);
	}
};


