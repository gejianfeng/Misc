
#include "BlackShieldNetNativeOnlinePrivatePCH.h"
#include "Serialization/JsonReader.h"
#include "Serialization/JsonWriter.h"
#include "JsonObjectConverter.h"
#include "BSNOnline.h"
#include "BsnDefs.h"
#include "BsnNetDriver.h"
#include "Sockets.h"
#include "SocketSubsystem.h"

bool FBSNOnline::Init()
{
	if (bInit)
	{
		return true;
	}

	UBsnNetDriver *DefaultDriver = UBsnNetDriver::StaticClass()->GetDefaultObject<UBsnNetDriver>();
	if (DefaultDriver != NULL)
	{
		NetURL.Host = DefaultDriver->Host;
		NetURL.Port = DefaultDriver->Port;
	}

	ISocketSubsystem* SocketSubsystem = ISocketSubsystem::Get();
	TSharedRef<FInternetAddr> Addr = SocketSubsystem->CreateInternetAddr(0, 0);
	
	int32 AttemptCount = 0;
	ESocketErrors ErrorCode = SE_NO_ERROR;
	do
	{
		const ANSICHAR *HostName = TCHAR_TO_ANSI(*DefaultDriver->Host);
		ESocketErrors ErrorCode = SocketSubsystem->GetHostByName(HostName, *Addr);
		if (ErrorCode != SE_NO_ERROR)
		{
			if (ErrorCode == SE_HOST_NOT_FOUND || ErrorCode == SE_NO_DATA || ErrorCode == SE_ETIMEDOUT)
			{
				// Force a failure
				AttemptCount = 3;
			}
		}
		AttemptCount++;
	} while (ErrorCode != SE_NO_ERROR && AttemptCount < 3);
	
	if (ErrorCode != SE_NO_ERROR)
	{
		return false;
	}

	NetURL.Host = Addr->ToString(false);

	SynchMessage = new FCriticalSection();
	bInit = true;

	return true;
}

bool FBSNOnline::Startup(UWorld *MyWorld)
{
	if (bInit)
	{
		World = MyWorld;

		if (!Driver.IsValid())
		{
			Driver = Cast<UBsnNetDriver>(GEngine->CreateNetDriver(MyWorld, BSNONLINE_MODULE_NAME));
		}

		if (!Driver.IsValid())
		{
			return false;
		}

		FString Error;
		if (!Driver->InitConnect(this, NetURL, Error))
		{
			return false;
		}

		Driver->Startup(this);

		RegisterMsgType(TEXT("Server"), UServerInfo::StaticClass(), false);

		if (!IsRunningDedicatedServer())
		{
			Online::SendMsg<FString, FString, uint16, FString>(TEXT("Server"),
				TEXT("GameType"), Driver->GameType,
				TEXT("Host"), Driver->Host,
				TEXT("Port"), Driver->Port,
				TEXT("ServerName"), Driver->ServerName);
		}
		else
		{

		}

		return true;
	}

	return false;
}

void FBSNOnline::Shutdown()
{
	if (Driver.IsValid())
	{
		Driver->Shutdown();
		GEngine->DestroyNamedNetDriver(World.Get(), BSNONLINE_MODULE_NAME);
	}
	World = NULL;
}

void FBSNOnline::UnInit()
{
	if (SynchMessage != nullptr)
	{
		delete SynchMessage;
		SynchMessage = nullptr;
	}
}

bool FBSNOnline::RegisterMsgType(const FString &InName, UClass *InMessageClass, bool bArray/*= false*/)
{
	if (MessageTypes.Find(InName) != NULL)
	{
		return false;
	}

	MessageTypes.Add(InName, FMessageEntry(InMessageClass, bArray));

	return true;
}

void FBSNOnline::ReciveMessage(const FString &Name, TSharedRef<FJsonObject> JsonMessage)
{
	FMessageEntry *pMessageEntry = MessageTypes.Find(Name);
	if (pMessageEntry != NULL)
	{
		UMsgBody *NewMsg = NewObject<UMsgBody>(GetTransientPackage(), pMessageEntry->MessageClass);
		if (NewMsg != NULL)
		{
			if (!FJsonObjectConverter::JsonObjectToUStruct(JsonMessage, pMessageEntry->MessageClass, NewMsg, 0, 0))
			{
				return;
			}

			{
				NewMsg->Entry = pMessageEntry;
				FScopeLock Lock(SynchMessage);
				Messages.Add(NewMsg);
				ArrayMsgCount.Add(1);
			}
		}
	}
}

void FBSNOnline::DispatchMessage()
{
	if ( Messages.Num() > 0)
	{
		TArray<UMsgBody *> SaveMessages;
		TArray<uint32>	   SaveMsgArrayCount;

		//Swap message for process
		{
			FScopeLock Lock(SynchMessage);
			SaveMessages = Messages;
			SaveMsgArrayCount = ArrayMsgCount;
			Messages.Empty();
			ArrayMsgCount.Empty();
		}

		//process message
		UMsgBody **ppMsg = SaveMessages.GetData();
		for (int32 i = 0; i < SaveMsgArrayCount.Num(); ++i)
		{
			uint32 arrayNum = SaveMsgArrayCount[i];
			UMsgBody *pMsg = ppMsg[0];
			FMessageEntry *Entry = pMsg->Entry;
			FOnlineMessageDelegate &Delegate = Entry->MultiDelegate;
			if (Delegate.IsBound())
			{
				Delegate.Broadcast(ppMsg, arrayNum);
			}
			ppMsg += arrayNum;
		}
	}
}

FOnlineMessageDelegate &FBSNOnline::GetOnlineDelegate(const FString &InMessageName)
{
	FMessageEntry *pMessageEntry = MessageTypes.Find(InMessageName);
	check(pMessageEntry != NULL);
	return pMessageEntry->MultiDelegate;
}

void FBSNOnline::AddReferencedObjects(FReferenceCollector& Collector)
{
	Collector.AddReferencedObjects(Messages);
}

IMPLEMENT_MODULE(FBSNOnline, BlackShieldNetOnline)

