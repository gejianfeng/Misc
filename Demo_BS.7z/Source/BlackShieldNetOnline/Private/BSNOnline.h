
#pragma once

#include "IBSNOnline.h"

struct FMessageEntry
{
	FMessageEntry(UClass *InClass, bool bInArray)
		:MessageClass(InClass)
		,bArray(bInArray)
	{
	}
	bool	bArray;
	UClass *MessageClass;
	FOnlineMessageDelegate MultiDelegate;
};

class UBsnNetDriver;
class FBSNOnline : public IBNSOnline, public FNetworkNotify, FGCObject
{
public:
	FBSNOnline() { bInit = false; SynchMessage = NULL; }
	virtual void StartupModule() override { }
	virtual void ShutdownModule() override { }
	virtual bool Init();
	virtual void UnInit();
	virtual bool Startup(UWorld *MyWorld);
	virtual void Shutdown();
	virtual EAcceptConnection::Type NotifyAcceptingConnection(){return EAcceptConnection::Accept;}
	virtual void NotifyAcceptedConnection(class UNetConnection* Connection){}
	virtual bool NotifyAcceptingChannel(class UChannel* Channel){ return false; }
	virtual void NotifyControlMessage(UNetConnection* Connection, uint8 MessageType, class FInBunch& Bunch){ }
	virtual UWorld *GetWorld(){ return World.Get(); }
	virtual void ReciveMessage(const FString &Name, TSharedRef<FJsonObject> JsonMessage);
	virtual void AddReferencedObjects(FReferenceCollector& Collector);
	virtual FOnlineMessageDelegate &GetOnlineDelegate(const FString &InMessageName);
	virtual void DispatchMessage();
	virtual bool RegisterMsgType(const FString &InName, UClass *InMessageClass, bool bArray = false);
	UBsnNetDriver *GetDriver() { return Driver.Get();  }
protected:
	bool bInit;
	TMap<FString, FMessageEntry>		MessageTypes;
	TWeakObjectPtr<UWorld>				World;
	TWeakObjectPtr<UBsnNetDriver>		Driver;
	UPROPERTY()
	TArray<class UMsgBody*>				Messages;
	TArray<uint32>						ArrayMsgCount;
	FCriticalSection				    *SynchMessage;
	FURL								NetURL;
};

