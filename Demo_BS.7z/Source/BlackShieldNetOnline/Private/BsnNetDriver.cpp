
#include "BlackShieldNetNativeOnlinePrivatePCH.h"
#include "BsnNetDriver.h"
#include "SocketSubsystem.h"
#include "IPAddress.h"
#include "Sockets.h"
#include "BSNOnline.h"
#include "BsnDefs.h"
#include "JsonObjectConverter.h"
#include "IpConnection.h"
#include <string>

/*	
	|len|type|-------Json Content-------------
	|-2-|--2-|-------bodylen(len-head_len)------------------
*/

class FBsnJsonPacketReciver :FRunnable
{
public:
	
	static const int32  recv_buff_len = 4096;
	static const uint32 const_head_len = 4;
	static const uint16 const_proto_type = 1;

	FBsnJsonPacketReciver(ISocketSubsystem *InSocketSubSystem, FSocket *InSocket, FBSNOnline *InOnline)
		: Socket(InSocket)
		, SocketSubSystem(InSocketSubSystem)
		, packet_len(0)
		, proto_type(0)
		, body_buff(nullptr)
		, body_len(0)
		, bPacketReading(false)
		, Online(InOnline)
		, bRequestExit(false)
	{
		int32 rec_len = 0;
		Socket->SetReceiveBufferSize(recv_buff_len, rec_len);
		Thread = FRunnableThread::Create(this, TEXT("FBsnJsonPacketReceiver"), 8 * 1024, TPri_AboveNormal);
	}

	~FBsnJsonPacketReciver()
	{
		if (Thread != NULL)
		{
			bRequestExit = true;
			Thread->Kill(true);
			delete Thread;
		}
	}

	virtual bool Init()
	{
		return true;
	}

	virtual uint32 Run()
	{
		while (!bRequestExit)
		{	
			int32  buffer_read = 0;
			TSharedRef<FInternetAddr> SourceAddr = SocketSubSystem->CreateInternetAddr();
			if (Socket->RecvFrom(recv_buff, recv_buff_len, buffer_read, SourceAddr.Get()))
			{
				ReadData(recv_buff, buffer_read);
			}
			else
			{
				Sleep(1);
			}
		}
		return 0;
	}

	void ReadData(uint8 *recv_buff, uint32 buffer_read)
	{
		if (CacheHead.Num() > 0) //ƴ�Ӳ������İ�ͷ
		{
			if (buffer_read + CacheHead.Num() > const_head_len)
			{
				uint32 n = const_head_len - CacheHead.Num();
				CacheHead.Append(recv_buff, n);
				BuildHeader(CacheHead.GetData(), const_head_len, packet_len, proto_type);
				body_buff = recv_buff + n;
				body_len = buffer_read - n;
				bPacketReading = true;
				CacheHead.Empty();
			}
			else
			{
				CacheHead.Append(recv_buff, buffer_read);
			}
		}
		else
		{
			if (!bPacketReading)
			{
				if (buffer_read >= const_head_len)
				{
					BuildHeader(recv_buff, buffer_read, packet_len, proto_type);
					body_len = buffer_read - const_head_len;
					if (body_len > 0)
					{
						body_buff = recv_buff + const_head_len;
					}
					bPacketReading = true;
				}
				else
				{
					check(CacheHead.Num());
					CacheHead.Append(recv_buff, buffer_read);
				}
			}
			else
			{
				body_buff = recv_buff;
				body_len = buffer_read;
			}
		}

		if (bPacketReading && body_buff != nullptr)
		{
			uint32 bodylen_need = packet_len - const_head_len;

			if (bodylen_need >= body_len + Cache.Num())
			{
				uint32 appnum = bodylen_need - Cache.Num();
				Cache.Append(body_buff, appnum);
				BuildJsonMessage();
				Cache.Empty();

				uint32 left_len = body_len - appnum;
				if (left_len > 0)
				{
					ReadData(body_buff + appnum, left_len);
				}
				else
				{
					bPacketReading = false;
				}
			}
			else
			{
				Cache.Append(body_buff, body_len);
			}
		}
	}

	inline void BuildJsonMessage()
	{
		TSharedPtr<FJsonObject> JsonMsg;
		FBufferReader Ar(Cache.GetData(), Cache.Num(), false);
		TSharedRef<TJsonReader<char> > JsonReader = TJsonReaderFactory<char>::Create(&Ar);
		if (!FJsonSerializer::Deserialize(JsonReader, JsonMsg) || !JsonMsg.IsValid())
		{
			return;
		}

		const TSharedPtr<FJsonValue> NameType = JsonMsg->GetField<EJson::String>(MSG_NAME);
		if (!NameType.IsValid())
		{
			return;
		}

		const TSharedPtr<FJsonValue> Body = JsonMsg->GetField<EJson::Object>(MSG_BODY);
		if (!Body.IsValid())
		{
			return;
		}
		
		if (Online != NULL)
		{
			Online->ReciveMessage(NameType->AsString(), Body->AsObject().ToSharedRef());
		}
	}

	inline void BuildHeader(uint8 *recv_buff, uint32 len, uint16 &packet_len, uint16 &proto_type)
	{
		check(len >= const_head_len);
		FBufferReader Ar(recv_buff, len, false);
		Ar.SetByteSwapping(PLATFORM_LITTLE_ENDIAN);
		Ar << packet_len;
		Ar << proto_type;
	}

	virtual void Stop() { }
	virtual void Exit() { }

protected:
	TArray<uint8>	 Cache;
	TArray<uint8>	 CacheHead;
	ISocketSubsystem *SocketSubSystem;
	FSocket			 *Socket;
	int32			 MarkCount;
	uint8			 recv_buff[recv_buff_len];
	FRunnableThread	 *Thread;
	uint16			packet_len;
	uint16			proto_type;
	uint8			*body_buff;
	uint32			body_len;
	bool			bPacketReading;
	bool			bRequestExit;
	FBSNOnline		*Online;
};

UBsnNetDriver::UBsnNetDriver(const FObjectInitializer &ObjectInitializer)
	:Super(ObjectInitializer)
	,MaxPortCountToTry(5)
	,JsonPacketReciver(nullptr)
	,Online(nullptr)
{
}

bool UBsnNetDriver::IsAvailable() const
{
	return true;
}

ISocketSubsystem* UBsnNetDriver::GetSocketSubsystem()
{
	return ISocketSubsystem::Get(PLATFORM_SOCKETSUBSYSTEM);
}

FSocket *UBsnNetDriver::CreateSocket()
{
	ISocketSubsystem* SocketSubsystem = GetSocketSubsystem();
	if (SocketSubsystem == NULL)
	{
		UE_LOG(LogNet, Warning, TEXT("UBsnNetDriver::CreateSocket: Unable to find socket subsystem"));
		return NULL;
	}
	return SocketSubsystem->CreateSocket(NAME_Stream, TEXT("BsnOnline"));
}

bool UBsnNetDriver::InitConnect(FNetworkNotify* InNotify, const FURL& ConnectURL, FString& Error)
{
	if (!InitBase(true, InNotify, ConnectURL, false, Error))
	{
		UE_LOG(LogNet, Warning, TEXT("Failed to init net driver ConnectURL: %s: %s"), *ConnectURL.ToString(), *Error);
		return false;
	}
	return true;
}

bool UBsnNetDriver::InitBase(bool bInitAsClient, FNetworkNotify* InNotify, const FURL& URL, bool bReuseAddressAndPort, FString& Error)
{
	NetConnectionClassName = UIpConnection::StaticClass()->GetPathName();

	if (!Super::InitBase(bInitAsClient, InNotify, URL, bReuseAddressAndPort, Error))
	{
		return false;
	}

	ISocketSubsystem* SocketSubsystem = GetSocketSubsystem();
	if (SocketSubsystem == NULL)
	{
		UE_LOG(LogNet, Warning, TEXT("Unable to find socket subsystem"));
		return false;
	}

	BsnSocket = CreateSocket();
	if (BsnSocket == NULL)
	{
		Error = FString::Printf(TEXT("WinSock: socket failed (%i)"), (int32)SocketSubsystem->GetLastErrorCode());
		return false;
	}

	if (BsnSocket->SetReuseAddr(bReuseAddressAndPort) == false)
	{
		UE_LOG(LogNet, Log, TEXT("setsockopt with SO_REUSEADDR failed"));
	}

	if (BsnSocket->SetRecvErr() == false)
	{
		UE_LOG(LogNet, Log, TEXT("setsockopt with IP_RECVERR failed"));
	}

	int send_buff_len = 4096;
	BsnSocket->SetSendBufferSize(send_buff_len, send_buff_len);

	if (BsnSocket->SetNonBlocking() == false)
	{
		Error = FString::Printf(TEXT("%s: SetNonBlocking failed (%i)"), SocketSubsystem->GetSocketAPIName(),
			(int32)SocketSubsystem->GetLastErrorCode());
		return false;
	}
	
	RemoteAddr = SocketSubsystem->CreateInternetAddr();
	
	bool bValide = false;
	RemoteAddr->SetIp(*URL.Host,bValide);
	RemoteAddr->SetPort(URL.Port);

	if (!BsnSocket->Connect(*RemoteAddr.Get()))
	{
		return false;
	}

	return true;
}

void UBsnNetDriver::Startup(FBSNOnline *InOnline)
{
	if (BsnSocket!=NULL)
	{
		Online = InOnline;

		ISocketSubsystem* SocketSubsystem = GetSocketSubsystem();
		JsonPacketReciver = new FBsnJsonPacketReciver(SocketSubsystem, BsnSocket, Online);

		UWorld *MyWorld = GetWorld();
		if (MyWorld != NULL)
		{
			MyWorld->GetTimerManager().SetTimer(TimerHandle_RecivePacket,
				this, &UBsnNetDriver::DefaultTimer,
				MyWorld->GetWorldSettings()->GetEffectiveTimeDilation(),
				true);
		}
	}
}

void UBsnNetDriver::DefaultTimer()
{
	if (Online != NULL)
	{
		Online->DispatchMessage();
	}
}

void UBsnNetDriver::Shutdown()
{
	UWorld *MyWorld = GetWorld();
	if (MyWorld != nullptr)
	{
		MyWorld->GetTimerManager().ClearTimer(TimerHandle_RecivePacket);
	}

	if (JsonPacketReciver)
	{
		delete JsonPacketReciver;
		JsonPacketReciver = nullptr;
	}

	Super::Shutdown();
}

void UBsnNetDriver::SendJson(const FString &InJson)
{
	if (BsnSocket != NULL)
	{
		int32 Bytes = InJson.Len();
		int32 BytesSend = 0;
		std::string AnsiJson = TCHAR_TO_ANSI(*InJson);

		TArray<uint8> Data;
		Data.SetNum(AnsiJson.length() + FBsnJsonPacketReciver::const_head_len);
		FMemory::Memcpy(Data.GetData() + FBsnJsonPacketReciver::const_head_len, AnsiJson.c_str(), AnsiJson.length());

		FBufferWriter Ar(Data.GetData(), Data.Num(), false);

		uint16 packet_size = Data.Num();
		uint16 proto_type = FBsnJsonPacketReciver::const_proto_type;
		
#if PLATFORM_LITTLE_ENDIAN
		packet_size = BYTESWAP_ORDER16(packet_size);
		proto_type = BYTESWAP_ORDER16(proto_type);
#endif

		Ar << packet_size;
		Ar << proto_type;
		
		BsnSocket->Send(Data.GetData(), Data.Num(), BytesSend);
	}
}

void UBsnNetDriver::SendJson(TSharedPtr<FJsonObject> JsonMsg)
{
	FString ContentString;

	TSharedRef<TJsonWriter<TCHAR, TPrettyJsonPrintPolicy<TCHAR>> > JsonWriter = TJsonWriterFactory<TCHAR, TPrettyJsonPrintPolicy<TCHAR> >::Create(&ContentString, 0);
	FJsonSerializer::Serialize(JsonMsg.ToSharedRef(), JsonWriter);
	JsonWriter->Close();

	SendJson(ContentString);
}

void UBsnNetDriver::SendMsg(const TCHAR *InMessageType, UMsgBody *Message)
{
	TSharedRef<FJsonObject>  JsonMsg = MakeShareable(new FJsonObject());
	TSharedRef<FJsonObject>  JsonObject = MakeShareable(new FJsonObject());
	if (FJsonObjectConverter::UStructToJsonObject(UServerInfo::StaticClass(), Message, JsonObject, 0, 0))
	{
		TSharedRef<FJsonValueString> JsonName = MakeShareable(new FJsonValueString(InMessageType));
		TSharedRef<FJsonValueObject> JsonContent = MakeShareable(new FJsonValueObject(JsonObject));
		JsonMsg->SetField(MSG_NAME,JsonName);
		JsonMsg->SetField(MSG_BODY, JsonContent);

		FString ContentString;
		TSharedRef<TJsonWriter<TCHAR, TPrettyJsonPrintPolicy<TCHAR>> > JsonWriter = TJsonWriterFactory<TCHAR, TPrettyJsonPrintPolicy<TCHAR> >::Create(&ContentString, 0);
		FJsonSerializer::Serialize(JsonMsg, JsonWriter);
		JsonWriter->Close();
		
		SendJson(ContentString);
	}
}

bool UBsnNetDriver::IsNetResourceValid()
{
	return true;
}

namespace Online
{
	void SendJson(TSharedPtr<FJsonObject> JsonMsg)
	{
		FBSNOnline *Online = (FBSNOnline *)(&IBNSOnline::Get());
		UBsnNetDriver *Driver = Online->GetDriver();
		if (Driver != NULL)
		{
			Driver->SendJson(JsonMsg);
		}
	}
}


