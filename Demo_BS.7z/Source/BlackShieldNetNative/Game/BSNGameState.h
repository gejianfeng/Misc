#pragma once

#include "BlackShieldCommons.h"
#include "BSNGameState.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnTimeUpdateDelegate, int32, Time);

USTRUCT(BlueprintType)
struct FScoreBoradItem
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(BlueprintReadOnly)
	FString Name;

	UPROPERTY(BlueprintReadOnly)
	int32  Rank;

	UPROPERTY(BlueprintReadOnly)
	bool	bSelf;

	UPROPERTY(BlueprintReadOnly)
	int32   KillCount;

	UPROPERTY(BlueprintReadOnly)
	int32   DeadCount;
};

UCLASS()
class ABSNGameState : public AGameState
{
	GENERATED_BODY()
public:
	static const FName WaitForEnter;
	static const FName WaitForPlay;
	static const FName LevelLoading;
	ABSNGameState(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());
	virtual bool HasMatchStarted() const override;
	virtual void OnRep_MatchState() override;
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;
	float GetWaitTime() { return WaitTime;  }
	int32 GetWaitTimeInt() { return IntWaitTime; }
	void  SetWaitTime(float InTime);

	void SetRemainingEnterMatchWaitTime(float InTime);

	float GetRemainingEnterMatchWaitTime() const { return RemainingEnterMatchWaitTime; }

	void SetGameMatchRemainingTime(float InTime);

	float GetGameMatchRemainingTime() const { return GameMatchRemainingTime; }

	void SetWaitToLeaveMapRemainingTime(float InTime);

	float GetWaitToLeaveMapRemainingTime() const { return WaitToLeaveMapRemainingTime; }

	UFUNCTION(BlueprintCallable, BlueprintNativeEvent, Category = "ReplicationNotify")
	void OnRep_IntWaitTime(int32 OldTime);

	virtual void OnRep_IntWaitTime_Implementation(int32 OldTime);

	UFUNCTION(BlueprintCallable, Category = "ReplicationNotify")
	void OnRep_RemainingEnterMatchWaitTime();

	UFUNCTION(BlueprintCallable, Category="UI")
	TArray<FScoreBoradItem> &GetScoreBoardData();
	void UpdateScoreBoard();
protected:
	virtual void HandleInWaitingRoom();
public:
	UPROPERTY(Transient, Replicated)
	int32			PlayerNumeber;
	UPROPERTY(Transient, Replicated)
	int32			PlayerNumberNeed;
	FString			URL;
protected:
	UPROPERTY(Transient, BlueprintReadOnly, ReplicatedUsing=OnRep_IntWaitTime)
	int32			IntWaitTime;

	UPROPERTY(Transient, BlueprintReadOnly, Replicated)
	float			WaitTime;

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, ReplicatedUsing=OnRep_RemainingEnterMatchWaitTime, Category = Game)
	float RemainingEnterMatchWaitTime;

	UPROPERTY(Transient, BlueprintReadOnly, Replicated, Category = Game)
	float GameMatchRemainingTime;

	UPROPERTY(Transient, BlueprintReadOnly, Replicated, Category = Game)
	float WaitToLeaveMapRemainingTime;

	UPROPERTY(Transient, BlueprintReadOnly, Replicated, Category = Game)
	float CurrentTimer;

	UPROPERTY(BlueprintAssignable, Category = Time)
	FOnTimeUpdateDelegate WaitTimeUpdateDelegates;

	FOnTimeUpdateDelegate EnterMatchWaitTimeUpdateDelegates;

	TArray<FScoreBoradItem>  ScoreBoardData;
};

