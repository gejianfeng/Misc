#include "BlackShieldNetNative.h"
#include "BSNGameModeBase.h"
#include "BSNGameState.h"
#include "BlackShieldGameInstance.h"
#include "Player/BSNPlayerController.h"
#include "Player/BSNCharacter.h"
#include "Game/BSNPlayerState.h"

const FName ABSNGameState::WaitForEnter = TEXT("WaitForEnter");
const FName ABSNGameState::WaitForPlay = TEXT("WaitForPlay");
const FName ABSNGameState::LevelLoading = TEXT("LevelLoading");

ABSNGameState::ABSNGameState(const FObjectInitializer& ObjectInitializer /*= FObjectInitializer::Get()*/)
	: Super(ObjectInitializer)
	, PlayerNumeber(0)
	, PlayerNumberNeed(2)
	, WaitTime(20)
{
	RemainingEnterMatchWaitTime = 0;
	GameMatchRemainingTime = 0;
	WaitToLeaveMapRemainingTime = 0;
}

bool ABSNGameState::HasMatchStarted() const
{
	if (GetMatchState() == MatchState::EnteringMap || GetMatchState() == MatchState::WaitingToStart || GetMatchState() == MatchState::InWaitingRoom)
	{
		return false;
	}

	return true;
}

void ABSNGameState::SetWaitTime(float InTime)
{
	WaitTime = InTime; 
	IntWaitTime = FMath::RoundToInt(InTime);
	ForceNetUpdate();
}

void ABSNGameState::SetRemainingEnterMatchWaitTime(float InTime)
{
	RemainingEnterMatchWaitTime = InTime;
	ForceNetUpdate();
}

void ABSNGameState::SetGameMatchRemainingTime(float InTime)
{
	GameMatchRemainingTime = InTime;
}

void ABSNGameState::SetWaitToLeaveMapRemainingTime(float InTime)
{
	WaitToLeaveMapRemainingTime = InTime;
}

void ABSNGameState::OnRep_IntWaitTime_Implementation(int32 OldTime)
{
	WaitTimeUpdateDelegates.Broadcast(IntWaitTime);
}

void ABSNGameState::OnRep_RemainingEnterMatchWaitTime()
{
	EnterMatchWaitTimeUpdateDelegates.Broadcast((int32)RemainingEnterMatchWaitTime);
}

void ABSNGameState::OnRep_MatchState()
{
	if (MatchState == MatchState::InWaitingRoom)
	{
		HandleInWaitingRoom();
	}
	Super::OnRep_MatchState();
}

void ABSNGameState::HandleInWaitingRoom()
{
	GetWorldSettings()->NotifyBeginPlay();
}

void ABSNGameState::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
	DOREPLIFETIME(ABSNGameState, PlayerNumeber);
	DOREPLIFETIME(ABSNGameState, PlayerNumberNeed);
	DOREPLIFETIME(ABSNGameState, IntWaitTime);

	DOREPLIFETIME(ABSNGameState, RemainingEnterMatchWaitTime);

	DOREPLIFETIME(ABSNGameState, GameMatchRemainingTime);
}

void ABSNGameState::UpdateScoreBoard()
{
	ScoreBoardData.Empty();
	for (FConstPawnIterator It(GetWorld()->GetPawnIterator()); It; ++It)
	{
		ABSNCharacter *pCharacter = Cast<ABSNCharacter>(*It);
		ABSNPlayerState *PlayerState = pCharacter ? Cast<ABSNPlayerState>(pCharacter->PlayerState) : NULL;
		if (PlayerState != NULL)
		{
			int32 value = PlayerState->GetKillCount() - PlayerState->GetDeathCount();

			ScoreBoardData.AddZeroed();
			int32 Index = ScoreBoardData.Num() - 1;
			if (ScoreBoardData.Num() > 1)
			{
				for (; Index > 0; --Index)
				{
					FScoreBoradItem &item = ScoreBoardData[Index - 1];
					if (value <= (item.KillCount - item.DeadCount))
					{
						break;
					}
					ScoreBoardData[Index] = item;
					ScoreBoardData[Index].Rank = Index + 1;
				}
			}

			FScoreBoradItem &Item = ScoreBoardData[Index];
			Item.bSelf = pCharacter->IsLocallyControlled();
			Item.DeadCount = PlayerState->GetDeathCount();
			Item.KillCount = PlayerState->GetKillCount();
			Item.Name = PlayerState->PlayerName;
			Item.Rank = Index + 1;
		}
	}
}

TArray<FScoreBoradItem> & ABSNGameState::GetScoreBoardData()
{
	return ScoreBoardData;
}

