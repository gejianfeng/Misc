#pragma once

#include "BSNGameModeBase.h"
#include "BSNGameModeFreeForAll.generated.h"

UCLASS(Config = Game, notplaceable, BlueprintType, Blueprintable, Transient)
class ABSNGameModeFreeForAll : public ABSNGameModeBase
{
	GENERATED_BODY()

public:
	ABSNGameModeFreeForAll(const FObjectInitializer& ObjectInitialzier = FObjectInitializer::Get());

	virtual void OnKilled(AController* Killer, AController* KilledPlayer, APawn* KilledPawn, const UDamageType* DamageType) override;

	virtual void OnVictory(AController* Winner);

protected:
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = Game)
	int32 KillCountVictory;
};