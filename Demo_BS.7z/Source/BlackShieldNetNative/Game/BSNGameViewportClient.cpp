#include "BlackShieldNetNative.h"
#include "BSNGameViewportClient.h"
#include "UI/Widgets/SConfirmationDialog.h"
#include "UI/Widgets/SScoreRank.h"
#include "BlackShieldGameInstance.h"
#include "UI/ScoreBoard.h"

UBSNGameViewportClient::UBSNGameViewportClient(const FObjectInitializer &ObjectInitializer)
	:Super(ObjectInitializer)
{
}

void UBSNGameViewportClient::ShowDialog(TWeakObjectPtr<ULocalPlayer> PlayerOwner, EDialogType DialogType, const FText &Message, const FText &Confirm, const FText &Cancel, const FOnClicked &OnConfirm, const FOnClicked &OnCancel)
{
	if (DialogWidget.IsValid())
	{
		return;
	}

	DialogWidget = SNew(SConfirmationDialog)
		.PlayerOwner(PlayerOwner)
		.DialogType(DialogType)
		.MessageText(Message)
		.ConfirmText(Confirm)
		.CancelText(Cancel)
		.OnConfirmClicked(OnConfirm)
		.OnCancelClicked(OnCancel);

	AddViewportWidgetContent(DialogWidget.ToSharedRef());

	OldFocusWidget = FSlateApplication::Get().GetKeyboardFocusedWidget();

	FSlateApplication::Get().SetKeyboardFocus(DialogWidget, EFocusCause::SetDirectly);
}

void UBSNGameViewportClient::HideDialog()
{
	if (DialogWidget.IsValid())
	{
		RemoveViewportWidgetContent(DialogWidget.ToSharedRef());
		DialogWidget = NULL;

		if (OldFocusWidget.IsValid())
		{
			FSlateApplication::Get().SetKeyboardFocus(OldFocusWidget, EFocusCause::SetDirectly);
		}

		OldFocusWidget = NULL;
	}
}

EDialogType UBSNGameViewportClient::GetDialogType() const
{
	return DialogWidget.IsValid() ? DialogWidget->DialogType : EDialogType::None;
}

TWeakObjectPtr<ULocalPlayer> UBSNGameViewportClient::GetDialogOwner() const
{
	return DialogWidget.IsValid() ? DialogWidget->PlayerOwner : nullptr;
}

void UBSNGameViewportClient::ShowScoreRank()
{
	if (1)
	{
		UBlackShieldGameInstance *GI = Cast<UBlackShieldGameInstance>(GameInstance);
		AScoreBoard *Board = GI ? GI->GetScoreBoard() : NULL;
		if (Board)
		{
			Board->ShowBoard(true);
		}
	}
	else
	{
		ScoreRankWidget = SNew(SScoreRank).Viewport(this);
		AddViewportWidgetContent(ScoreRankWidget.ToSharedRef());
	}
}

void UBSNGameViewportClient::HideScoreRank()
{
	if (1)
	{
		UBlackShieldGameInstance *GI = Cast<UBlackShieldGameInstance>(GameInstance);
		AScoreBoard *Board = GI? GI->GetScoreBoard() : NULL;
		if (Board)
		{
			Board->ShowBoard(false);
		}
	}
	else
	{
		if (ScoreRankWidget.IsValid())
		{
			RemoveViewportWidgetContent(ScoreRankWidget.ToSharedRef());
			ScoreRankWidget = NULL;
		}
	}
}


