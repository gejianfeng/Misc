
#include "BlackShieldNetNative.h"
#include "BSNPlayerState.h"
#include "BlackShieldGameInstance.h"
#include "UI/ScoreBoard.h"
#include "Player/BSNCharacter.h"

ABSNPlayerState::ABSNPlayerState(const FObjectInitializer& ObjectInitializer /*= FObjectInitializer::Get()*/)
	: Super(ObjectInitializer)
{
	HeroName = TEXT("Hero0");
	PVPState = EPVPState::None;
	PVPWaitStartTime = 0;

	KillCount = 0;
	DeathCount = 0;

	PlayerIndex = -1;
	bPlayerDead = false;
}

ABSNPlayerState::~ABSNPlayerState()
{
}

void ABSNPlayerState::IncreaseKillCount()
{
	KillCount++;
}

void ABSNPlayerState::SetKillCount(int32 InKillCount)
{
	KillCount = InKillCount;
}

void ABSNPlayerState::IncreaseDeathCount()
{
	DeathCount++;
}

void ABSNPlayerState::SetDeathCount(int32 InDeathCount)
{
	DeathCount = InDeathCount;
}

void ABSNPlayerState::SetHeroName(const FString& InHeroName)
{
	HeroName = InHeroName;
}

void ABSNPlayerState::SetPlayerIndex(int32 InIndex)
{
	PlayerIndex = InIndex;
}

void ABSNPlayerState::SetPlayerDead(bool bDead)
{
	bPlayerDead = bDead;
}


void ABSNPlayerState::ClientAddKillMessage_Implementation(const FString &Killer, const FString &DeadPlayer, int8 InGunType)
{
	UBlackShieldGameInstance *GI = Cast<UBlackShieldGameInstance>(GetGameInstance());
	AScoreBoard *Board = GI->GetScoreBoard();
	if (Board != NULL)
	{
		Board->AddKillMessage(Killer, DeadPlayer, EGunType(InGunType));
	}
}

void ABSNPlayerState::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
	DOREPLIFETIME(ABSNPlayerState, HeroName);
	DOREPLIFETIME(ABSNPlayerState, PVPState);
	DOREPLIFETIME(ABSNPlayerState, PVPWaitStartTime);

	DOREPLIFETIME(ABSNPlayerState, KillCount);
	DOREPLIFETIME(ABSNPlayerState, DeathCount);

	DOREPLIFETIME(ABSNPlayerState, PlayerIndex);
	DOREPLIFETIME(ABSNPlayerState, bPlayerDead);
}

