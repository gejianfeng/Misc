#pragma once

#include "BSNPlayerState.generated.h"

UENUM()
enum class EPVPState : uint8
{
	None,
	WaitEnterPVPMap,
	EnterPVPMap,
};

UCLASS()
class ABSNPlayerState : public APlayerState
{
	GENERATED_BODY()
public:
	ABSNPlayerState(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());
	~ABSNPlayerState();

	void IncreaseKillCount();

	void SetKillCount(int32 InKillCount);

	int32 GetKillCount() const { return KillCount; }

	void IncreaseDeathCount();

	void SetDeathCount(int32 InDeathCount);

	int32 GetDeathCount() const { return DeathCount; }

	FString GetHeroName() const { return HeroName; }

	UFUNCTION(BlueprintCallable, Category = Game)
	void SetHeroName(const FString& InHeroName);

	UFUNCTION(BlueprintCallable, Category = Game)
	void SetPlayerIndex(int32 InIndex);

	int32 GetPlayerIndex() { return PlayerIndex; }

	void SetPlayerDead(bool bDead);

	bool GetPlayerDead() const { return bPlayerDead; }

	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

	UFUNCTION(Client, Reliable)
	void ClientAddKillMessage(const FString &Killer, const FString &DeadPlayer, int8 InGunType);

protected:
	UPROPERTY(Transient, VisibleAnywhere, BlueprintReadOnly, Replicated, Category = Game)
	int32 KillCount;

	UPROPERTY(Transient, VisibleAnywhere, BlueprintReadOnly, Replicated, Category = Game)
	int32 DeathCount;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Replicated, Category = Game)
	FString HeroName;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Replicated, Category = Game)
	int32 PlayerIndex;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Replicated, Category = Game)
	bool bPlayerDead;
public:
	UPROPERTY(Transient, Replicated)
	EPVPState PVPState;
	UPROPERTY(Transient, Replicated)
	double    PVPWaitStartTime;
};

