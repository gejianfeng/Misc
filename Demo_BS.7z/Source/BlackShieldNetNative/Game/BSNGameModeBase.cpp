#include "BlackShieldNetNative.h"
#include "Interface/LevelScriptGameInterface.h"
#include "BSNGameModeBase.h"
#include "BSNGameState.h"
#include "BSNPlayerState.h"
#include "AI/BSNBotAIController.h"
#include "BlackShieldUtilityFunctions.h"
#include "BlackShieldGameInstance.h"
#include "Player/BSNPlayerController.h"
#include "Player/BSNCharacter.h"
#include "Online/BSNGameSession.h"
#include "UI/BSNHUD.h"
#include "Interface/MatchGameInterface.h"

DEFINE_LOG_CATEGORY_STATIC(LogGameMode, Log, All);

namespace MatchState
{
	const FName InWaitingRoom = TEXT("InWaitingRoom");
}

ABSNGameModeBase::ABSNGameModeBase(const FObjectInitializer& ObjectInitializer /*= FObjectInitializer::Get()*/)
	: Super(ObjectInitializer)
{
	GameStateClass = ABSNGameState::StaticClass();
	PlayerControllerClass = ABSNPlayerController::StaticClass();
	PlayerStateClass = ABSNPlayerState::StaticClass();
	HUDClass = ABSNHUD::StaticClass();
	
	DefaultWaitingRoomMapName = TEXT("L_MainLobby");

	bShouldLoadWaitingRoom = false;
	bWaitingRoomMapLoadExcuted = false;

	bBotsPreCreated = false;

	DefaultCreateBotsRemainingTime = 3.0f;

	MinRespawnDelay = 3.0f;

	DefaultEnterMatchWaitTime = 30;

	DefaultWaitToStartTime = 15;

	DefaultGameMatchTime = 300;

	WaitToLeaveMapTime = 10;

	InvincibleTimeWhenSpawn = 3;

	bCanStartNewPlayer = false;

	bStartEnterMatchTick = false;

	MaxNumberPlayer = 6;

	MaxNumberBots = 5;

	NumLoginPlayer = 0;

	ServiceMap = TEXT("L_MainGamePVP");
}

void ABSNGameModeBase::StartPlay()
{
	if (MatchState == MatchState::EnteringMap)
	{
		SetMatchState(MatchState::InWaitingRoom);
	}

	if (UWorld* World = GetWorld())
	{
		ALevelScriptActor* LevelScriptActor = World->GetLevelScriptActor();
		if (LevelScriptActor && LevelScriptActor->Implements<ULevelScriptGameInterface>())
		{
			bShouldLoadWaitingRoom = ILevelScriptGameInterface::Execute_NeedWaitingRoom(LevelScriptActor);
			ILevelScriptGameInterface::Execute_GameModeStarted(LevelScriptActor);
		}
	}

	if (bShouldLoadWaitingRoom)
	{
		CheckAndLoadWaitingRoom();
	}
	else
	{
		// Start match directly
		StartMatch();
	}
}

void ABSNGameModeBase::StartMatch()
{
	if (HasMatchStarted())
	{
		return;
	}

	//Let the game session override the StartMatch function, in case it wants to wait for arbitration
	if (GameSession->HandleStartMatchRequest())
	{
		return;
	}

	SetMatchState(MatchState::InProgress);
}

bool ABSNGameModeBase::HasMatchStarted() const
{
	if (GetMatchState() == MatchState::EnteringMap || GetMatchState() == MatchState::WaitingToStart || GetMatchState() == MatchState::InWaitingRoom)
	{
		return false;
	}

	return true;
}

bool ABSNGameModeBase::IsMatchInWaitingRoom() const
{
	return GetMatchState() == MatchState::InWaitingRoom;
}

bool ABSNGameModeBase::IsMatchWaitingToStart() const
{
	return GetMatchState() == MatchState::WaitingToStart;
}

bool ABSNGameModeBase::IsWaitingPostMatch() const
{
	return GetMatchState() == MatchState::WaitingPostMatch;
}

void ABSNGameModeBase::HandleInvicibleTimeUp(TWeakObjectPtr<class ABSNCharacter> BSNCharacter)
{
	if (BSNCharacter.IsValid())
	{
		BSNCharacter->SetInvincible(false);
	}
}

void ABSNGameModeBase::Tick(float DeltaSeconds)
{
	if (bStartEnterMatchTick && NumPlayers >= 1)
	{
		ABSNGameState* BSNGameState = GetGameState<ABSNGameState>();
		if (BSNGameState)
		{
			BSNGameState->SetRemainingEnterMatchWaitTime(BSNGameState->GetRemainingEnterMatchWaitTime() - DeltaSeconds);
			if (BSNGameState->GetRemainingEnterMatchWaitTime() <= 0)
			{
				BSNGameState->SetRemainingEnterMatchWaitTime(0);
				bStartEnterMatchTick = false;

				EnterGameLevel();
			}

			if (BSNGameState->GetRemainingEnterMatchWaitTime() <= DefaultCreateBotsRemainingTime && !bBotsPreCreated)
			{
				CreateDefaultBots();
				StartBots();
				bBotsPreCreated = true;
			}
		}
	}
	else if (GetMatchState() == MatchState::WaitingToStart && NumPlayers >= 1)
	{
		ABSNGameState* BSNGameState = GetGameState<ABSNGameState>();
		if (BSNGameState)
		{
			BSNGameState->SetWaitTime(BSNGameState->GetWaitTime() - DeltaSeconds);
			if (BSNGameState->GetWaitTime() <= 0)
			{
				BSNGameState->SetWaitTime(0);

				//StartMatch();
			}
		}
	}
	else if (IsMatchInProgress())
	{
		ABSNGameState* BSNGameState = GetGameState<ABSNGameState>();
		if (BSNGameState)
		{
			BSNGameState->SetGameMatchRemainingTime(BSNGameState->GetGameMatchRemainingTime() - DeltaSeconds);
			if (BSNGameState->GetGameMatchRemainingTime() <= 0)
			{
				BSNGameState->SetGameMatchRemainingTime(0);

				EndMatch();
			}
		}
	}
	else if (IsWaitingPostMatch())
	{
		ABSNGameState* BSNGameState = GetGameState<ABSNGameState>();
		if (BSNGameState)
		{
			BSNGameState->SetWaitToLeaveMapRemainingTime(BSNGameState->GetWaitToLeaveMapRemainingTime() - DeltaSeconds);
			if (BSNGameState->GetWaitToLeaveMapRemainingTime() <= 0)
			{
				BSNGameState->SetWaitToLeaveMapRemainingTime(0);

				SetMatchState(MatchState::LeavingMap);
				
				if (IsRunningDedicatedServer())
				{
					OnFinishGame();
				}
				else
				{
					ReturnToMainMenuHost();
				}
			}
		}
	}

	Super::Tick(DeltaSeconds);
}

void ABSNGameModeBase::PreLogin(const FString& Options, const FString& Address, const TSharedPtr<const FUniqueNetId>& UniqueId, FString& ErrorMessage)
{
	if (NumPlayers + 1 > MaxNumberPlayer)
	{
		ErrorMessage = FString::Printf(TEXT("Exceeded max allowed players(%d)"), MaxNumberPlayer);
		return;
	}

	Super::PreLogin(Options, Address, UniqueId, ErrorMessage);
}

void ABSNGameModeBase::LoadWaitingRoom()
{
	if (bWaitingRoomMapLoadExcuted)
	{
		return;
	}

	bWaitingRoomMapLoadExcuted = true;

	WaitingRoomSubLevelName = DefaultWaitingRoomMapName;

	if (UWorld* World = GetWorld())
	{
		ALevelScriptActor* LevelScriptActor = World->GetLevelScriptActor();
		if (LevelScriptActor)
		{
			FName RetrievedMapName = ILevelScriptGameInterface::Execute_GetWaitingRoomMapName(LevelScriptActor);
			if (!RetrievedMapName.IsNone())
			{
				WaitingRoomSubLevelName = RetrievedMapName;
			}
		}
	}

	if (!WaitingRoomSubLevelName.IsNone())
	{
		BSNUtils::LoadStreamLevel(this, WaitingRoomSubLevelName, true, false, FBSNLevelStreamingActionComplete::CreateUObject(this, &ABSNGameModeBase::HandleLoadWaitingRoomComplete));
	}
}

void ABSNGameModeBase::SetShouldLoadWaitingRoom(bool bShould)
{
	bShouldLoadWaitingRoom = bShould;
}

void ABSNGameModeBase::HandleLoadWaitingRoomComplete()
{
	for (FConstPlayerControllerIterator Iterator = GetWorld()->GetPlayerControllerIterator(); Iterator; ++Iterator)
	{
		APlayerController* PlayerController = *Iterator;
		if (PlayerCanRestart(PlayerController))
		{
			APawn* OldPawn = PlayerController->GetPawn();
			if (OldPawn)
			{
				OldPawn->Destroy();
			}

			PlayerController->Possess(nullptr);

			RestartPlayer(PlayerController);
		}
	}

	SetCanStartNewPlayer(true);

	K2_LoadWaitingRoomCompleted();
}

void ABSNGameModeBase::K2_LoadWaitingRoomCompleted_Implementation()
{
	bStartEnterMatchTick = true;
	ABSNGameState* BSNGameState = GetGameState<ABSNGameState>();
	if (BSNGameState)
	{
		BSNGameState->SetRemainingEnterMatchWaitTime(DefaultEnterMatchWaitTime);
	}
}

void ABSNGameModeBase::Killed(AController* Killer, AController* KilledPlayer, APawn* KilledPawn, const UDamageType* DamageType)
{
	if (HasMatchEnded())
		return;

	ABSNPlayerState* KillerPlayerState = Killer ? Cast<ABSNPlayerState>(Killer->PlayerState) : nullptr;
	ABSNPlayerState* KilledPlayerState = KilledPlayer ? Cast<ABSNPlayerState>(KilledPlayer->PlayerState) : nullptr;

	if (Killer != KilledPlayer)
	{
		if (KillerPlayerState)
		{
			KillerPlayerState->IncreaseKillCount();
		}

		if (KilledPlayer)
		{
			KilledPlayerState->IncreaseDeathCount();
		}
	}

	OnKilled(Killer, KilledPlayer, KilledPawn, DamageType);
}

void ABSNGameModeBase::OnKilled(AController* Killer, AController* KilledPlayer, APawn* KilledPawn, const UDamageType* DamageType)
{
}

bool ABSNGameModeBase::CanDamage(AController* Instigator, AController* DamagedPlayer, AActor* DamageCauser)
{
	if (IsMatchInProgress() && DamagedPlayer)
	{
		ABSNCharacterBase* BSNCharacterBase = Cast<ABSNCharacterBase>(DamagedPlayer->GetPawn());
		if (BSNCharacterBase)
		{
			// Invincible character can not be damaged
			return (!BSNCharacterBase->GetInvincible() && !BSNCharacterBase->GetIsDying());
		}
	}

	return false;
}

void ABSNGameModeBase::StartNewPlayer(APlayerController* NewPlayer)
{
	// tell client what hud class to use
	NewPlayer->ClientSetHUD(HUDClass);

	if (bCanStartNewPlayer)
	{
		RestartPlayer(NewPlayer);
	}
}

void ABSNGameModeBase::StartPlayerRespawnProcess(class AController* InController)
{
	if (!CanPlayerRespawn(InController))
		return;

	FTimerHandle UnUsedTimeHandler;
	GetWorld()->GetTimerManager().SetTimer(UnUsedTimeHandler, FTimerDelegate::CreateUObject(this, &ABSNGameModeBase::RespawnPlayer, InController), MinRespawnDelay, false);
}

bool ABSNGameModeBase::CanPlayerRespawn(class AController* InController) const
{
	if (!InController
		|| InController->IsPendingKill()								// already destroyed
		|| !GetWorld()->bMatchStarted
		|| GetMatchState() != MatchState::InProgress)
	{
		return false;
	}

	return true;
}

void ABSNGameModeBase::RespawnPlayer(class AController* InController)
{
	OnRespawnPlayer(InController);
}

void ABSNGameModeBase::OnRespawnPlayer(class AController* InController)
{
	if (!CanPlayerRespawn(InController))
	{
		return;
	}

	ABSNPlayerController* BSNPlayerController = Cast<ABSNPlayerController>(InController);
	if (BSNPlayerController)
	{
		BSNPlayerController->LeaveDeathSpectatorState();
	}

	APawn* ControlledPawn = InController->GetPawn();
	if (ControlledPawn)
	{
		InController->UnPossess();
		ControlledPawn->Destroy();
	}

	RestartPlayer(InController);
}

APlayerController* ABSNGameModeBase::Login(class UPlayer* NewPlayer, ENetRole RemoteRole, const FString& Portal, const FString& Options, const TSharedPtr<const FUniqueNetId>& UniqueId, FString& ErrorMessage)
{
	ErrorMessage = GameSession->ApproveLogin(Options);
	if (!ErrorMessage.IsEmpty())
	{
		return NULL;
	}

	APlayerController* NewPlayerController = SpawnPlayerController(RemoteRole, FVector::ZeroVector, FRotator::ZeroRotator);

	if (NewPlayerController)
	{
		CustomLoginProcess(NewPlayer, RemoteRole, Portal, Options, UniqueId, ErrorMessage, NewPlayerController);
	}

	// Handle spawn failure.
	if (NewPlayerController == NULL)
	{
		UE_LOG(LogGameMode, Log, TEXT("Couldn't spawn player controller of class %s"), PlayerControllerClass ? *PlayerControllerClass->GetName() : TEXT("NULL"));
		ErrorMessage = FString::Printf(TEXT("Failed to spawn player controller"));
		return NULL;
	}

	// Customize incoming player based on URL options
	ErrorMessage = InitNewPlayer(NewPlayerController, UniqueId, Options, Portal);
	if (!ErrorMessage.IsEmpty())
	{
		return NULL;
	}

	// Set up spectating
	bool bSpectator = FCString::Stricmp(*UGameplayStatics::ParseOption(Options, TEXT("SpectatorOnly")), TEXT("1")) == 0;
	if (bSpectator || MustSpectate(NewPlayerController))
	{
		NewPlayerController->StartSpectatingOnly();
		return NewPlayerController;
	}

	return NewPlayerController;
}

void ABSNGameModeBase::CustomLoginProcess(class UPlayer* NewPlayer, ENetRole InRemoteRole, const FString& Portal, const FString& Options, const TSharedPtr<const FUniqueNetId>& UniqueId, FString& ErrorMessage, APlayerController* NewPlayerController)
{
	NumLoginPlayer++;

	FString HeroName = UGameplayStatics::ParseOption(Options, TEXT("HeroName"));
	if (!HeroName.IsEmpty())
	{
		ABSNPlayerController* BSNPlayerController = Cast<ABSNPlayerController>(NewPlayerController);
		if (BSNPlayerController)
		{
			BSNPlayerController->SetHeroName(HeroName);
		}
	}

	ABSNPlayerState* BSNPlayerState = Cast<ABSNPlayerState>(NewPlayerController->PlayerState);
	if (BSNPlayerState)
	{
		int32 PlayerIndex = NumLoginPlayer - 1;

		BSNPlayerState->SetPlayerIndex(PlayerIndex);
	}

	// Destroy a bot character when a new human player login
	//UWorld* World = GetWorld();
	//if (World)
	//{
	//	for (FConstControllerIterator Iter = World->GetControllerIterator(); Iter; ++Iter)
	//	{
	//		ABSNBotAIController* BotAIController = Cast<ABSNBotAIController>(*Iter);
	//		if (BotAIController)
	//		{
	//			DestroyBot(BotAIController);
	//			break;
	//		}
	//	}
	//}
}

void ABSNGameModeBase::PostLogin(APlayerController* NewPlayer)
{
	Super::PostLogin(NewPlayer);

	if (NumPlayers >= MaxNumberPlayer)
	{
		UBlackShieldGameInstance* GameInstance = BSNUtils::GetBSNGameInstance(this);
		if (GameInstance)
		{
			GameInstance->SetAllowJoinSession(false);
		}
	}
}

void ABSNGameModeBase::Logout(AController* Exiting)
{
	Super::Logout(Exiting);

	if (Exiting->IsA<APlayerController>())
	{
		NumLoginPlayer--;
	}
}

void ABSNGameModeBase::RestartPlayer(class AController* NewPlayer)
{
	if (NewPlayer == NULL || NewPlayer->IsPendingKillPending())
	{
		return;
	}

	UE_LOG(LogGameMode, Verbose, TEXT("RestartPlayer %s"), (NewPlayer && NewPlayer->PlayerState) ? *NewPlayer->PlayerState->PlayerName : TEXT("Unknown"));

	if (NewPlayer->PlayerState && NewPlayer->PlayerState->bOnlySpectator)
	{
		UE_LOG(LogGameMode, Verbose, TEXT("RestartPlayer tried to restart a spectator-only player!"));
		return;
	}

	AActor* StartSpot = FindPlayerStart(NewPlayer);

	// if a start spot wasn't found,
	if (StartSpot == NULL)
	{
		// check for a previously assigned spot
		if (NewPlayer->StartSpot != NULL)
		{
			StartSpot = NewPlayer->StartSpot.Get();
			UE_LOG(LogGameMode, Warning, TEXT("Player start not found, using last start spot"));
		}
		else
		{
			// otherwise abort
			UE_LOG(LogGameMode, Warning, TEXT("Player start not found, failed to restart player"));
			return;
		}
	}
	// try to create a pawn to use of the default class for this player
	if (NewPlayer->GetPawn() == NULL && GetDefaultPawnClassForController(NewPlayer) != NULL)
	{
		NewPlayer->SetPawn(SpawnDefaultPawnFor(NewPlayer, StartSpot));
	}

	if (NewPlayer->GetPawn() == NULL)
	{
		NewPlayer->FailedToSpawnPawn();
	}
	else
	{
		// initialize and start it up
		InitStartSpot(StartSpot, NewPlayer);

		// @todo: this was related to speedhack code, which is disabled.
		/*
		if ( NewPlayer->GetAPlayerController() )
		{
		NewPlayer->GetAPlayerController()->TimeMargin = -0.1f;
		}
		*/
		NewPlayer->Possess(NewPlayer->GetPawn());

		// If the Pawn is destroyed as part of possession we have to abort
		if (NewPlayer->GetPawn() == nullptr)
		{
			NewPlayer->FailedToSpawnPawn();
		}
		else
		{
			// set initial control rotation to player start's rotation
			NewPlayer->ClientSetRotation(NewPlayer->GetPawn()->GetActorRotation(), true);

			FRotator NewControllerRot = StartSpot->GetActorRotation();
			NewControllerRot.Roll = 0.f;
			NewPlayer->SetControlRotation(NewControllerRot);

			SetPlayerDefaults(NewPlayer->GetPawn());

			K2_OnRestartPlayer(NewPlayer);
		}
	}

#if !UE_WITH_PHYSICS
	if (NewPlayer->GetPawn() != NULL)
	{
		UCharacterMovementComponent* CharacterMovement = Cast<UCharacterMovementComponent>(NewPlayer->GetPawn()->GetMovementComponent());
		if (CharacterMovement)
		{
			CharacterMovement->bCheatFlying = true;
			CharacterMovement->SetMovementMode(MOVE_Flying);
		}
	}
#endif	//!UE_WITH_PHYSICS

	PostRestartPlayer(NewPlayer);
}

void ABSNGameModeBase::PostRestartPlayer(class AController* NewPlayer)
{
	if (!NewPlayer)
		return;

	ABSNCharacter* BSNCharacter = Cast<ABSNCharacter>(NewPlayer->GetPawn());
	ABSNPlayerState* BSNPlayerState = Cast<ABSNPlayerState>(NewPlayer->PlayerState);
	if (BSNPlayerState)
	{
		BSNPlayerState->SetPlayerDead(false);
	}

	if (IsMatchWaitingToStart())
	{
		BSNCharacter->SetInvincible(true);
	}
	else if (IsMatchInProgress())
	{
		BSNCharacter->CreateHandGun();
		BSNCharacter->SetInvincible(true);

		// Invincible
		FTimerHandle InvincibleTimeHandle;
		GetWorld()->GetTimerManager().SetTimer(InvincibleTimeHandle, FTimerDelegate::CreateUObject(this, &ABSNGameModeBase::HandleInvicibleTimeUp, TWeakObjectPtr<class ABSNCharacter>(BSNCharacter)), InvincibleTimeWhenSpawn, false);
	}

	if (IsMatchWaitingToStart() || IsMatchInProgress())
	{
		BSNCharacter->ClientInitInGame();
	}

	ABSNBotAIController* BotPlayer = Cast<ABSNBotAIController>(NewPlayer);
	if (BotPlayer)
	{
		PostInitBotPlayer(BotPlayer);
	}
}

void ABSNGameModeBase::PostInitBotPlayer(class ABSNBotAIController* BotPlayer)
{
	if (IsMatchInProgress())
	{
		ABSNCharacter* BSNCharacter = Cast<ABSNCharacter>(BotPlayer->GetPawn());
		BSNCharacter->CreateHandGun();
		BotPlayer->StartRunBehaviorTree();
	}
}

bool ABSNGameModeBase::PlayerCanRestart_Implementation(APlayerController* Player)
{
	if (!(IsMatchInProgress() || IsMatchInWaitingRoom() || IsMatchWaitingToStart()) || Player == NULL || Player->IsPendingKillPending())
	{
		return false;
	}

	// Ask the player controller if it's ready to restart as well
	return Player->CanRestartPlayer();
}

AActor* ABSNGameModeBase::FindPlayerStart_Implementation(AController* Player, const FString& IncomingName)
{
	UWorld* World = GetWorld();

	FName IncomingPlayerStartTag;
	// if incoming start is specified, then just use it
	if (!IncomingName.IsEmpty())
	{
		IncomingPlayerStartTag = FName(*IncomingName);
	}
	else
	{
		if (Player->IsA<APlayerController>())
		{
			if (IsMatchInWaitingRoom())
			{
				IncomingPlayerStartTag = TEXT("Wait");
			}
			else
			{
				IncomingPlayerStartTag = TEXT("SpawnPlayer");
			}
		}
		else if (Player->IsA<AAIController>())
		{
			IncomingPlayerStartTag = TEXT("SpawnBot");
		}
	}

	if (IncomingPlayerStartTag.IsValid())
	{
		TArray<APlayerStart*> CandidatePlayerStarts;
		for (TActorIterator<APlayerStart> It(World); It; ++It)
		{
			APlayerStart* Start = *It;
			if (Start && Start->PlayerStartTag == IncomingPlayerStartTag)
			{
				CandidatePlayerStarts.Add(Start);
			}
		}

		if (CandidatePlayerStarts.Num() > 0)
		{
			AActor* ChosenStartSpot = nullptr;

			// Adjust in game spawn location. Calculate average distance between each bot character and player to each bot spawn actor.
			// Use the farthest point as the spawn location.
			if (IsMatchInProgress())
			{
				ChosenStartSpot = ChooseNoCharacterStartSpot(CandidatePlayerStarts);
			}
			else
			{
				ABSNPlayerState* BSNPlayerState = Cast<ABSNPlayerState>(Player->PlayerState);
				int32 Index = 0;

				int32 PlayerIndex = BSNPlayerState->GetPlayerIndex();
				if (BSNPlayerState && PlayerIndex >= 0)
				{
					Index = PlayerIndex;
					Index = Index % CandidatePlayerStarts.Num();
				}
				else
				{
					Index = FMath::RandRange(0, CandidatePlayerStarts.Num() - 1);
				}

				ChosenStartSpot = CandidatePlayerStarts[Index];
			}

			return ChosenStartSpot;
		}
	}

	// always pick StartSpot at start of match
	if (ShouldSpawnAtStartSpot(Player))
	{
		return Player->StartSpot.Get();
	}

	AActor* BestStart = ChoosePlayerStart(Player);
	if (BestStart == NULL)
	{
		// no player start found
		UE_LOG(LogGameMode, Log, TEXT("Warning - PATHS NOT DEFINED or NO PLAYERSTART with positive rating"));

		// This is a bit odd, but there was a complex chunk of code that in the end always resulted in this, so we may as well just 
		// short cut it down to this.  Basically we are saying spawn at 0,0,0 if we didn't find a proper player start
		BestStart = World->GetWorldSettings();
	}

	return BestStart;
}

AActor* ABSNGameModeBase::ChooseNoCharacterStartSpot(const TArray<APlayerStart *>& CandidatePlayerStarts)
{
	TArray<ABSNCharacter*> AliveCharacters;
	UWorld* World = GetWorld();

	for (TActorIterator<ABSNCharacter> It(World); It; ++It)
	{
		ABSNCharacter* Character = *It;
		AliveCharacters.Add(Character);
	}

	float Distance = 0.0f;
	APlayerStart* TargetStart = NULL;

	for (int idx = 0; idx < CandidatePlayerStarts.Num(); ++idx)
	{
		float TotalDistance = 0.0f;
		APlayerStart* Start = CandidatePlayerStarts[idx];

		for (int i = 0; i < AliveCharacters.Num(); ++i)
		{
			ABSNCharacter* Character = AliveCharacters[i];

			FVector StartLocation = Start->GetActorLocation();
			FVector CharacterLocation = Character->GetActorLocation();
			float TmpDistance = FMath::Abs(FVector::Dist(StartLocation, CharacterLocation));
			TotalDistance += TmpDistance;
		}

		float AvgDistance = TotalDistance / AliveCharacters.Num();
		if (AvgDistance > Distance)
		{
			Distance = AvgDistance;
			TargetStart = Start;
		}
	}

	return TargetStart;
}

APawn* ABSNGameModeBase::SpawnDefaultPawnFor_Implementation(AController* NewPlayer, class AActor* StartSpot)
{
	FString SpawnHeroName = BSNUtils::GetBSNGameInstance(this)->HeroName;

	ABSNPlayerState* BSNPlayerState = Cast<ABSNPlayerState>(NewPlayer->PlayerState);
	if (BSNPlayerState)
	{
		SpawnHeroName = BSNPlayerState->GetHeroName();
	}

	// don't allow pawn to be spawned with any pitch or roll
	FRotator StartRotation(ForceInit);
	StartRotation.Yaw = StartSpot->GetActorRotation().Yaw;
	FVector StartLocation = StartSpot->GetActorLocation();

	FActorSpawnParameters SpawnInfo;
	SpawnInfo.Instigator = Instigator;
	SpawnInfo.ObjectFlags |= RF_Transient;	// We never want to save default player pawns into a map
	SpawnInfo.bDeferConstruction = true;
	UClass* PawnClass = GetDefaultPawnClassForController(NewPlayer);

	FTransform PawnTransform;
	PawnTransform.SetRotation(StartRotation.Quaternion());
	PawnTransform.SetLocation(StartLocation);

	APawn* ResultPawn = GetWorld()->SpawnActor<APawn>(PawnClass, StartLocation, StartRotation, SpawnInfo);
	if (ResultPawn == NULL)
	{
		UE_LOG(LogGameMode, Warning, TEXT("Couldn't spawn Pawn of type %s at %s"), *GetNameSafe(PawnClass), *StartSpot->GetName());
	}

	ABSNCharacter* BSNCharacter = Cast<ABSNCharacter>(ResultPawn);
	if (BSNCharacter)
	{
		BSNCharacter->ChangeHero(SpawnHeroName);
	}

	if (ResultPawn)
		ResultPawn->FinishSpawning(PawnTransform, true);

	return ResultPawn;
}

UClass* ABSNGameModeBase::GetDefaultPawnClassForController_Implementation(AController* InController)
{
	if (InController->IsA<APlayerController>())
		return DefaultPawnClass;
	else
		return DefaultBotPawnClass;
}

class ABSNBotAIController* ABSNGameModeBase::SpawnBotAIController(FVector const& SpawnLocation, FRotator const& SpawnRotation)
{
	FActorSpawnParameters SpawnInfo;
	SpawnInfo.Instigator = Instigator;
	SpawnInfo.ObjectFlags |= RF_Transient;	// We never want to save player controllers into a map
	SpawnInfo.bDeferConstruction = true;
	ABSNBotAIController* NewAIC = GetWorld()->SpawnActor<ABSNBotAIController>(DefaultBotAIController, SpawnLocation, SpawnRotation, SpawnInfo);
	if (NewAIC)
	{
		UGameplayStatics::FinishSpawningActor(NewAIC, FTransform(SpawnRotation, SpawnLocation));
	}

	return NewAIC;
}

class ABSNBotAIController* ABSNGameModeBase::CreateBotAIController()
{
	ABSNBotAIController* BotAIController = SpawnBotAIController(FVector::ZeroVector, FRotator::ZeroRotator);

	InitBotAIController(BotAIController);

	if (BotAIController)
	{
		NumBots++;
	}

	return BotAIController;
}

void ABSNGameModeBase::InitBotAIController(class ABSNBotAIController* BotAIController)
{
	ABSNPlayerState* PlayerState = Cast<ABSNPlayerState>(BotAIController->PlayerState);
	if (PlayerState)
	{
		PlayerState->SetPlayerIndex(NumBots);
	}

	AActor* const StartSpot = FindPlayerStart(BotAIController);
	if (StartSpot != NULL)
	{
		// Set the player controller / camera in this new location
		FRotator InitialControllerRot = StartSpot->GetActorRotation();
		InitialControllerRot.Roll = 0.f;
		BotAIController->SetInitialLocationAndRotation(StartSpot->GetActorLocation(), InitialControllerRot);
		BotAIController->StartSpot = StartSpot;
	}
}

void ABSNGameModeBase::DestroyBot(class ABSNBotAIController* BotAIController)
{
	if (BotAIController)
	{
		APawn* BotPawn = BotAIController->GetPawn();
		if (BotPawn)
		{
			BotPawn->Destroy();
		}

		BotAIController->Destroy();

		NumBots--;
	}
}

void ABSNGameModeBase::StartBot(class ABSNBotAIController* BotAIController)
{
	if (BotAIController)
	{
		APawn* BotPawn = BotAIController->GetPawn();
		if (BotPawn)
		{
			BotPawn->Destroy();
		}
		BotAIController->Possess(nullptr);

		RestartPlayer(BotAIController);
	}
}

void ABSNGameModeBase::CreateDefaultBots()
{
	int32 BotCreatingNum = FMath::Clamp(MaxNumberPlayer - NumLoginPlayer, 0, FMath::Min(MaxNumberPlayer, MaxNumberBots));

	for (int32 i = 0; i < BotCreatingNum; ++i)
	{
		CreateBotAIController();
	}
}

void ABSNGameModeBase::StartBots()
{
	UWorld* World = GetWorld();
	for (FConstControllerIterator Iter = World->GetControllerIterator(); Iter; ++Iter)
	{
		ABSNBotAIController* BotAIController = Cast<ABSNBotAIController>(*Iter);
		if (BotAIController)
		{
			StartBot(BotAIController);
		}
	}
}

void ABSNGameModeBase::OnMatchStateSet()
{
	Super::OnMatchStateSet();

	if (MatchState == MatchState::InWaitingRoom)
	{
		HandleInWaitingRoom();
	}
	else if (MatchState == MatchState::WaitingToStart)
	{
		HandleMatchWaitToStart();
	}
}

void ABSNGameModeBase::HandleInWaitingRoom()
{
	GetWorldSettings()->NotifyBeginPlay();
}

void ABSNGameModeBase::HandleMatchHasStarted()
{
	GameSession->HandleMatchHasStarted();

	ABSNGameState* BSNGameState = GetGameState<ABSNGameState>();
	if (BSNGameState)
	{
		BSNGameState->SetGameMatchRemainingTime(DefaultGameMatchTime);
	}

	// start human players first
	for (FConstPlayerControllerIterator Iterator = GetWorld()->GetPlayerControllerIterator(); Iterator; ++Iterator)
	{
		APlayerController* PlayerController = *Iterator;
		if (PlayerCanRestart(PlayerController))
		{
			APawn* OldPawn = PlayerController->GetPawn();
			if (OldPawn)
			{
				OldPawn->Destroy();
			}
			PlayerController->Possess(nullptr);

			RestartPlayer(PlayerController);
		}
	}

	// Start bot if exists some BotAIControllers
	StartBots();

	SetCanStartNewPlayer(true);

	// Make sure level streaming is up to date before triggering NotifyMatchStarted
	GEngine->BlockTillLevelStreamingCompleted(GetWorld());

	// First fire BeginPlay, if we haven't already in waiting to start match
	GetWorldSettings()->NotifyBeginPlay();

	// Then fire off match started
	GetWorldSettings()->NotifyMatchStarted();

	// if passed in bug info, send player to right location
	const FString BugLocString = UGameplayStatics::ParseOption(OptionsString, TEXT("BugLoc"));
	const FString BugRotString = UGameplayStatics::ParseOption(OptionsString, TEXT("BugRot"));
	if (!BugLocString.IsEmpty() || !BugRotString.IsEmpty())
	{
		for (FConstPlayerControllerIterator Iterator = GetWorld()->GetPlayerControllerIterator(); Iterator; ++Iterator)
		{
			APlayerController* PlayerController = *Iterator;
			if (PlayerController->CheatManager != NULL)
			{
				PlayerController->CheatManager->BugItGoString(BugLocString, BugRotString);
			}
		}
	}

	if (IsHandlingReplays() && GetGameInstance() != nullptr)
	{
		GetGameInstance()->StartRecordingReplay(GetWorld()->GetMapName(), GetWorld()->GetMapName());
	}

	// Check if any actor with MatchGameInterface implemented. Call OnMatchStarted() function.
	for (TActorIterator<AActor> It(GetWorld()); It; ++It)
	{
		AActor* PA = (*It);
		if (PA && PA->Implements<UMatchGameInterface>())
		{
			IMatchGameInterface::Execute_OnMatchStarted(PA);
		}
	}
}

void ABSNGameModeBase::HandleMatchHasEnded()
{
	Super::HandleMatchHasEnded();

	ABSNGameState* BSNGameState = GetGameState<ABSNGameState>();
	if (BSNGameState)
	{
		BSNGameState->SetWaitToLeaveMapRemainingTime(WaitToLeaveMapTime);
	}
}

void ABSNGameModeBase::HandleMatchWaitToStart()
{
	for (FConstPlayerControllerIterator Iterator = GetWorld()->GetPlayerControllerIterator(); Iterator; ++Iterator)
	{
		APlayerController* PlayerController = *Iterator;
		if (PlayerCanRestart(PlayerController))
		{
			APawn* OldPawn = PlayerController->GetPawn();
			if (OldPawn)
			{
				OldPawn->Destroy();
			}

			PlayerController->Possess(nullptr);

			RestartPlayer(PlayerController);
		}
	}

	StartBots();

	ABSNGameState* BSNGameState = GetGameState<ABSNGameState>();
	if (BSNGameState)
	{
		BSNGameState->SetWaitTime(DefaultWaitToStartTime);
	}

	for (FConstPlayerControllerIterator Iterator = GetWorld()->GetPlayerControllerIterator(); Iterator; ++Iterator)
	{
		ABSNCharacter *pChar = Cast<ABSNCharacter>(Iterator->Get()->GetPawn());
		if (pChar != NULL)
		{
			pChar->ClientStartWait(DefaultWaitToStartTime);
		}
	}

	SetCanStartNewPlayer(true);
}

bool ABSNGameModeBase::ReadyToStartMatch_Implementation()
{
	// If bDelayed Start is set, wait for a manual match start
	if (bDelayedStart)
	{
		return false;
	}

	if (GetMatchState() == MatchState::WaitingToStart)
	{
		ABSNGameState* BSNGameState = GetGameState<ABSNGameState>();
		if (BSNGameState)
		{
			if (BSNGameState->GetWaitTime() <= 0)
			{
				return true;
			}
		}
	}

	return false;
}

void ABSNGameModeBase::CheckAndLoadWaitingRoom()
{
	if (!bWaitingRoomMapLoadExcuted && bShouldLoadWaitingRoom)
	{
		LoadWaitingRoom();
	}
}

void ABSNGameModeBase::EnterGameLevel()
{
	SetCanStartNewPlayer(false);

	BSNUtils::UnloadStreamLevel(this, WaitingRoomSubLevelName);

	for (FConstPlayerControllerIterator Iterator = GetWorld()->GetPlayerControllerIterator(); Iterator; ++Iterator)
	{
		APlayerController* PlayerController = *Iterator;
		APawn* OldPawn = PlayerController->GetPawn();
		if (OldPawn)
		{
			OldPawn->Destroy();
		}
		PlayerController->Possess(nullptr);
	}

	if (UWorld* World = GetWorld())
	{
		ALevelScriptActor* LevelScriptActor = World->GetLevelScriptActor();
		bool bNeedLoadGameSubLevel = false;

		if (LevelScriptActor && LevelScriptActor->Implements<ULevelScriptGameInterface>())
		{
			GameSubLevelNames.Empty();
			ILevelScriptGameInterface::Execute_GetGameMapNames(LevelScriptActor, GameSubLevelNames);
			if (GameSubLevelNames.Num() > 0)
			{
				GameSubLevelLoadedArray.Init(false, GameSubLevelNames.Num());

				for (auto& SubLevelName : GameSubLevelNames)
				{
					BSNUtils::LoadStreamLevel(this, SubLevelName, true, false, FBSNLevelStreamingActionComplete::CreateUObject(this, &ABSNGameModeBase::HandleGameLevelLoadComplete, SubLevelName));
				}

				bNeedLoadGameSubLevel = true;
			}
		}

		if (!bNeedLoadGameSubLevel)
		{
			SetMatchState(MatchState::WaitingToStart);
		}
	}
}

void ABSNGameModeBase::HandleGameLevelLoadComplete(FName SubLevelName)
{
	for (int32 i = 0; i < GameSubLevelNames.Num(); ++i)
	{
		if (GameSubLevelNames[i] == SubLevelName)
		{
			GameSubLevelLoadedArray.SetRange(i, 1, true);
			break;
		}
	}

	bool bAllGameSubLevelLoaded = true;
	for (int32 i = 0; i < GameSubLevelNames.Num(); ++i)
	{
		if (!GameSubLevelLoadedArray[i])
		{
			bAllGameSubLevelLoaded = false;
		}
	}

	if (bAllGameSubLevelLoaded)
	{
		SetMatchState(MatchState::WaitingToStart);
	}
}

void ABSNGameModeBase::SetCanStartNewPlayer(bool bInCanStartNewPlayer)
{
	bCanStartNewPlayer = bInCanStartNewPlayer;
}

TSubclassOf<AGameSession> ABSNGameModeBase::GetGameSessionClass() const
{
	return ABSNGameSession::StaticClass();
}

void ABSNGameModeBase::FinishGame()
{
	EndMatch();
	OnFinishGame();
}

void ABSNGameModeBase::OnFinishGame()
{
	for (FConstControllerIterator It = GetWorld()->GetControllerIterator(); It; ++It)
	{
		ABSNPlayerController *PlayerController = Cast<ABSNPlayerController>(*It);
		if (PlayerController != NULL)
		{
			PlayerController->ClientReturnToMainMenu(TEXT(""));
		}
	}

	GEngine->SetClientTravel(GetWorld(), *ServiceMap, TRAVEL_Absolute);
}

void ABSNGameModeBase::QuickStart()
{
	if (bStartEnterMatchTick)
	{
		ABSNGameState* BSNGameState = GetGameState<ABSNGameState>();
		if (BSNGameState)
		{
			if (BSNGameState->GetRemainingEnterMatchWaitTime() > DefaultCreateBotsRemainingTime && !bBotsPreCreated)
			{
				BSNGameState->SetRemainingEnterMatchWaitTime(DefaultCreateBotsRemainingTime);
			}
		}
	}
}

void ABSNGameModeBase::AddBot()
{
	if (IsMatchInProgress() || IsMatchWaitingToStart())
	{
		if ((NumBots + NumLoginPlayer) < MaxNumberPlayer)
		{
			ABSNBotAIController* BotAIController = CreateBotAIController();
			StartBot(BotAIController);
		}
	}
}

void ABSNGameModeBase::RemoveBot()
{
	if (IsMatchInProgress() || IsMatchWaitingToStart())
	{
		if (NumBots > 0)
		{
			UWorld* World = GetWorld();
			if (World)
			{
				for (FConstControllerIterator Iter = World->GetControllerIterator(); Iter; ++Iter)
				{
					ABSNBotAIController* BotAIController = Cast<ABSNBotAIController>(*Iter);
					if (BotAIController)
					{
						ABSNPlayerState* PlayerState = Cast<ABSNPlayerState>(BotAIController->PlayerState);
						if (PlayerState)
						{
							if (PlayerState->GetPlayerIndex() == (NumBots - 1))
							{
								DestroyBot(BotAIController);
								break;
							}
						}
					}
				}
			}
		}
	}
}