#pragma once

#include "GameFramework/GameMode.h"
#include "BSNGameModeBase.generated.h"

namespace MatchState
{
	extern const FName InWaitingRoom;
}

UCLASS(Config = Game, notplaceable, BlueprintType, Blueprintable, Transient)
class ABSNGameModeBase : public AGameMode
{
	GENERATED_BODY()

public:
	ABSNGameModeBase(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());

	virtual void StartPlay() override;

	virtual void StartMatch() override;

	virtual bool HasMatchStarted() const override;

	UFUNCTION(BlueprintCallable, Category = "Game")
	virtual bool IsMatchInWaitingRoom() const;

	UFUNCTION(BlueprintCallable, Category = "Game")
	virtual bool IsMatchWaitingToStart() const;

	UFUNCTION(BlueprintCallable, Category = "Game")
	virtual bool IsWaitingPostMatch() const;

	// Invincible reset
	void HandleInvicibleTimeUp(TWeakObjectPtr<class ABSNCharacter> BSNCharacter);

	virtual void Tick(float DeltaSeconds) override;

	/** Accept or reject a player attempting to join the server.  Fails login if you set the ErrorMessage to a non-empty string. */
	virtual void PreLogin(const FString& Options, const FString& Address, const TSharedPtr<const FUniqueNetId>& UniqueId, FString& ErrorMessage) override;

	virtual APlayerController* Login(class UPlayer* NewPlayer, ENetRole InRemoteRole, const FString& Portal, const FString& Options, const TSharedPtr<const FUniqueNetId>& UniqueId, FString& ErrorMessage) override;

	void CustomLoginProcess(class UPlayer* NewPlayer, ENetRole InRemoteRole, const FString& Portal, const FString& Options, const TSharedPtr<const FUniqueNetId>& UniqueId, FString& ErrorMessage, APlayerController* NewPlayerController);

	void PostLogin(APlayerController* NewPlayer) override;

	virtual void Logout(AController* Exiting) override;

	virtual void RestartPlayer(class AController* NewPlayer) override;

	virtual void PostRestartPlayer(class AController* NewPlayer);

	virtual void PostInitBotPlayer(class ABSNBotAIController* BotPlayer);

	virtual bool PlayerCanRestart_Implementation(APlayerController* Player) override;

	AActor* FindPlayerStart_Implementation(AController* Player, const FString& IncomingName) override;

	AActor* ChooseNoCharacterStartSpot(const TArray<APlayerStart *>& CandidatePlayerStarts);

	virtual APawn* SpawnDefaultPawnFor_Implementation(AController* NewPlayer, class AActor* StartSpot) override;

	virtual UClass* GetDefaultPawnClassForController_Implementation(AController* InController) override;

	// Bot Related
	UFUNCTION(BlueprintCallable, Category = Bot)
	virtual class ABSNBotAIController* SpawnBotAIController(FVector const& SpawnLocation, FRotator const& SpawnRotation);

	UFUNCTION(BlueprintCallable, Category = Bot)
	virtual class ABSNBotAIController* CreateBotAIController();

	UFUNCTION(BlueprintCallable, Category = Bot)
	virtual void InitBotAIController(class ABSNBotAIController* BotAIController);

	UFUNCTION(BlueprintCallable, Category = Bot)
	virtual void DestroyBot(class ABSNBotAIController* BotAIController);

	UFUNCTION(BlueprintCallable, Category = Bot)
	virtual void StartBot(class ABSNBotAIController* BotAIController);

	UFUNCTION(BlueprintCallable, Category = Bot)
	virtual void CreateDefaultBots();

	UFUNCTION(BlueprintCallable, Category = Bot)
	virtual void StartBots();

	//Map
	UFUNCTION(BlueprintCallable, Category = "Map")
	virtual void LoadWaitingRoom();

	UFUNCTION(BlueprintCallable, Category = "Map")
	virtual void SetShouldLoadWaitingRoom(bool bShould);

	void HandleLoadWaitingRoomComplete();

	void EnterGameLevel();

	void HandleGameLevelLoadComplete(FName SubLevelName);

	void SetCanStartNewPlayer(bool bInCanStartNewPlayer);

	UFUNCTION(BlueprintCallable, BlueprintNativeEvent, Category = "Map", meta = (DisplayName = "OnLoadWaitingRoomComplete"))
	void K2_LoadWaitingRoomCompleted();

	virtual void K2_LoadWaitingRoomCompleted_Implementation();

	// Game
	virtual void Killed(AController* Killer, AController* KilledPlayer, APawn* KilledPawn, const UDamageType* DamageType);

	virtual void OnKilled(AController* Killer, AController* KilledPlayer, APawn* KilledPawn, const UDamageType* DamageType);

	virtual bool CanDamage(AController* Instigator, AController* DamagedPlayer, AActor* DamageCauser);

	virtual bool IsGameEnding() const { return bGameEnding; }

	virtual void StartNewPlayer(APlayerController* NewPlayer) override;

	virtual void StartPlayerRespawnProcess(class AController* InController);

	virtual bool CanPlayerRespawn(class AController* InController) const;

	UFUNCTION(BlueprintCallable, Category = Spawn)
	void RespawnPlayer(class AController* InController);

	virtual void OnRespawnPlayer(class AController* InController);

	const FName &GetDefaultWaitingRoomMap() { return DefaultWaitingRoomMapName; }

	void FinishGame();
	//////////////////////////////////////////////////////////////////////////
protected:
	virtual TSubclassOf<AGameSession> GetGameSessionClass() const override;
	virtual void OnMatchStateSet() override;
	virtual void HandleInWaitingRoom();

	/** Called when the state transitions to InProgress */
	virtual void HandleMatchHasStarted() override;

	virtual void HandleMatchHasEnded() override;

	virtual void HandleMatchWaitToStart();

	virtual bool ReadyToStartMatch_Implementation() override;

	void CheckAndLoadWaitingRoom();

	void OnFinishGame();

public:
	UFUNCTION(BlueprintCallable, Category = "DEBUG")
	void QuickStart();

	UFUNCTION(BlueprintCallable, Category = "DEBUG")
	void AddBot();

	UFUNCTION(BlueprintCallable, Category = "DEBUG")
	void RemoveBot();

protected:
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Map")
	FName DefaultWaitingRoomMapName;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = Classes)
	TSubclassOf<class APawn> DefaultBotPawnClass;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = Classes)
	TSubclassOf<class ABSNBotAIController> DefaultBotAIController;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Map")
	uint32 bShouldLoadWaitingRoom : 1;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Map")
	FName WaitingRoomSubLevelName;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Map")
	TArray<FName> GameSubLevelNames;

	TBitArray<> GameSubLevelLoadedArray;

	// Excuted loadstreamlevel
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Map")
	uint32 bWaitingRoomMapLoadExcuted : 1;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Game)
	uint32 bGameEnding : 1;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = Game)
	float DefaultCreateBotsRemainingTime;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = Game)
	float DefaultWaitToStartTime;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = Game)
	float DefaultEnterMatchWaitTime;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = Game)
	float DefaultGameMatchTime;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = Game)
	float WaitToLeaveMapTime;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = Game)
	float InvincibleTimeWhenSpawn;

	UPROPERTY(VisibleInstanceOnly, BlueprintReadOnly, Category = Game)
	bool bBotsPreCreated;

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = Game)
	bool bStartEnterMatchTick;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Game)
	bool bCanStartNewPlayer;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Game)
	int32 NumLoginPlayer;

	FString ServiceMap;
public:
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Game)
	int32	MaxNumberPlayer;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Game)
	int32 MaxNumberBots;
};
