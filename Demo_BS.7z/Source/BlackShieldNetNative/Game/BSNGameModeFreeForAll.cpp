#include "BlackShieldNetNative.h"
#include "BSNGameModeFreeForAll.h"
#include "BlackShieldUtilityFunctions.h"
#include "BlackShieldGameInstance.h"
#include "Game/BSNGameState.h"
#include "Weapon/BSNGun.h"
#include "Game/BSNPlayerState.h"

ABSNGameModeFreeForAll::ABSNGameModeFreeForAll(const FObjectInitializer& ObjectInitialzier /*= FObjectInitializer::Get()*/)
	: Super(ObjectInitialzier)
{
	KillCountVictory = 20;
}

void ABSNGameModeFreeForAll::OnKilled(AController* Killer, AController* KilledPlayer, APawn* KilledPawn, const UDamageType* DamageType)
{
	ABSNPlayerState* KillerPlayerState = Killer ? Cast<ABSNPlayerState>(Killer->PlayerState) : nullptr;

	if (KillerPlayerState)
	{
		if (KillerPlayerState->GetKillCount() >= KillCountVictory)
		{
			OnVictory(Killer);
		}
		else
		{
			ABSNPlayerController *DeadPlayer = Cast<ABSNPlayerController>(KilledPlayer);
			ABSNPlayerController *KillerPlayer = Cast<ABSNPlayerController>(Killer);
			if (DeadPlayer != NULL && CanPlayerRespawn(DeadPlayer))
			{
				FString PlayerName = TEXT("Player");
				if (KillerPlayer && KillerPlayer->PlayerState)
				{
					PlayerName = KillerPlayer->PlayerState->PlayerName;
				}

				DeadPlayer->ClientStartRespawnEffect(PlayerName, MinRespawnDelay);
			}
		}

		FString KillerPlayerName = KillerPlayerState->PlayerName;
		FString KilledPlayerName = KilledPlayer->PlayerState->PlayerName;

		for (FConstPlayerControllerIterator It(GetWorld()->GetPlayerControllerIterator()); It; ++It)
		{
			APlayerController *RemotePC = *It;
			if (RemotePC->GetRemoteRole() == ROLE_None)
			{
				continue;
			}

			ABSNPlayerState *PlayerState = Cast<ABSNPlayerState>(RemotePC->PlayerState);
			if (PlayerState != NULL)
			{
				PlayerState->ClientAddKillMessage(KillerPlayerName, KilledPlayerName, int8(EGunType::MachineGun));
			}
		}
	}
}

void ABSNGameModeFreeForAll::OnVictory(AController* Winner)
{
	EndMatch();
}

