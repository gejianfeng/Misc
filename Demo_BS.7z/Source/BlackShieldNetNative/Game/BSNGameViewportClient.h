#pragma once

#include "BlackShieldCommons.h"
#include "SlateDelegates.h"
#include "BSNGameViewportClient.generated.h"

class SConfirmationDialog;

UCLASS(Within=Engine, Transient, config = Engine)
class UBSNGameViewportClient : public UGameViewportClient
{
	GENERATED_UCLASS_BODY()
public:
	void ShowDialog(TWeakObjectPtr<ULocalPlayer> PlayerOwner, EDialogType DialogType, const FText &Message, const FText &Confirm, const FText &Cancle, const FOnClicked &OnConfirm, const FOnClicked &OnCancel);
	void HideDialog();
	bool IsShowingDialog() const { return DialogWidget.IsValid(); }
	EDialogType GetDialogType() const;
	TWeakObjectPtr<ULocalPlayer> GetDialogOwner() const;
	void ShowScoreRank();
	void HideScoreRank();
protected:
	TSharedPtr<class SWidget >			OldFocusWidget;
	TSharedPtr<SConfirmationDialog>		DialogWidget;
	TSharedPtr<class SScoreRank>		ScoreRankWidget;
};

