#include "BlackShieldNetNative.h"
#include "BSNLevelStreamingHelper.h"
#include "Engine/CoreSettings.h"

FBSNLevelStreamingHelper::FBSNLevelStreamingHelper()
{

}

void FBSNLevelStreamingHelper::AddLevelStreamingAction(FBSNLevelStreamingAction* InAction)
{
	LevelStreamingActions.Add(TSharedPtr<FBSNLevelStreamingAction>(InAction));
}

void FBSNLevelStreamingHelper::Tick(float DeltaTime)
{
	TArray<TSharedPtr<FBSNLevelStreamingAction>> CompletedActions;

	for (auto& Action : LevelStreamingActions)
	{
		bool bComplete = false;
		Action->UpdateAction(bComplete);

		if (bComplete)
		{
			CompletedActions.Add(Action);
		}
	}

	for (auto& Action : CompletedActions)
	{
		Action->CompleteDelegate.ExecuteIfBound();
		LevelStreamingActions.Remove(Action);
	}
}

FBSNLevelStreamingAction::FBSNLevelStreamingAction(bool bIsLoading, const FName& InLevelName, bool bIsMakeVisibleAfterLoad, bool bIsShouldBlockOnLoad, const FBSNLevelStreamingActionComplete& InDelegate, UWorld* World)
	: bLoading(bIsLoading)
	, LevelName(InLevelName)
	, bMakeVisibleAfterLoad(bIsMakeVisibleAfterLoad)
	, bShouldBlockOnLoad(bIsShouldBlockOnLoad)
	, CompleteDelegate(InDelegate)
{
	Level = FindAndCacheLevelStreamingObject(LevelName, World);
	ActivateLevel(Level);
}

void FBSNLevelStreamingAction::UpdateAction(bool& bComplete)
{
	bComplete = UpdateLevel(Level);
}

ULevelStreaming* FBSNLevelStreamingAction::FindAndCacheLevelStreamingObject(const FName LevelName, UWorld* InWorld)
{
	// Search for the level object by name.
	if (LevelName != NAME_None)
	{
		const FString SearchPackageName = MakeSafeLevelName(LevelName, InWorld);

		for (ULevelStreaming* LevelStreaming : InWorld->StreamingLevels)
		{
			// We check only suffix of package name, to handle situations when packages were saved for play into a temporary folder
			// Like Saved/Autosaves/PackageName
			if (LevelStreaming &&
				LevelStreaming->GetWorldAssetPackageName().EndsWith(SearchPackageName, ESearchCase::IgnoreCase))
			{
				return LevelStreaming;
			}
		}
	}

	return NULL;
}

void FBSNLevelStreamingAction::ActivateLevel(ULevelStreaming* LevelStreamingObject)
{
	if (LevelStreamingObject != NULL)
	{
		// Loading.
		if (bLoading)
		{
			UE_LOG(LogStreaming, Log, TEXT("Streaming in level %s (%s)..."), *LevelStreamingObject->GetName(), *LevelStreamingObject->GetWorldAssetPackageName());
			LevelStreamingObject->bShouldBeLoaded = true;
			LevelStreamingObject->bShouldBeVisible |= bMakeVisibleAfterLoad;
			LevelStreamingObject->bShouldBlockOnLoad = bShouldBlockOnLoad;
		}
		// Unloading.
		else
		{
			UE_LOG(LogStreaming, Log, TEXT("Streaming out level %s (%s)..."), *LevelStreamingObject->GetName(), *LevelStreamingObject->GetWorldAssetPackageName());
			LevelStreamingObject->bShouldBeLoaded = false;
			LevelStreamingObject->bShouldBeVisible = false;
		}

		UWorld* LevelWorld = CastChecked<UWorld>(LevelStreamingObject->GetOuter());
		// If we have a valid world
		if (LevelWorld)
		{
			// Notify players of the change
			for (FConstPlayerControllerIterator Iterator = LevelWorld->GetPlayerControllerIterator(); Iterator; ++Iterator)
			{
				APlayerController* PlayerController = *Iterator;

				UE_LOG(LogLevel, Log, TEXT("ActivateLevel %s %i %i %i"),
					*LevelStreamingObject->GetWorldAssetPackageName(),
					LevelStreamingObject->bShouldBeLoaded,
					LevelStreamingObject->bShouldBeVisible,
					LevelStreamingObject->bShouldBlockOnLoad);



				PlayerController->LevelStreamingStatusChanged(
					LevelStreamingObject,
					LevelStreamingObject->bShouldBeLoaded,
					LevelStreamingObject->bShouldBeVisible,
					LevelStreamingObject->bShouldBlockOnLoad,
					INDEX_NONE);

			}
		}
	}
	else
	{
		UE_LOG(LogLevel, Warning, TEXT("Failed to find streaming level object associated with '%s'"), *LevelName.ToString());
	}
}

FString FBSNLevelStreamingAction::MakeSafeLevelName(const FName& InLevelName, UWorld* InWorld)
{
	// Special case for PIE, the PackageName gets mangled.
	if (!InWorld->StreamingLevelsPrefix.IsEmpty())
	{
		FString PackageName = InWorld->StreamingLevelsPrefix + FPackageName::GetShortName(InLevelName);
		if (!FPackageName::IsShortPackageName(InLevelName))
		{
			PackageName = FPackageName::GetLongPackagePath(InLevelName.ToString()) + TEXT("/") + PackageName;
		}

		return PackageName;
	}

	return InLevelName.ToString();
}

bool FBSNLevelStreamingAction::UpdateLevel(ULevelStreaming* LevelStreamingObject)
{
	// No level streaming object associated with this sequence.
	if (LevelStreamingObject == NULL)
	{
		return true;
	}
	// Level is neither loaded nor should it be so we finished (in the sense that we have a pending GC request) unloading.
	else if ((LevelStreamingObject->GetLoadedLevel() == NULL) && !LevelStreamingObject->bShouldBeLoaded)
	{
		return true;
	}
	// Level shouldn't be loaded but is as background level streaming is enabled so we need to fire finished event regardless.
	else if (LevelStreamingObject->GetLoadedLevel() && !LevelStreamingObject->bShouldBeLoaded && !GUseBackgroundLevelStreaming)
	{
		return true;
	}
	// Level is both loaded and wanted so we finished loading.
	else if (LevelStreamingObject->GetLoadedLevel() && LevelStreamingObject->bShouldBeLoaded
		// Make sure we are visible if we are required to be so.
		&& (!bMakeVisibleAfterLoad || LevelStreamingObject->GetLoadedLevel()->bIsVisible))
	{
		return true;
	}

	// Loading/ unloading in progress.
	return false;
}
