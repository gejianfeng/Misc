
#pragma once
#define AUTHORITY_SERVER_URL TEXT("http://114.55.105.227")
#define GAME_VERSION TEXT("BlackShieldNet")
#define AES_KEY "Sinceme_BlackShield_20160830shen"
