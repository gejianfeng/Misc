#include "BlackShieldNetNative.h"
#include "BlackShieldSingleton.h"

UBlackShieldSingleton::UBlackShieldSingleton()
{

}

