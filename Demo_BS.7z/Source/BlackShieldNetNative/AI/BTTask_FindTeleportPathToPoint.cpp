// Fill out your copyright notice in the Description page of Project Settings.

#include "BlackShieldNetNative.h"
#include "BTTask_FindTeleportPathToPoint.h"
#include "AIController.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "AI/Navigation/NavigationPath.h"

EBTNodeResult::Type UBTTask_FindTeleportPathToPoint::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	AAIController* MyController = Cast<AAIController>(OwnerComp.GetAIOwner());
	if (MyController == NULL)
	{
		return EBTNodeResult::Failed;
	}

	const FVector PathStartPoint = MyController->GetPawn()->GetActorLocation();

	UBlackboardComponent* BlackboardComp = OwnerComp.GetBlackboardComponent();
	if (BlackboardComp == NULL)
	{
		return EBTNodeResult::Failed;
	}

	const FVector PathEndPoint = BlackboardComp->GetValueAsVector(TargetPoint.SelectedKeyName);

	UNavigationPath* Path = UNavigationSystem::FindPathToLocationSynchronously(MyController, PathStartPoint, PathEndPoint);

	if (Path && Path->IsValid() && Path->GetPath()->IsValid() && !Path->IsPartial())
	{
		auto Points = Path->GetPath()->GetPathPoints();

		if (IsDebug)
		{
			for (int32 Idx = 0; Idx < Points.Num(); Idx++)
			{
				FColor DebugColor = FLinearColor(0.8, 0.7, 0.2, 0.8).ToRGBE();
				DrawDebugSphere(GetWorld(), Points[Idx].Location, 20, 8, DebugColor);
			}
		}

		if (Points.Num() >= 2)
		{
			BlackboardComp->SetValueAsVector(Destination.SelectedKeyName, Points[1].Location);
			return EBTNodeResult::Succeeded;
		}
		else
		{
			return EBTNodeResult::Failed;
		}
	}

	return EBTNodeResult::Failed;
}


