// Fill out your copyright notice in the Description page of Project Settings.

#include "BlackShieldNetNative.h"
#include "BSNBotAIController.h"
#include "Player/BSNCharacterBot.h"

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

FBotAIDifficultyDataRow::FBotAIDifficultyDataRow()
{
	FireMissRate = 60;
	WaitTime = 5;
	LowHpRate = 0.3;
	EnemySearchRange = 500;
	PropSearchRange = 500;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

ABSNBotAIController::ABSNBotAIController(const FObjectInitializer& ObjectInitializer /*= FObjectInitializer::Get()*/)
	: Super(ObjectInitializer)
{
	bWantsPlayerState = true;
}

void ABSNBotAIController::StartRunBehaviorTree()
{
	GetRandomAIDifficultyType();
	InitAIAttributes();
	OnStartRunBehaviorTree();
}

void ABSNBotAIController::GetRandomAIDifficultyType()
{
	int RandVal = FMath::RandRange(0, 100);

	if (RandVal < 70)
	{
		ConfigName = FName("Easy");
	}
	else if (RandVal < 90)
	{
		ConfigName = FName("Normal");
	}
	else 
	{
		ConfigName = FName("Hard");
	}
}

void ABSNBotAIController::InitAIAttributes()
{
	Config = *GetRow(ConfigName);

	LowHpRate = Config.LowHpRate;
	FireMissRate = Config.FireMissRate;
	WaitTime = Config.WaitTime;
	EnemySearchRange = Config.EnemySearchRange;
	PropSearchRange = Config.PropSearchRange;
}

FBotAIDifficultyDataRow* ABSNBotAIController::GetRow(FName& name)
{
	UDataTable *pConfigTable = (UDataTable *)StaticLoadObject(UDataTable::StaticClass(), NULL, TEXT("DataTable'/Game/BlackShieldNew/Table/DT_BotAI.DT_BotAI'"));
	if (pConfigTable != NULL)
	{
		FBotAIDifficultyDataRow *pConfigData = pConfigTable->FindRow<FBotAIDifficultyDataRow>(name, TEXT(""));
		return pConfigData;
	}
	return NULL;
}

float ABSNBotAIController::GetFireMissRate() const
{
	return FireMissRate;
}