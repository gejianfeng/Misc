// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "BehaviorTree/Tasks/BTTask_BlueprintBase.h"
#include "BTTask_FindTeleportPathToPoint.generated.h"

/**
 * 
 */
UCLASS()
class UBTTask_FindTeleportPathToPoint : public UBTTask_BlueprintBase
{
	GENERATED_BODY()
	
	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;
	
private:

	UPROPERTY(EditAnywhere)
	struct FBlackboardKeySelector TargetPoint;

	UPROPERTY(EditAnywhere)
	struct FBlackboardKeySelector Destination;

	UPROPERTY(EditAnywhere)
	bool IsDebug;

};
