// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "AIController.h"
#include "AI/Navigation/RecastNavMesh.h"
#include "BSNBotAIController.generated.h"

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

USTRUCT(BlueprintType)
struct FBotAIDifficultyDataRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

public:
	FBotAIDifficultyDataRow();

	UPROPERTY(EditAnywhere, Category = Default)
		float		FireMissRate;

	UPROPERTY(EditAnywhere, Category = Default)
		float		WaitTime;

	UPROPERTY(EditAnywhere, Category = Default)
		float		LowHpRate;

	UPROPERTY(EditAnywhere, Category = Default)
		float		EnemySearchRange;

	UPROPERTY(EditAnywhere, Category = Default)
		float		PropSearchRange;
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/**
 * 
 */
UCLASS(BlueprintType, Abstract)
class BLACKSHIELDNETNATIVE_API ABSNBotAIController : public AAIController
{
	GENERATED_BODY()
	
public:
	ABSNBotAIController(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());

	virtual void StartRunBehaviorTree();

	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = AIController)
	void OnStartRunBehaviorTree();

	void GetRandomAIDifficultyType();
	void InitAIAttributes();
	FBotAIDifficultyDataRow* GetRow(FName& name);
	
	float GetFireMissRate() const;

protected:
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = Default)
	FName	ConfigName;

	UPROPERTY(EditDefaultsOnly, Category = Config)
	FBotAIDifficultyDataRow	Config;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = Config)
	float	LowHpRate;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = Config)
	float	FireMissRate;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = Config)
	float	WaitTime;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = Config)
	float	EnemySearchRange;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = Config)
	float	PropSearchRange;
};
