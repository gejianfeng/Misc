// Fill out your copyright notice in the Description page of Project Settings.

#include "BlackShieldNetNative.h"
#include "AIController.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "AI/Navigation/NavigationPath.h"
#include "BTTask_FindTeleportPath.h"

EBTNodeResult::Type UBTTask_FindTeleportPath::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	AAIController* MyController = Cast<AAIController>(OwnerComp.GetAIOwner());
	if (MyController == NULL)
	{
		return EBTNodeResult::Failed;
	}

	const FVector PathStartPoint = MyController->GetPawn()->GetActorLocation();

	UBlackboardComponent* BlackboardComp = OwnerComp.GetBlackboardComponent();
	if (BlackboardComp == NULL)
	{
		return EBTNodeResult::Failed;
	}

	ACharacter* EnemyCharacter = Cast<ACharacter>(BlackboardComp->GetValueAsObject(Enemy.SelectedKeyName));
	if (EnemyCharacter == NULL)
	{
		return EBTNodeResult::Failed;
	}

	const FVector PathEndPoint = EnemyCharacter->GetActorLocation();

	// Try to teleport to point in front of target character.

	const FVector TargetForwardVector = EnemyCharacter->GetActorForwardVector();
	FVector TempPoint = PathEndPoint + TargetForwardVector * 400.0f;
	FVector TryEndPoint = UNavigationSystem::GetRandomPointInNavigableRadius(MyController, TempPoint, 100);
	
	UNavigationPath* TryPath = UNavigationSystem::FindPathToLocationSynchronously(MyController, PathStartPoint, TryEndPoint);
	if (TryPath && TryPath->IsValid() && TryPath->GetPath()->IsValid() && !TryPath->IsPartial())
	{
		auto Points = TryPath->GetPath()->GetPathPoints();

		if (IsDebug)
		{
			for (int32 Idx = 0; Idx < Points.Num(); Idx++)
			{
				FColor DebugColor = FLinearColor(0.8, 0.7, 0.2, 0.8).ToRGBE();
				DrawDebugSphere(GetWorld(), Points[Idx].Location, 20, 8, DebugColor, false, 10);
			}
		}

		if (Points.Num() > 2)
		{
			BlackboardComp->SetValueAsVector(Destination.SelectedKeyName, Points[1].Location);
			return EBTNodeResult::Succeeded;
		}
		else if (Points.Num() == 1)
		{
			BlackboardComp->SetValueAsVector(Destination.SelectedKeyName, TryEndPoint);
			return EBTNodeResult::Succeeded;
		}
	}

	UNavigationPath* Path = UNavigationSystem::FindPathToLocationSynchronously(MyController, PathStartPoint, PathEndPoint);

	if (Path && Path->IsValid() && Path->GetPath()->IsValid() && !Path->IsPartial())
	{
		auto Points = Path->GetPath()->GetPathPoints();

		if (IsDebug)
		{
			for (int32 Idx = 0; Idx < Points.Num(); Idx++)
			{
				FColor DebugColor = FLinearColor(0.8, 0.7, 0.2, 0.8).ToRGBE();
				DrawDebugSphere(GetWorld(), Points[Idx].Location, 20, 8, DebugColor, false, 10);
			}
		}

		if (Points.Num() > 2)
		{
			BlackboardComp->SetValueAsVector(Destination.SelectedKeyName, Points[1].Location);
		}
		else
		{
			const float SearchRadius = 200.0f;
			const FVector SearchOrigin = PathEndPoint + 400.0f * (PathStartPoint - PathEndPoint).GetSafeNormal();
			FVector Loc = FVector::ZeroVector;

			if (PathStartPoint.Equals(PathEndPoint))
			{
				Loc = UNavigationSystem::GetRandomPointInNavigableRadius(MyController, SearchOrigin, SearchRadius);
			}
			else
			{
				Loc = UNavigationSystem::GetRandomReachablePointInRadius(MyController, SearchOrigin, SearchRadius);
			}

			if (Loc != FVector::ZeroVector)
			{
				BlackboardComp->SetValueAsVector(Destination.SelectedKeyName, Loc);
			}

			if (IsDebug)
			{
				FColor DebugColor = FLinearColor(0.3, 0.7, 0.2, 0.8).ToRGBE();
				DrawDebugSphere(GetWorld(), Loc, 20, 8, DebugColor, false, 10);
			}

		}

		return EBTNodeResult::Succeeded;
	}

	return EBTNodeResult::Failed;
}
