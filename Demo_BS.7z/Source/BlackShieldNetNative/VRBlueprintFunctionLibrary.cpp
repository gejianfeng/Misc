// Fill out your copyright notice in the Description page of Project Settings.


#include "BlackShieldNetNative.h"
#include "VRBlueprintFunctionLibrary.h"
#include "SynthBenchmark.h"
#include "BlackShieldNetNativeModule.h"
#include "VRGameUserSettings.h"

EBSInputType UVRBlueprintFunctionLibrary::GetInputType()
{
	if (g_BlackShieldNetNativeModule)
	{
		g_BlackShieldNetNativeModule->GetConfig().InputType;
	}

	return EBSInputType::Keyboard;
}

UObject* UVRBlueprintFunctionLibrary::LoadAssetSync(UObject* WorldContextObject, const TAssetPtr<UObject>& Asset)
{
	TAssetPtr<UObject>& AssetPtr = const_cast<TAssetPtr<UObject>&>(Asset);
	return AssetPtr.LoadSynchronous();
}

void UVRBlueprintFunctionLibrary::ComputeCPUGPUPerfIndex(float& CPUIndex, float& GPUIndex)
{
	FSynthBenchmarkResults SynthBenchmark;
	ISynthBenchmark::Get().Run(SynthBenchmark, true, 10U);

	CPUIndex = SynthBenchmark.ComputeCPUPerfIndex();
	GPUIndex = SynthBenchmark.ComputeGPUPerfIndex();
}

bool UVRBlueprintFunctionLibrary::FileSaveString(FString SaveTextB, FString FileNameB)
{
	return FFileHelper::SaveStringToFile(SaveTextB, *(FPaths::GameDir() + FileNameB));
}

bool UVRBlueprintFunctionLibrary::FileLoadString(FString FileNameA, FString& SaveTextA)
{
	return FFileHelper::LoadFileToString(SaveTextA, *(FPaths::GameDir() + FileNameA));
}


int32 UVRBlueprintFunctionLibrary::GetLocalizationType()
{
	int32 localType = 0;
	//UVRGameUserSettings* UserSetting = Cast<UVRGameUserSettings>(GEngine->GetGameUserSettings());
	//if (UserSetting != nullptr)
	//{
	//	localType = UserSetting->LocalizationType;
	//}
	return localType;
}


void UVRBlueprintFunctionLibrary::SetLocalizationType(const int32 LocalType)
{
	//if (LocalType < 0)
	//{
	//	return;
	//}
	//UVRGameUserSettings* UserSetting = Cast<UVRGameUserSettings>(GEngine->GetGameUserSettings());
	//if (UserSetting != nullptr)
	//{
	//	UserSetting->LocalizationType = LocalType;
	//	UserSetting->SaveSettings();
	//}
}


FString UVRBlueprintFunctionLibrary::GetToken()
{
	return GetGameCmdLine();
}

FString UVRBlueprintFunctionLibrary::GetGameCmdLine()
{
	const TCHAR * cmdline = FCommandLine::Get();
	return cmdline;
}

bool UVRBlueprintFunctionLibrary::IsDevelopMode()
{
	return !(IsRunningGame() || IsRunningDedicatedServer());
}

int32 UVRBlueprintFunctionLibrary::GetAttachedHMDDeviceType()
{
	int32 Type = -1;
	if (GEngine->HMDDevice.IsValid())
	{
		auto DeviceType = GEngine->HMDDevice->GetHMDDeviceType();
		Type = DeviceType;
	}
	return Type;
}


bool UVRBlueprintFunctionLibrary::IsViveDeviceAttached()
{
	return IsDeviceAttached(EHMDDeviceType::DT_SteamVR);
}

bool UVRBlueprintFunctionLibrary::IsOculusDeviceAttached()
{
	return IsDeviceAttached(EHMDDeviceType::DT_OculusRift);
}

bool UVRBlueprintFunctionLibrary::IsDeviceAttached(EHMDDeviceType::Type DeviceType)
{
	bool IsAttached = false;

	if (GEngine->HMDDevice.IsValid())
	{
		auto Type = GEngine->HMDDevice->GetHMDDeviceType();
		IsAttached = (Type == DeviceType);
	}

	return IsAttached;
}

