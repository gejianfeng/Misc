#pragma once


class GameUtils
{
public:
	static bool DecryptAESString(const FString& Content, FString& OutDecryptContent);
	static bool EncryptAESString(const FString& Content, FString& OutDecryptContent);
	static void TestRun();
};

