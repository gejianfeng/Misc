#pragma once

#include "BlackShieldNetNativeConfig.h"

class FBlackShieldNetNativeModule : public FDefaultGameModuleImpl
{
public:
	FBlackShieldNetNativeModule();

	virtual void StartupModule() override;

	virtual void ShutdownModule() override;

	const FBlackShieldNetNativeConfig& GetConfig() const { return BlackShieldConfig; }

protected:
	FBlackShieldNetNativeConfig BlackShieldConfig;
};
