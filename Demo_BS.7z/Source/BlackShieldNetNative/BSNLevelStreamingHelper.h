#pragma once

#include "BSNLevelStreamingHelperDefinitions.h"

class FBSNLevelStreamingAction
{
	friend class FBSNLevelStreamingHelper;
public:
	bool bLoading;
	bool bMakeVisibleAfterLoad;
	bool bShouldBlockOnLoad;
	ULevelStreaming* Level;
	FName LevelName;

public:
	FBSNLevelStreamingAction(bool bIsLoading, const FName& InLevelName, bool bIsMakeVisibleAfterLoad, bool bIsShouldBlockOnLoad, const FBSNLevelStreamingActionComplete& InDelegate, UWorld* World);

	virtual void UpdateAction(bool& bComplete);

	ULevelStreaming* FindAndCacheLevelStreamingObject(const FName LevelName, UWorld* InWorld);

	void ActivateLevel(ULevelStreaming* LevelStreamingObject);

	FString MakeSafeLevelName(const FName& InLevelName, UWorld* InWorld);

	bool UpdateLevel(ULevelStreaming* LevelStreamingObject);

protected:
	FBSNLevelStreamingActionComplete CompleteDelegate;
};

class FBSNLevelStreamingHelper : FTickableGameObject
{
public:
	FBSNLevelStreamingHelper();

	void AddLevelStreamingAction(FBSNLevelStreamingAction* InAction);

	virtual bool IsTickableWhenPaused() const
	{
		return true;
	}

	virtual TStatId GetStatId() const override
	{
		RETURN_QUICK_DECLARE_CYCLE_STAT(FBSNLevelStreamingHelper, STATGROUP_Tickables);
	}

	virtual void Tick(float DeltaTime) override;

	virtual bool IsTickable() const override
	{
		return true;
	}

protected:
	TArray<TSharedPtr<FBSNLevelStreamingAction>> LevelStreamingActions;
};
