#include "BlackShieldNetNative.h"
#include "BlackShieldUtilityFunctions.h"
#include "BSNLevelStreamingHelper.h"
#include "BlackShieldGameInstance.h"

namespace BSNUtils
{
	class UBlackShieldGameInstance* GetBSNGameInstance(UObject* WorldContextObject)
	{
		return GetTypedGameInstance<class UBlackShieldGameInstance>(WorldContextObject);
	}

	void LoadStreamLevel(UObject* WorldContextObject, FName LevelName, bool bMakeVisibleAfterLoad, bool bShouldBlockOnLoad, const FBSNLevelStreamingActionComplete& InDelegate /*= nullptr*/)
	{
		UBlackShieldGameInstance* BSNGameInstance = GetBSNGameInstance(WorldContextObject);
		if (!BSNGameInstance)
			return;

		FBSNLevelStreamingAction* StreamingAction = new FBSNLevelStreamingAction(true, LevelName, bMakeVisibleAfterLoad, bShouldBlockOnLoad, InDelegate, BSNGameInstance->GetWorld());
		BSNGameInstance->GetLevelStreamingHelper()->AddLevelStreamingAction(StreamingAction);
	}

	void UnloadStreamLevel(UObject* WorldContextObject, FName LevelName, const FBSNLevelStreamingActionComplete& InDelegate /*= nullptr*/)
	{
		UBlackShieldGameInstance* BSNGameInstance = GetBSNGameInstance(WorldContextObject);
		if (!BSNGameInstance)
			return;

		FBSNLevelStreamingAction* StreamingAction = new FBSNLevelStreamingAction(false, LevelName, false, false, InDelegate, BSNGameInstance->GetWorld());
		BSNGameInstance->GetLevelStreamingHelper()->AddLevelStreamingAction(StreamingAction);
	}
}
