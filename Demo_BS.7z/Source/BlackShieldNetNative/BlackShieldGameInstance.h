#pragma once

#include "OnlineSessionInterface.h"

#include "BlackShieldGameInstance.generated.h"

class FOnlineSessionSearchResult;
class FOnlineSessionSearch;
class AScoreBoard;

USTRUCT(BlueprintType)
struct FBlueprintSearchSessionResult
{
	GENERATED_BODY()

	FOnlineSessionSearchResult SessionSearchResult;
};

DECLARE_DYNAMIC_DELEGATE_TwoParams(FOnFindSessionsResultDynamicDelegate, bool, bSuccess, const TArray<FBlueprintSearchSessionResult>&, Results);
DECLARE_DELEGATE_TwoParams(FOnFindSessionsResultDelegate, bool, const TArray<FOnlineSessionSearchResult>&);

UCLASS()
class UBlackShieldGameInstance : public UGameInstance
{
	GENERATED_BODY()

public:
	UBlackShieldGameInstance(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());

	virtual void Init() override;

	virtual void Shutdown() override;

	virtual void BeginDestroy() override;

	class FBSNLevelStreamingHelper* GetLevelStreamingHelper() const { return LevelStreamingHelper.Get(); }

	class UHeroSelectionDataManager* GetHeroSelectoinDataManager() const { return HeroSelectionDataManager; }

	//pvp flow
	void BeginRequestPVPMode(const FString &InMapName, uint32 NumPlayerNeed);
	void OnLoginFailed();
	void JoinPVP(class ABSNPlayerController *NewPC, bool bJoin);
	void EndPVP();
	void StartMainMenu();
	void EndMainMenu();
	void TravelToServer(const FURL &InURL);
	FURL &GetPendingURL() { return PendingURL; }
	virtual void StartGameInstance() override;
	virtual void FinishDestroy() override;

	//
	UObject *GetWeaponInstance();
	AScoreBoard *GetScoreBoard();

	// Temporary purpose
	UFUNCTION(BlueprintCallable, Category = Game)
	void QuickJoinGame();

	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = Game)
	void OnQuickJoinGame();

	UFUNCTION(BlueprintCallable, Category = Game)
	void StartSearchRoom();

	UFUNCTION(BlueprintCallable, Category = Game)
	void DoSearchRoom();

	UFUNCTION(BlueprintCallable, Category = Game)
	void CancelSearch();

	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = Game)
	void OnCancelSearch();

	UFUNCTION(BlueprintCallable, Category = Game)
	void SetAllowJoinSession(bool bAllowJoin);

	UFUNCTION(BlueprintCallable, Category = Game)
	void SetEnterMainHallLevelCounts(int32 Counts);

	int32 GetEnterMainHallLevelCounts() const { return EnterMainHallLevelCounts; }

	// Session
	UFUNCTION(BlueprintCallable, Category = Session)
	void CreateSession(const FName& MapName);

	UFUNCTION(BlueprintCallable, Category = Session)
	void FindSessions(int32 MaxResults);

	void FindSessionsNative(int32 MaxResults, const FOnFindSessionsResultDelegate& InDelegate);

	bool SimpleJoinSession(const FOnlineSessionSearchResult& SearchResult);

	UFUNCTION(BlueprintCallable, Category = Session)
	void SimpleJoinSessionInIndex(int32 ResultIndex);

	UFUNCTION(BlueprintCallable, Category = Session)
	void SimpleJoinSession(const FBlueprintSearchSessionResult& DesiredSession);

	UFUNCTION(BlueprintCallable, Category = Session)
	void DestroySession();

	bool IsHostDelicatedServer() { return bHostDelicateServer; }

	UFUNCTION(BlueprintCallable, Category = Game)
	void SetupHMD();

protected:
	void HandleCreateSessionComplete(FName SessionName, bool bSuccess);

	void HandleFindSessionsComplete(bool bSuccess);

	void HandleJoinSessionComplete(FName SessionName, EOnJoinSessionCompleteResult::Type ResultType);

	void StartPVP();
public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Game)
	FString HeroName;

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = Game)
	uint32 bIsInQuickJoinGame : 1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category= Game)
	float MaxSearchTime;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Game)
	float SearchRoomInterval;

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = Game)
	FTimerHandle FinishQuickJoinTimeHandle;

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = Game)
	FTimerHandle SearchRoomTimeHandle;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Game)
	FName DefaultMapName;

protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = Session)
	FOnFindSessionsResultDynamicDelegate FindSessionResultDelegate;

	FOnFindSessionsResultDelegate FindSessionResultDelegateNative;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Session)
	TArray<FBlueprintSearchSessionResult> SessionSearchResults;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Game)
	class UHeroSelectionDataManager* HeroSelectionDataManager;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Game)
	TSubclassOf<AActor>				WeaponInterfaceClass;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Game)
	TSubclassOf<class AScoreBoard>	BoardClass;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Game)
	FTimerHandle QuickJoinTimeHandle;

	UPROPERTY(Transient)
	TWeakObjectPtr<UObject> WeaponInstance;

	UPROPERTY(Transient)
	TWeakObjectPtr<AScoreBoard> ScoreBoard;

	UPROPERTY(VisibleInstanceOnly, BlueprintReadOnly, Category = Game)
	int32 EnterMainHallLevelCounts;

protected:
	TSharedPtr<class FBSNLevelStreamingHelper>			LevelStreamingHelper;
	TSharedPtr<FOnlineSessionSearch>					SearchObject;
	FTimerHandle										TimeHandle_StartTravel;
	TArray<TWeakObjectPtr<class ABSNPlayerController>>  JoinPlayers;
	TSharedPtr<class FBSNMainMenu>						MainMenuUI;
	FURL												PendingURL;
	bool												bHostDelicateServer;
};

