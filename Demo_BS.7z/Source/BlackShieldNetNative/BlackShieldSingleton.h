#pragma once

#include "BlackShieldSingleton.generated.h"

UCLASS(Abstract, Blueprintable, BlueprintType)
class UBlackShieldSingleton : public UObject
{
	GENERATED_BODY()

public:
	UBlackShieldSingleton();
};
