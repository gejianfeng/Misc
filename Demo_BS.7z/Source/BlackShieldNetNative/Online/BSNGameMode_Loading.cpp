
#include "BlackShieldNetNative.h"
#include "BSNGameSession.h"
#include "BSNGameMode_Loading.h"
#include "Game/BSNGameState.h"
#include "BlackShieldGameInstance.h"
#include "UI/BSNHUD.h"

ABSNGameMode_Loading::ABSNGameMode_Loading(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer)
{
	PlayerControllerClass = ABSNPlayerController::StaticClass();
	GameStateClass = ABSNGameState::StaticClass();
	HUDClass = ABSNHUD::StaticClass();
}

ABSNGameMode_Loading::~ABSNGameMode_Loading()
{
}

void ABSNGameMode_Loading::RestartPlayer(class AController* NewPlayer)
{
	if (NewPlayer != NULL)
	{
		NewPlayer->SetIgnoreMoveInput(true);
		NewPlayer->SetIgnoreLookInput(true);
	}
}

void ABSNGameMode_Loading::StartMatch()
{
	Super::StartMatch();

	ABSNGameState *MyGameState = Cast<ABSNGameState>(GameState);
	if (MyGameState)
	{
		MyGameState->SetMatchState(ABSNGameState::LevelLoading);
	}

	if (GetRemoteRole()==ROLE_None)
	{
		GetWorld()->GetTimerManager().SetTimer(TimeHandler_SeamlessTravel, this, &ABSNGameMode_Loading::BeginSeamlessTravel, 0.5f, false);
	}
}

void ABSNGameMode_Loading::BeginSeamlessTravel()
{
	UBlackShieldGameInstance *GI = Cast<UBlackShieldGameInstance>(GetGameInstance());
	if (GI != NULL)
	{
		UWorld *MyWorld = GetWorld();
		FURL &URL = GI->GetPendingURL();

		PendingURL = FURL(&GEngine->LastURLFromWorld(MyWorld), *URL.Map, TRAVEL_Absolute);
		PendingURL.Host = URL.Host;

		if (!PendingURL.Valid)
		{
			const FString Error = FText::Format(NSLOCTEXT("Engine", "InvalidUrl", "Invalid URL: {0}"), FText::FromString(URL.Map)).ToString();
			GEngine->BroadcastTravelFailure(MyWorld, ETravelFailure::InvalidURL, Error);
		}
		else
		{
			FWorldContext &Context = GEngine->GetWorldContextFromWorldChecked(MyWorld);
			LoadPackageAsync(PendingURL.Map,
							 FLoadPackageAsyncDelegate::CreateUObject(this, &ABSNGameMode_Loading::SeamlessTravelLoadCallback),
							 0,
							 (MyWorld->WorldType == EWorldType::PIE ? PKG_PlayInEditor : PKG_None)
			);
		}
	}
}

void ABSNGameMode_Loading::SeamlessTravelLoadCallback(const FName& PackageName, UPackage* LevelPackage, EAsyncLoadingResult::Type Result)
{
 	UWorld *MyWorld = GetWorld();
	if (MyWorld != NULL && Result== EAsyncLoadingResult::Succeeded)
	{
		GEngine->SetClientTravel(MyWorld, *PendingURL.Host, TRAVEL_Absolute);
	}
}

