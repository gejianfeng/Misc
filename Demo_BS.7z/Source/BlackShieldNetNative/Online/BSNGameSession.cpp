#include "BlackShieldNetNative.h"
#include "Net/UnrealNetwork.h"
#include "BSNGameSession.h"
#include "AssertionMacros.h"

DEFINE_LOG_CATEGORY_STATIC(LogBSNGameSession, Log, All);

ABSNGameSession::ABSNGameSession(const FObjectInitializer& ObjectInitializer /*= FObjectInitializer::Get()*/)
	: Super(ObjectInitializer)
{
	if (!HasAnyFlags(RF_ClassDefaultObject))
	{
		OnCreateSessionCompleteDelegate = FOnCreateSessionCompleteDelegate::CreateUObject(this, &ABSNGameSession::OnCreateSessionComplete);
		OnDestroySessionCompleteDelegate = FOnDestroySessionCompleteDelegate::CreateUObject(this, &ABSNGameSession::OnDestroySessionComplete);

		OnFindSessionsCompleteDelegate = FOnFindSessionsCompleteDelegate::CreateUObject(this, &ABSNGameSession::OnFindSessionsComplete);
		OnJoinSessionCompleteDelegate = FOnJoinSessionCompleteDelegate::CreateUObject(this, &ABSNGameSession::OnJoinSessionComplete);

		OnStartSessionCompleteDelegate = FOnStartSessionCompleteDelegate::CreateUObject(this, &ABSNGameSession::OnStartOnlineGameComplete);
	}
}

void ABSNGameSession::CreateSession(const FName &Name)
{
	UWorld *World = GetWorld();
	IOnlineSessionPtr SessionInt = Online::GetSessionInterface(World);
	if (SessionInt.IsValid())
	{
		FOnlineSessionSettings  OnlineSessionSettings;
		OnlineSessionSettings.bAllowJoinInProgress = false;
		OnlineSessionSettings.NumPrivateConnections = 100;
		OnlineSessionSettings.NumPublicConnections = 100;
		SessionInt->CreateSession(0, Name, OnlineSessionSettings);
	}
}

void ABSNGameSession::DestorySession(const FName &Name)
{
	UWorld *World = GetWorld();
	IOnlineSessionPtr SessionInt = Online::GetSessionInterface(World);
	if (SessionInt.IsValid())
	{
		SessionInt->DestroySession(Name, OnDestroySessionCompleteDelegate);
	}
}

void ABSNGameSession::JoinSession(int32 playernum, const FName &Name)
{
	UWorld *World = GetWorld();
	IOnlineSessionPtr SessionInt = Online::GetSessionInterface(World);
	if (SessionInt.IsValid())
	{
		FOnlineSessionSearchResult Result;
		SessionInt->JoinSession(playernum, Name, Result);
	}
}

void ABSNGameSession::DumpSession(const FName &Name)
{
	UWorld *World = GetWorld();
	IOnlineSessionPtr SessionInt = Online::GetSessionInterface(World);
	if (SessionInt.IsValid())
	{
		FNamedOnlineSession *Session = SessionInt->GetNamedSession(Name);
		if (Session != NULL)
		{
			UE_LOG(LogBSNGameSession, Log, TEXT("dumping NamedSession: "));
			UE_LOG(LogBSNGameSession, Log, TEXT("	SessionName: %s"), *Session->SessionName.ToString());
			UE_LOG(LogBSNGameSession, Log, TEXT("	HostingPlayerNum: %d"), Session->HostingPlayerNum);
			UE_LOG(LogBSNGameSession, Log, TEXT("	SessionState: %s"), EOnlineSessionState::ToString(Session->SessionState));
			UE_LOG(LogBSNGameSession, Log, TEXT("	RegisteredPlayers: "));
			if (Session->RegisteredPlayers.Num())
			{
				for (int32 UserIdx = 0; UserIdx < Session->RegisteredPlayers.Num(); UserIdx++)
				{
					UE_LOG(LogBSNGameSession, Verbose, TEXT("	    %d: %s"), UserIdx, *Session->RegisteredPlayers[UserIdx]->ToDebugString());
				}
			}
			else
			{
				UE_LOG(LogBSNGameSession, Verbose, TEXT("	    0 registered players"));
			}

			UE_LOG(LogBSNGameSession, Verbose, TEXT("dumping Session: "));
			UE_LOG(LogBSNGameSession, Verbose, TEXT("	OwningPlayerName: %s"), *Session->OwningUserName);
			UE_LOG(LogBSNGameSession, Verbose, TEXT("	OwningPlayerId: %s"), Session->OwningUserId.IsValid() ? *Session->OwningUserId->ToDebugString() : TEXT(""));
			UE_LOG(LogBSNGameSession, Verbose, TEXT("	NumOpenPrivateConnections: %d"), Session->NumOpenPrivateConnections);
			UE_LOG(LogBSNGameSession, Verbose, TEXT("	NumOpenPublicConnections: %d"), Session->NumOpenPublicConnections);
			UE_LOG(LogBSNGameSession, Verbose, TEXT("	SessionInfo: %s"), Session->SessionInfo.IsValid() ? *Session->SessionInfo->ToDebugString() : TEXT("NULL"));

			UE_LOG(LogBSNGameSession, Verbose, TEXT("dumping SessionSettings: "));
			UE_LOG(LogBSNGameSession, Verbose, TEXT("\tNumPublicConnections: %d"), Session->SessionSettings.NumPublicConnections);
			UE_LOG(LogBSNGameSession, Verbose, TEXT("\tNumPrivateConnections: %d"), Session->SessionSettings.NumPrivateConnections);
			UE_LOG(LogBSNGameSession, Verbose, TEXT("\tbIsLanMatch: %s"), Session->SessionSettings.bIsLANMatch ? TEXT("true") : TEXT("false"));
			UE_LOG(LogBSNGameSession, Verbose, TEXT("\tbIsDedicated: %s"), Session->SessionSettings.bIsDedicated ? TEXT("true") : TEXT("false"));
			UE_LOG(LogBSNGameSession, Verbose, TEXT("\tbUsesStats: %s"), Session->SessionSettings.bUsesStats ? TEXT("true") : TEXT("false"));
			UE_LOG(LogBSNGameSession, Verbose, TEXT("\tbShouldAdvertise: %s"), Session->SessionSettings.bShouldAdvertise ? TEXT("true") : TEXT("false"));
			UE_LOG(LogBSNGameSession, Verbose, TEXT("\tbAllowJoinInProgress: %s"), Session->SessionSettings.bAllowJoinInProgress ? TEXT("true") : TEXT("false"));
			UE_LOG(LogBSNGameSession, Verbose, TEXT("\tbAllowInvites: %s"), Session->SessionSettings.bAllowInvites ? TEXT("true") : TEXT("false"));
			UE_LOG(LogBSNGameSession, Verbose, TEXT("\tbUsesPresence: %s"), Session->SessionSettings.bUsesPresence ? TEXT("true") : TEXT("false"));
			UE_LOG(LogBSNGameSession, Verbose, TEXT("\tbAllowJoinViaPresence: %s"), Session->SessionSettings.bAllowJoinViaPresence ? TEXT("true") : TEXT("false"));
			UE_LOG(LogBSNGameSession, Verbose, TEXT("\tbAllowJoinViaPresenceFriendsOnly: %s"), Session->SessionSettings.bAllowJoinViaPresenceFriendsOnly ? TEXT("true") : TEXT("false"));
			UE_LOG(LogBSNGameSession, Verbose, TEXT("\tBuildUniqueId: 0x%08x"), Session->SessionSettings.BuildUniqueId);
			UE_LOG(LogBSNGameSession, Verbose, TEXT("\tSettings:"));

			for (FSessionSettings::TConstIterator It(Session->SessionSettings.Settings); It; ++It)
			{
				FName Key = It.Key();
				const FOnlineSessionSetting& Setting = It.Value();
				UE_LOG(LogBSNGameSession, Verbose, TEXT("\t\t%s=%s"), *Key.ToString(), *Setting.ToString());
			}

		}
	}
}

void ABSNGameSession::RegisterServer()
{

}

void ABSNGameSession::RegisterServerFailed()
{

}

void ABSNGameSession::OnCreateSessionComplete(FName SessionName, bool bWasSuccessful)
{
	UWorld *World = GetWorld();
	IOnlineSessionPtr SessionInt = Online::GetSessionInterface(World);
	if (SessionInt.IsValid())
	{
		UE_LOG(LogBSNGameSession, Log, TEXT("Create session complete for %s, result %s"),*SessionName.GetPlainNameString(),(bWasSuccessful?TEXT("Success"):TEXT("Failed")));
	}
}

void ABSNGameSession::OnStartOnlineGameComplete(FName SessionName, bool bWasSuccessful)
{

}

void ABSNGameSession::OnFindSessionsComplete(bool bWasSuccessful)
{
	UE_LOG(LogBSNGameSession, Log, TEXT("Find session complete, result %s"), (bWasSuccessful ? TEXT("Success") : TEXT("Failed")));
}

void ABSNGameSession::OnJoinSessionComplete(FName SessionName, EOnJoinSessionCompleteResult::Type Result)
{
	if (Result == EOnJoinSessionCompleteResult::Success)
	{
		UWorld *World = GetWorld();
		IOnlineSessionPtr SessionInt = Online::GetSessionInterface(World);
		if (SessionInt.IsValid())
		{
			FString URL;
			SessionInt->GetResolvedConnectString(SessionName, URL);
			UE_LOG(LogBSNGameSession, Log, TEXT("Find session success! %s, URL %s"), *SessionName.GetPlainNameString(), *URL);
		}
	}
	else if (Result == EOnJoinSessionCompleteResult::AlreadyInSession)
	{
		UE_LOG(LogBSNGameSession, Log, TEXT("Is already in session !"));
	}
	else if (Result == EOnJoinSessionCompleteResult::SessionDoesNotExist)
	{
		UE_LOG(LogBSNGameSession, Log, TEXT("The session to find is not exsit!"));
	}
}

void ABSNGameSession::OnDestroySessionComplete(FName SessionName, bool bWasSuccessful)
{
	// 	UE_LOG(LogBSNGameSession, Log, TEXT("create session complete for %s, result %s"), *SessionName, bWasSuccessful? TEXT("True"):TEXT("False"));
}
