#pragma once

#include "GameFramework/GameSession.h"
#include "BSNGameMode_Loading.generated.h"

UCLASS(BlueprintType)
class ABSNGameMode_Loading :public AGameMode
{
	GENERATED_UCLASS_BODY()
public:
	~ABSNGameMode_Loading();
	virtual void RestartPlayer(class AController* NewPlayer) override;
	virtual void StartMatch() override;
protected:
	void BeginSeamlessTravel();
	void SeamlessTravelLoadCallback(const FName& PackageName, UPackage* LevelPackage, EAsyncLoadingResult::Type Result);
protected:
	FTimerHandle TimeHandler_SeamlessTravel;
	FURL		 PendingURL;
};



