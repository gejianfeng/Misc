#pragma once

#include "GameFramework/GameSession.h"
#include "BSNGameMode_Menu.generated.h"

UCLASS(BlueprintType)
class ABSNGameMode_Menu :public AGameMode
{
	GENERATED_UCLASS_BODY()
public:
	virtual void PreInitializeComponents() override;
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	virtual void RestartPlayer(class AController* NewPlayer) override;
	virtual TSubclassOf<AGameSession> GetGameSessionClass() const override;
};

