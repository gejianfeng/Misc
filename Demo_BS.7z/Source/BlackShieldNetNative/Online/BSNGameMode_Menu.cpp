
#include "BlackShieldNetNative.h"
#include "BSNGameSession.h"
#include "BSNGameMode_Menu.h"
#include "Game/BSNGameState.h"
#include "BlackShieldGameInstance.h"

ABSNGameMode_Menu::ABSNGameMode_Menu(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer)
{
	PlayerControllerClass = ABSNPlayerController::StaticClass();
	GameStateClass = ABSNGameState::StaticClass();
	HUDClass = ABSNHUD::StaticClass();
}

void ABSNGameMode_Menu::PreInitializeComponents()
{
	Super::PreInitializeComponents();
// 
// 	ABSNGameState *MyGameState = GetGameState<ABSNGameState>();
// 	if (MyGameState != NULL)
// 	{
// 		MyGameState->SetMatchState(ABSNGameState::WaitForEnter);
// 	}
}

void ABSNGameMode_Menu::RestartPlayer(class AController* NewPlayer)
{
// 	if (NewPlayer != NULL)
// 	{
// 		NewPlayer->SetIgnoreMoveInput(true);
// 		NewPlayer->SetIgnoreLookInput(true);
// 	}
}

TSubclassOf<AGameSession> ABSNGameMode_Menu::GetGameSessionClass() const
{
	return ABSNGameSession::StaticClass();
}

void ABSNGameMode_Menu::BeginPlay()
{
	Super::BeginPlay();
// 	UBlackShieldGameInstance *GI = Cast<UBlackShieldGameInstance>(GetGameInstance());
// 	if (GI != nullptr)
// 	{
// 		GI->StartMainMenu();
// 	}
}

void ABSNGameMode_Menu::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
// 	UBlackShieldGameInstance *GI = Cast<UBlackShieldGameInstance>(GetGameInstance());
// 	if (GI != nullptr)
// 	{
// 		GI->EndMainMenu();
// 	}
	Super::EndPlay(EndPlayReason);
}
