#pragma once

#include "GameFramework/GameSession.h"
#include "BSNGameSession.generated.h"

UCLASS()
class ABSNGameSession : public AGameSession
{
	GENERATED_BODY()

public:
	ABSNGameSession(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());

protected:
	virtual void OnCreateSessionComplete(FName SessionName, bool bWasSuccessful);

	void OnStartOnlineGameComplete(FName SessionName, bool bWasSuccessful);

	void OnFindSessionsComplete(bool bWasSuccessful);

	void OnJoinSessionComplete(FName SessionName, EOnJoinSessionCompleteResult::Type Result);

	virtual void OnDestroySessionComplete(FName SessionName, bool bWasSuccessful);

public:
	virtual void RegisterServer();
	virtual void RegisterServerFailed();
	void CreateSession(const FName &Name);
	void DestorySession(const FName &Name);
	void JoinSession(int32 playernum, const FName &Name);
	void DumpSession(const FName &Name);

protected:
	/** Delegate for creating a new session */
	FOnCreateSessionCompleteDelegate OnCreateSessionCompleteDelegate;
	/** Delegate after starting a session */
	FOnStartSessionCompleteDelegate OnStartSessionCompleteDelegate;
	/** Delegate for destroying a session */
	FOnDestroySessionCompleteDelegate OnDestroySessionCompleteDelegate;
	/** Delegate for searching for sessions */
	FOnFindSessionsCompleteDelegate OnFindSessionsCompleteDelegate;
	/** Delegate after joining a session */
	FOnJoinSessionCompleteDelegate OnJoinSessionCompleteDelegate;

	/** Handles to various registered delegates */
	FDelegateHandle OnStartSessionCompleteDelegateHandle;
	FDelegateHandle OnCreateSessionCompleteDelegateHandle;
	FDelegateHandle OnDestroySessionCompleteDelegateHandle;
	FDelegateHandle OnFindSessionsCompleteDelegateHandle;
	FDelegateHandle OnJoinSessionCompleteDelegateHandle;
};