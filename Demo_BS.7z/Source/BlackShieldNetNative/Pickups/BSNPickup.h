// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "GameFramework/Actor.h"
#include "Weapon/BSNITem.h"
#include "BSNPickup.generated.h"

class ABSPickupManager;

USTRUCT()
struct FPickItem
{
	GENERATED_BODY()
public:
	FPickItem() { Weight = 1.0f; InventoryClass = nullptr; }
	UPROPERTY(EditAnywhere)
	TSubclassOf<ABSNItem> InventoryClass;	
	UPROPERTY(EditAnywhere)
	float				  Weight;
};

UCLASS(BlueprintType, Blueprintable)
class ABSPickupManager : public AActor
{
	GENERATED_UCLASS_BODY()
public:
	virtual void BeginPlay() override;
	virtual void NotifyActorBeginOverlap(class AActor* Other) override;
	void GetLifetimeReplicatedProps(TArray< FLifetimeProperty > & OutLifetimeProps) const;
	UFUNCTION()
	void OnRep_IsActive();
	UFUNCTION(BlueprintCallable, BlueprintImplementableEvent, Category = Pickup)
	void OnPickupEvent();
	UFUNCTION(BlueprintCallable, BlueprintImplementableEvent, Category = Pickup)
	void OnRespawnEvent();
	UFUNCTION(BlueprintCallable, Category = Pickup)
		bool IsWeapon();
	UFUNCTION(BlueprintCallable, Category = Pickup)
		bool IsHealthPotion();
protected:
	void Respawn();
	void OnTouchPickupEnd();
	void OnPickupBy(TSubclassOf<ABSNItem> InventoryType, ABSNCharacter *pBSOwner);
	/*void GivepickupTo(const FName &InName, TSubclassOf<ABSNItem> &InventoryType, ABSNCharacter *Pawn);*/
	bool CanPickedUpByCharacter() const;
	virtual void Serialize(FArchive& Ar);
public:
	UPROPERTY(VisibleAnywhere)
	UCapsuleComponent *CollisionComponent;
	UPROPERTY(EditAnywhere)
	TArray<FPickItem> RandomPickTypes;
	UPROPERTY(EditAnywhere)
	float			  RespawnTime;
	UPROPERTY(EditDefaultsOnly)
	UParticleSystem	  *BloomEffect;
protected:
	UPROPERTY(BlueprintReadOnly, Transient, ReplicatedUsing = OnRep_IsActive)
	uint32			  bIsActive : 1;
	UPROPERTY(Transient, VisibleInstanceOnly, Replicated)
	ABSNCharacter	  *PickedupBy;
	UPROPERTY(Transient, Replicated)
	int				  PickupIndex;
protected:
	FTimerHandle				TimerHandle_RespawnPickup;
	float						TotalWeight;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	UParticleSystemComponent	*BloomParticleComponent;
	UPROPERTY(VisibleInstanceOnly, BlueprintReadOnly)
	UStaticMeshComponent		*PreviewPickMeshComp;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	URotatingMovementComponent	*MovementComponent;
};

