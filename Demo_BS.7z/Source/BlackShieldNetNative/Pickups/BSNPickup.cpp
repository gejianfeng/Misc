// Fill out your copyright notice in the Description page of Project Settings.

#include "BlackShieldNetNative.h"
#include "BSNPickup.h"
#include "BlackShieldCommons.h"
#include "Player/BSNCharacter.h"
#include "Weapon/BSNGun.h"
#include "Weapon/BSNHealthPotion.h"
#include "Weapon/BSNBullet.h"
#include "Weapon/BSNGrenade.h"
#include "Game/BSNGameState.h"

//////////////////////////////////////////////////////////////////////////
ABSPickupManager::ABSPickupManager(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, RespawnTime(5.0f)	
	, MovementComponent(NULL)
	, bIsActive(false)
	, PickedupBy(NULL)
	, PickupIndex(INDEX_NONE)
{
	CollisionComponent = ObjectInitializer.CreateDefaultSubobject<UCapsuleComponent>(this, TEXT("CollisionComp"));
	CollisionComponent->InitCapsuleSize(40.0f, 50.0f);
	CollisionComponent->SetCollisionObjectType(ECC_GameTraceChannel13);
	CollisionComponent->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
	CollisionComponent->SetCollisionResponseToAllChannels(ECR_Overlap);
	CollisionComponent->SetCollisionResponseToChannel(ECC_Visibility, ECR_Overlap);

	RootComponent = CollisionComponent;

	PreviewPickMeshComp = ObjectInitializer.CreateDefaultSubobject<UStaticMeshComponent>(this, TEXT("PreviewMesh"));
	PreviewPickMeshComp->SetupAttachment(RootComponent);

	BloomParticleComponent = ObjectInitializer.CreateDefaultSubobject<UParticleSystemComponent>(this,TEXT("BloomEffect"));
	BloomParticleComponent->bAutoActivate = false;
	BloomParticleComponent->bAutoDestroy = false;
	BloomParticleComponent->SetupAttachment(RootComponent);

 	MovementComponent = ObjectInitializer.CreateDefaultSubobject<URotatingMovementComponent>(this, TEXT("RotationingMovement"));
	SetReplicates(true);
}

void ABSPickupManager::BeginPlay()
{
	Super::BeginPlay();

	TotalWeight = 0;
	uint32 NumPickItem = RandomPickTypes.Num();
	if (NumPickItem > 0)
	{
		for (FPickItem &PickItem : RandomPickTypes)
		{
			TotalWeight += PickItem.Weight;
		}
	}

	if (MovementComponent != nullptr)
	{
		MovementComponent->RegisterComponent();
	}

	Respawn();
}

bool ABSPickupManager::CanPickedUpByCharacter() const
{
	if (!bIsActive || IsPendingKill())
	{
		return false;
	}

	ABSNGameState *MyGameState = Cast<ABSNGameState>(GetWorld()->GetGameState());
	if (!MyGameState || !MyGameState->IsMatchInProgress())
	{
		return false;
	}

	return true;
}

void ABSPickupManager::NotifyActorBeginOverlap(class AActor* Other)
{
	Super::NotifyActorBeginOverlap(Other);
	
	if (PickupIndex!=INDEX_NONE && Role==ROLE_Authority)
	{
		ABSNCharacter *pOwner = Cast<ABSNCharacter>(Other);
		FPickItem &SelectItem = RandomPickTypes[PickupIndex];
		if (pOwner && CanPickedUpByCharacter())
		{
			TSubclassOf<ABSNItem> &PickupType = SelectItem.InventoryClass;
			if (PickupType != NULL)
			{
				OnPickupBy(PickupType, pOwner);
				PickedupBy = pOwner;
			}
		
			if (!IsPendingKill())
			{
				OnPickupEvent();
				OnTouchPickupEnd();
			}

			bIsActive = false;
			PickupIndex = INDEX_NONE;
		}
	}
}

void ABSPickupManager::OnPickupBy(TSubclassOf<ABSNItem> InventoryType, ABSNCharacter *pBSOwner)
{
	ABSNItem *DefBSNItem = Cast<ABSNItem>(InventoryType->GetDefaultObject());

	if (ABSNGun *pWeapon = Cast<ABSNGun>(DefBSNItem))
	{
		FName Name = *FPackageName::GetShortName(InventoryType->GetOuterUPackage());
		ABSNGun *CurrentWeapon = Cast<ABSNGun>(pBSOwner->RightHandWeapon);
		if (CurrentWeapon != NULL && CurrentWeapon->GetClass()==*InventoryType)
		{
			uint32 Ammo = CurrentWeapon->Config.AmmoPerClip*CurrentWeapon->Config.InitClips;
			CurrentWeapon->GiveAmmo(Ammo);
		}
		else
		{
			ABSNItem *pInstanceInventory = GetWorld()->SpawnActorDeferred<ABSNItem>(InventoryType,FTransform::Identity);
			ABSNItem::InstanceItemByItemInfo(pInstanceInventory, Name);
			pWeapon = Cast<ABSNGun>(pInstanceInventory);
			pWeapon->BSNOwner = pBSOwner;
			pInstanceInventory->FinishSpawning(FTransform::Identity,true);
			pWeapon->SetOwner(pBSOwner);
			pWeapon->Instigator = pBSOwner;
			pBSOwner->EquipWeapon(pWeapon);
			pBSOwner->SaveItem(Name);
		}
	}
	else if (ABSNHeathPotion *pHealthPotion = Cast<ABSNHeathPotion>(DefBSNItem))
	{
		FName Name = *FPackageName::GetShortName(InventoryType->GetOuterUPackage());
		FHeathPotionDataRow *pHeathPotionData = ABSNHeathPotion::GetRow(Name);
		if (pHeathPotionData != NULL)
		{
			pBSOwner->GiveHealth(pHeathPotionData->HealthGive);
		}
		else
		{
			pBSOwner->GiveHealth(pHealthPotion->Config.HealthGive);
		}
	}
	else if (ABSNBullets *pBullets = Cast<ABSNBullets>(DefBSNItem))
	{
		FName Name = *FPackageName::GetShortName(InventoryType->GetOuterUPackage());
		FBulletRowData *pBulletData = ABSNBullets::GetRow(Name);
		if (pBulletData == NULL)
		{
			pBulletData = &pBullets->Config;
		}

		ABSNGun *pWeapon = Cast<ABSNGun>(pBSOwner->RightHandWeapon);
		if (pWeapon != NULL)
		{
			if (pBulletData->WeaponSpecial == NULL || pWeapon->IsA(pBulletData->WeaponSpecial))
			{
				pWeapon->GiveAmmo(pBulletData->AmmoCount);
			}
			else
			{
				pBSOwner->SaveItem(Name);
			}
		}
	}
	else if (ABSNGrenade *pGrenade = Cast<ABSNGrenade>(DefBSNItem))
	{
		FName Name = *FPackageName::GetShortName(InventoryType->GetOuterUPackage());
		ABSNItem *pInstanceInventory = GetWorld()->SpawnActorDeferred<ABSNItem>(InventoryType, FTransform::Identity);
		ABSNItem::InstanceItemByItemInfo(pInstanceInventory, Name);
		pGrenade = Cast<ABSNGrenade>(pInstanceInventory);
		pGrenade->BSNOwner = pBSOwner;
		pInstanceInventory->FinishSpawning(FTransform::Identity, true);
		pGrenade->SetOwner(pBSOwner);
		pGrenade->Instigator = pBSOwner;
		pBSOwner->UseGrenade(pGrenade);
	}
}

void ABSPickupManager::Respawn()
{
	uint32 NumPickItem = RandomPickTypes.Num();
	if (NumPickItem > 0)
	{
		if (TotalWeight > 0)
		{
			float curAcceWeight = FMath::FRandRange(0, TotalWeight);
			float acceProb = 0;
			uint32 i = 0;
			for (; i < NumPickItem; i++)
			{
				acceProb += RandomPickTypes[i].Weight;
				if (acceProb >= curAcceWeight)
				{
					break;
				}
			}
			PickupIndex = (i >= NumPickItem) ? NumPickItem - 1 : i;
		}
		else
		{
			PickupIndex = rand() % NumPickItem;
		}

		UStaticMesh *PreviewMesh = NULL;
		UClass *PickupType = *(RandomPickTypes[PickupIndex].InventoryClass);
		if (PickupType!=NULL)
		{
			ABSNItem *SpwanedInventory = Cast<ABSNItem>(PickupType->GetDefaultObject());
			PreviewMesh = SpwanedInventory ? SpwanedInventory->Mesh : NULL;
		}

		if (PreviewMesh)
		{
			PreviewPickMeshComp->SetStaticMesh(PreviewMesh);
			bIsActive = true;
		}

		if (MovementComponent != NULL)
		{
			MovementComponent->Activate();
		}
	}

	if (BloomParticleComponent != nullptr)
	{
		BloomParticleComponent->SetTemplate(BloomEffect);
		BloomParticleComponent->ActivateSystem();
	}
}

void ABSPickupManager::OnRep_IsActive()
{
	if (bIsActive)
	{
		Respawn();
	}
	else
	{
		OnTouchPickupEnd();
	}
}

void ABSPickupManager::OnTouchPickupEnd()
{
	GetWorldTimerManager().SetTimer<ABSPickupManager>(TimerHandle_RespawnPickup, this, &ABSPickupManager::Respawn, RespawnTime, false);

	if (BloomParticleComponent != nullptr)
	{
		TSubclassOf<ABSNItem> &PickupType = RandomPickTypes[PickupIndex].InventoryClass;
		ABSNItem *SpwanedInventory = Cast<ABSNItem>(PickupType->GetDefaultObject());
	
		UParticleSystem *pSys = SpwanedInventory ? SpwanedInventory->GetPickEffect() : NULL;
		if (pSys!=NULL)
		{
			BloomParticleComponent->SetTemplate(pSys);
			BloomParticleComponent->ActivateSystem();
		}
		else
		{
			BloomParticleComponent->DeactivateSystem();
		}

		PreviewPickMeshComp->SetStaticMesh(NULL);
		if (MovementComponent != nullptr)
		{
			MovementComponent->Deactivate();
		}
	}
}

void ABSPickupManager::Serialize(FArchive& Ar)
{
	Super::Serialize(Ar);
}

void ABSPickupManager::GetLifetimeReplicatedProps(TArray< FLifetimeProperty > & OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
	DOREPLIFETIME(ABSPickupManager, bIsActive);
	DOREPLIFETIME(ABSPickupManager, PickedupBy);
}

bool ABSPickupManager::IsWeapon()
{
	if (PickupIndex == INDEX_NONE)
	{
		return false;
	}

	FPickItem &SelectItem = RandomPickTypes[PickupIndex];
	TSubclassOf<ABSNItem> &PickupType = SelectItem.InventoryClass;
	ABSNItem *DefBSNItem = Cast<ABSNItem>(PickupType->GetDefaultObject());

	if (ABSNGun *pWeapon = Cast<ABSNGun>(DefBSNItem))
	{
		return true;
	}

	return false;
}

bool ABSPickupManager::IsHealthPotion()
{
	if (PickupIndex == INDEX_NONE)
	{
		return false;
	}

	FPickItem &SelectItem = RandomPickTypes[PickupIndex];
	TSubclassOf<ABSNItem> &PickupType = SelectItem.InventoryClass;
	ABSNItem *DefBSNItem = Cast<ABSNItem>(PickupType->GetDefaultObject());

	if (ABSNHeathPotion *pHealthPotion = Cast<ABSNHeathPotion>(DefBSNItem))
	{
		return true;
	}

	return false;
}