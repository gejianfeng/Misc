#pragma once

#include "BlackShieldCommons.generated.h"

UENUM(BlueprintType)
enum class EBSInputType : uint8
{
	HTCVive		= 0,
	Record		= 1,
	Keyboard	= 2,
	Gamepad		= 3,
	ArcadeBoard	= 4,
	OculusCV1	= 5
};

UENUM(BlueprintType)
enum class EBSMoveType : uint8
{
	Fly			= 0,
	Walk		= 1,
	Aircraft	= 2
};

UENUM(BlueprintType)
enum class EIKAnimState : uint8
{
	Idle,
	Teleport
};

UENUM(BlueprintType)
enum class EFKAnimState : uint8
{
	None,
	TeleportBegin,
	TeleportEnd,
	Dead,
	Idle
};

UENUM(BlueprintType)
enum class EBSHandAction : uint8
{
	Idle,
	HoldKnife,
	HoldGun,
	GrabSomething,
	Fire,
	Reload,
};

USTRUCT(BlueprintType)
struct FBSNLocationRotation
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FVector Location;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FRotator Rotation;
};

enum class EDialogType : uint8
{
	None,
	Generic,
	ControllerDisconnected
};

