// Fill out your copyright notice in the Description page of Project Settings.

#include "BlackShieldNetNative.h"

DEFINE_LOG_CATEGORY(LogBlackShield);
