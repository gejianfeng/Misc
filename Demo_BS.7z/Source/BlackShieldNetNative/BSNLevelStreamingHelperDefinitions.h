#pragma once

DECLARE_DELEGATE(FBSNLevelStreamingActionComplete);