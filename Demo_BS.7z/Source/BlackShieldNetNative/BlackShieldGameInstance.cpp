#include "BlackShieldNetNative.h"
#include "BlackShieldGameInstance.h"
#include "BSNLevelStreamingHelper.h"
#include "OnlineSubsystemUtils.h"
#include "OnlineSessionSettings.h"
#include "BlackShieldNetNativeConfig.h"
#include "DataTables/HeroSelectionData.h"
#include "IBSNOnline.h"
#include "Game/BSNPlayerState.h"
#include "Game/BSNGameState.h"
#include "Player/BSNPlayerController.h"
#include "UI/Widgets/SMainMenu.h"
#include "IHeadMountedDisplay.h"

#define ALLOW_JOIN_SESSION TEXT("AllowJoin")

#define GAME_TYPE TEXT("GameType")
#define GAME_TYPE_NAME TEXT("BlackShieldNetNative")

UBlackShieldGameInstance::UBlackShieldGameInstance(const FObjectInitializer& ObjectInitializer /*= FObjectInitializer::Get()*/)
	: Super(ObjectInitializer)
	, WeaponInstance(NULL)
{
	HeroName = TEXT("Hero0");

	MaxSearchTime = 15.0f;
	SearchRoomInterval = 2.0f;
	bIsInQuickJoinGame = false;
	bHostDelicateServer = false;

	EnterMainHallLevelCounts = 0;

	HeroSelectionDataManager = CreateDefaultSubobject<UHeroSelectionDataManager>(TEXT("HeroSelectionDataManager"));
}

void UBlackShieldGameInstance::Init()
{
	Super::Init();

	LevelStreamingHelper = TSharedPtr<class FBSNLevelStreamingHelper>(new FBSNLevelStreamingHelper);

	IOnlineSessionPtr OnlineSessionPtr = Online::GetSessionInterface(GetWorld());
	if (OnlineSessionPtr.IsValid())
	{
		OnlineSessionPtr->AddOnCreateSessionCompleteDelegate_Handle(FOnCreateSessionCompleteDelegate::CreateUObject(this, &UBlackShieldGameInstance::HandleCreateSessionComplete));
		OnlineSessionPtr->AddOnFindSessionsCompleteDelegate_Handle(FOnFindSessionsCompleteDelegate::CreateUObject(this, &UBlackShieldGameInstance::HandleFindSessionsComplete));
		OnlineSessionPtr->AddOnJoinSessionCompleteDelegate_Handle(FOnJoinSessionCompleteDelegate::CreateUObject(this, &UBlackShieldGameInstance::HandleJoinSessionComplete));

		SearchObject = MakeShareable(new FOnlineSessionSearch);
	}

	if (WorldContext->WorldType == EWorldType::Game)
	{
		bool bLan = FParse::Param(FCommandLine::Get(), TEXT("lan"));
		bHostDelicateServer = !bLan;
	}
	else
	{
		bool bWan = FParse::Param(FCommandLine::Get(), TEXT("wan"));
		bHostDelicateServer = bWan;
	}
}

UObject *UBlackShieldGameInstance::GetWeaponInstance()
{
	if (!WeaponInstance.IsValid() && WeaponInterfaceClass != NULL)
	{
		WeaponInstance = GetWorld()->SpawnActor(WeaponInterfaceClass);
	}
	return WeaponInstance.Get();
}

AScoreBoard *UBlackShieldGameInstance::GetScoreBoard()
{
	if (!ScoreBoard.IsValid() && BoardClass != NULL)
	{
		ScoreBoard = Cast<AScoreBoard>(GetWorld()->SpawnActor(BoardClass));
	}
	return ScoreBoard.Get();
}

void UBlackShieldGameInstance::Shutdown()
{
	GetTimerManager().ClearAllTimersForObject(this);

	LevelStreamingHelper.Reset();

	IBNSOnline::Get().Shutdown();

	DestroySession();

	Super::Shutdown();
}

void UBlackShieldGameInstance::BeginDestroy()
{
	Super::BeginDestroy();
}

void UBlackShieldGameInstance::SetAllowJoinSession(bool bAllowJoin)
{
	IOnlineSessionPtr OnlineSessionPtr = Online::GetSessionInterface(GetWorld());
	if (OnlineSessionPtr.IsValid())
	{
		FOnlineSessionSettings* Setttings = OnlineSessionPtr->GetSessionSettings(GameSessionName);
		if (Setttings)
		{
			Setttings->Set(ALLOW_JOIN_SESSION, false, EOnlineDataAdvertisementType::ViaOnlineServiceAndPing);
		}
	}
}

void UBlackShieldGameInstance::SetEnterMainHallLevelCounts(int32 Counts)
{
	EnterMainHallLevelCounts = Counts;
}

void UBlackShieldGameInstance::CreateSession(const FName& MapName)
{
	IOnlineSessionPtr OnlineSessionPtr = Online::GetSessionInterface(GetWorld());
	if (OnlineSessionPtr.IsValid())
	{
		FOnlineSessionSettings Settings;
		Settings.NumPublicConnections = 6;
		Settings.NumPrivateConnections = 0;
		Settings.bShouldAdvertise = true;
		Settings.bAllowJoinInProgress = true;
		Settings.bIsLANMatch = true;
		Settings.bUsesPresence = true;
		Settings.bAllowJoinViaPresence = true;
		Settings.bIsDedicated = IsDedicatedServerInstance();
		Settings.bAllowJoinViaPresenceFriendsOnly = false;
		Settings.bAntiCheatProtected = false;
		Settings.bUsesStats = true;
		Settings.bShouldAdvertise = true;

		// These are about the only changes over the standard Create Sessions Node
		Settings.bAllowInvites = true;

		Settings.Set(SETTING_MAPNAME, MapName.ToString());
		Settings.Set(GAME_TYPE, FString(GAME_TYPE_NAME));

		OnlineSessionPtr->CreateSession(0, GameSessionName, Settings);
	}
}

void UBlackShieldGameInstance::FindSessions(int32 MaxResults)
{
	IOnlineSessionPtr OnlineSessionPtr = Online::GetSessionInterface(GetWorld());
	if (OnlineSessionPtr.IsValid())
	{
		SearchObject->MaxSearchResults = MaxResults;
		SearchObject->bIsLanQuery = true;
		SearchObject->QuerySettings.Set(SEARCH_PRESENCE, true, EOnlineComparisonOp::Equals);
		SearchObject->QuerySettings.Set(GAME_TYPE, FString(GAME_TYPE_NAME), EOnlineComparisonOp::Equals);

		OnlineSessionPtr->FindSessions(0, SearchObject.ToSharedRef());
	}
}

void UBlackShieldGameInstance::FindSessionsNative(int32 MaxResults, const FOnFindSessionsResultDelegate& InDelegate)
{
	IOnlineSessionPtr OnlineSessionPtr = Online::GetSessionInterface(GetWorld());
	if (OnlineSessionPtr.IsValid())
	{
		SearchObject->MaxSearchResults = MaxResults;
		SearchObject->bIsLanQuery = true;
		SearchObject->QuerySettings.Set(SEARCH_PRESENCE, true, EOnlineComparisonOp::Equals);
		SearchObject->QuerySettings.Set(GAME_TYPE, FString(GAME_TYPE_NAME), EOnlineComparisonOp::Equals);

		OnlineSessionPtr->FindSessions(0, SearchObject.ToSharedRef());

		FindSessionResultDelegateNative = InDelegate;
	}
}

bool UBlackShieldGameInstance::SimpleJoinSession(const FOnlineSessionSearchResult& SearchResult)
{
	IOnlineSessionPtr OnlineSessionPtr = Online::GetSessionInterface(GetWorld());
	if (OnlineSessionPtr.IsValid())
	{
		OnlineSessionPtr->JoinSession(0, GameSessionName, SearchResult);

		return true;
	}

	return false;
}

void UBlackShieldGameInstance::SimpleJoinSession(const FBlueprintSearchSessionResult& DesiredSession)
{
	SimpleJoinSession(DesiredSession.SessionSearchResult);
}

void UBlackShieldGameInstance::DestroySession()
{
	IOnlineSessionPtr OnlineSessionPtr = Online::GetSessionInterface(GetWorld());
	if (OnlineSessionPtr.IsValid())
	{
		OnlineSessionPtr->DestroySession(GameSessionName);
	}
}

void UBlackShieldGameInstance::SimpleJoinSessionInIndex(int32 ResultIndex)
{
	if (ResultIndex < SessionSearchResults.Num())
	{
		SimpleJoinSession(SessionSearchResults[ResultIndex].SessionSearchResult);
	}
}

void UBlackShieldGameInstance::HandleCreateSessionComplete(FName SessionName, bool bSuccess)
{
 	if (!bSuccess)
 		return;
 
 	IOnlineSessionPtr OnlineSessionPtr = Online::GetSessionInterface(GetWorld());
 	if (OnlineSessionPtr.IsValid())
 	{
 		FOnlineSessionSettings* SessionSettings = OnlineSessionPtr->GetSessionSettings(SessionName);
 		if (SessionSettings)
 		{
 			FString MapName;
 			SessionSettings->Get(SETTING_MAPNAME, MapName);
 
 			OnlineSessionPtr->StartSession(SessionName);
 
 			FString OptionStr = TEXT("listen");
 			OptionStr += FString::Printf(TEXT("?HeroName=%s"), *HeroName);
 			UGameplayStatics::OpenLevel(this, *MapName, true, OptionStr);
 		}
 	}
}

void UBlackShieldGameInstance::HandleFindSessionsComplete(bool bSuccess)
{
	SessionSearchResults.Empty();
	for (int32 i = 0; i < SearchObject->SearchResults.Num(); ++i)
	{
		SessionSearchResults.Add(FBlueprintSearchSessionResult{ SearchObject->SearchResults[i] });
	}

	FindSessionResultDelegate.ExecuteIfBound(bSuccess, SessionSearchResults);

	FindSessionResultDelegateNative.ExecuteIfBound(bSuccess, SearchObject->SearchResults);
}

void UBlackShieldGameInstance::HandleJoinSessionComplete(FName SessionName, EOnJoinSessionCompleteResult::Type ResultType)
{
	if (ResultType != EOnJoinSessionCompleteResult::Success)
		return;

	APlayerController * const PlayerController = GetFirstLocalPlayerController();
	FString URL;

	IOnlineSessionPtr OnlineSessionPtr = Online::GetSessionInterface(GetWorld());
	if (PlayerController && OnlineSessionPtr.IsValid() && OnlineSessionPtr->GetResolvedConnectString(SessionName, URL))
	{
		URL += FString::Printf(TEXT("?HeroName=%s"), *HeroName);
		PlayerController->ClientTravel(URL, TRAVEL_Absolute);
	}
}

//////////////////////////////////////////////////////////////////////////
void UBlackShieldGameInstance::StartGameInstance()
{
	Super::StartGameInstance();

	UWorld *MyWorld = GetWorld();
	if (MyWorld != NULL)
	{
		IBNSOnline::Get().Startup(MyWorld);
	}
}

void UBlackShieldGameInstance::OnLoginFailed()
{
}

void UBlackShieldGameInstance::FinishDestroy()
{
	Super::FinishDestroy();
}

// #define BSN_USE_LANSESSION 0

void UBlackShieldGameInstance::QuickJoinGame()
{
	if (bHostDelicateServer)
	{
		GetTimerManager().SetTimer(QuickJoinTimeHandle,
			FTimerDelegate::CreateLambda([this]()
		{
			APlayerController* PlayerController = this->GetFirstLocalPlayerController(this->GetWorld());
			FString URL;
			int32 Port;
			URL = GetBlackShieldConfig().Host;
			Port = GetBlackShieldConfig().Port;
			//URL += FString::Printf(TEXT("?HeroName="), *HeroName);
			FURL CombURL;
			CombURL.Host = URL;
			CombURL.Port = Port;

			// Temporary Map
			CombURL.Map = TEXT("L_MainGamePVP");
			CombURL.AddOption(*FString::Printf(TEXT("?HeroName="), *HeroName));
			this->TravelToServer(CombURL);
		}), 3.0f, false);
	}
	else
	{
		//OnQuickJoinGame(); // Blueprint event
		if (bIsInQuickJoinGame)
			return;

		bIsInQuickJoinGame = true;

		GetTimerManager().SetTimer(
			FinishQuickJoinTimeHandle,
			FTimerDelegate::CreateLambda
			([=]()
		{
			CancelSearch();
			CreateSession(DefaultMapName);
		}),
			MaxSearchTime, false);

		StartSearchRoom();
	}
}

void UBlackShieldGameInstance::StartSearchRoom()
{
	DoSearchRoom();

	//GetWorld()->GetTimerManager().SetTimer(SearchRoomTimeHandle, 
	//	FTimerDelegate::CreateLambda(
	//	[=]()
	//	{
	//		IOnlineSessionPtr OnlineSessionPtr = Online::GetSessionInterface(GetWorld());
	//		if (OnlineSessionPtr.IsValid())
	//		{
	//			OnlineSessionPtr->CancelFindSessions();
	//		}
	//		DoSearchRoom();
	//	}), 
	//	SearchRoomInterval, 
	//	false);
}

void UBlackShieldGameInstance::DoSearchRoom()
{
	FindSessionsNative(
		10, 
		FOnFindSessionsResultDelegate::CreateLambda([=](bool bSuccess, const TArray<FOnlineSessionSearchResult>& SearchResults)
		{
			if (bSuccess)
			{
				for (int32 i = 0; i < SearchResults.Num(); ++i)
				{
					const FOnlineSessionSearchResult& Result = SearchResults[i];
					if (Result.IsValid())
					{
						bool bAllowJoin = true;
						Result.Session.SessionSettings.Get(ALLOW_JOIN_SESSION, bAllowJoin);

						if (!bAllowJoin)
							continue;

						CancelSearch();
						SimpleJoinSession(Result);
						break;
					}
				}
			}
			else
			{
				DoSearchRoom();
			}
		})
	);
}

void UBlackShieldGameInstance::CancelSearch()
{
	if (bHostDelicateServer)
	{
		if (QuickJoinTimeHandle.IsValid())
		{
			GetWorld()->GetTimerManager().ClearTimer(QuickJoinTimeHandle);
			QuickJoinTimeHandle.Invalidate();
		}
	}
	else
	{
		//OnCancelSearch(); // Blueprint event
		GetWorld()->GetTimerManager().ClearTimer(FinishQuickJoinTimeHandle);
		GetWorld()->GetTimerManager().ClearTimer(SearchRoomTimeHandle);
		FinishQuickJoinTimeHandle.Invalidate();
		SearchRoomTimeHandle.Invalidate();

		IOnlineSessionPtr OnlineSessionPtr = Online::GetSessionInterface(GetWorld());
		if (OnlineSessionPtr.IsValid())
		{
			OnlineSessionPtr->CancelFindSessions();
		}
		bIsInQuickJoinGame = false;
	}
}

void UBlackShieldGameInstance::JoinPVP(ABSNPlayerController *NewPC, bool bJoin)
{
	if (bJoin)
	{
		ABSNPlayerState *MyPlayerState = Cast<ABSNPlayerState>(NewPC->PlayerState);
		if (MyPlayerState != NULL)
		{
			MyPlayerState->PVPState = EPVPState::WaitEnterPVPMap;
		}

		UWorld *MyWorld = NewPC->GetWorld();
		ABSNGameState *MyGameState = MyWorld ? Cast<ABSNGameState>(MyWorld->GetGameState()) : NULL;
		if (MyGameState != NULL)
		{
			MyGameState->PlayerNumeber++;
			if (MyGameState->PlayerNumeber >= MyGameState->PlayerNumberNeed)
			{
				GetTimerManager().SetTimer(TimeHandle_StartTravel, this, &UBlackShieldGameInstance::StartPVP, 1.0f, false);
			}
		}

		JoinPlayers.Add(NewPC);
	}
}

void UBlackShieldGameInstance::StartPVP()
{
	UWorld *MyWorld = GetWorld();
	ABSNGameState *MyGameState = MyWorld ? Cast<ABSNGameState>(MyWorld->GetGameState()) : NULL;

	if (MyGameState != NULL)
	{
		for (int32 i = 0; i < JoinPlayers.Num(); ++i)
		{
			ABSNPlayerController *PC = JoinPlayers[i].Get();
			if (PC != NULL)
			{
				ABSNPlayerState *PlayerState = Cast<ABSNPlayerState>(PC->PlayerState);
				PlayerState->PVPState = EPVPState::WaitEnterPVPMap;
				PlayerState->PVPWaitStartTime = 0;
				PC->ClientTravel(MyGameState->URL, ETravelType::TRAVEL_Absolute);
			}
		}
	}
}

void UBlackShieldGameInstance::EndPVP()
{
	JoinPlayers.Empty();
}

void UBlackShieldGameInstance::BeginRequestPVPMode(const FString &InMapName, uint32 NumPlayerNeed)
{
	UWorld *MyWorld = GetWorld();
	ABSNGameState *MyGameState = MyWorld ? Cast<ABSNGameState>(MyWorld->GetGameState()) : NULL;
	if (MyGameState != NULL)
	{
		MyGameState->PlayerNumberNeed = NumPlayerNeed;
		MyGameState->URL = InMapName;
	}

	for (FConstPlayerControllerIterator It = GetWorld()->GetPlayerControllerIterator(); It; ++It)
	{
		ABSNPlayerController *PC = Cast<ABSNPlayerController>(*It);
		if (PC != NULL)
		{
			PC->ClientRequestPVPMode();
		}
	}
}

void UBlackShieldGameInstance::StartMainMenu()
{
	if (!MainMenuUI.IsValid())
	{
		ULocalPlayer* const Player = GetFirstGamePlayer();
		MainMenuUI = MakeShareable(new FBSNMainMenu());
		MainMenuUI->Construct(this, Player);
		MainMenuUI->AddMenuToGameViewport();
	}
}

void UBlackShieldGameInstance::EndMainMenu()
{
	if (MainMenuUI.IsValid())
	{
		MainMenuUI->RemoveMenuFromGameViewport();
		MainMenuUI = nullptr;
	}
}

void UBlackShieldGameInstance::TravelToServer(const FURL &InURL)
{
	UWorld *World = GetWorld();
	if (World != NULL)
	{
		PendingURL = InURL;
		EndMainMenu();
		GEngine->SetClientTravel(World, TEXT("Loading"), TRAVEL_Absolute);
	}
}


void UBlackShieldGameInstance::SetupHMD()
{
	if (GEngine && GEngine->HMDDevice.IsValid())
	{
		GEngine->HMDDevice->EnableHMD(true);
	}
}


UObject *GetWeaponInterface(UGameInstance *InGI)
{
	UBlackShieldGameInstance *GI = Cast<UBlackShieldGameInstance>(InGI);
	if (GI != NULL)
	{
		return GI->GetWeaponInstance();
	}
	return NULL;
}

