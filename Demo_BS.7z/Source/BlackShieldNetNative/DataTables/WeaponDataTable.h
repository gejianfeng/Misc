// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "WeaponDataTable.generated.h"

/**
 * 
 */
USTRUCT(BlueprintType)
struct FWeapon_Entry : public FTableRowBase
{
	GENERATED_BODY()
	
		/** Tag specified in the table */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = GameplayTag)
	FString Tag;

	/** Text that describes this category - not all tags have categories */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = GameplayTag)
	FText CategoryText;
	
	/** Text that describes this category - not all tags have categories */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = GameplayTag)
	FText CategoryText1;

	/** Text that describes this category - not all tags have categories */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = GameplayTag)
	FText CategoryText2;

	/** Text that describes this category - not all tags have categories */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = GameplayTag)
	FText CategoryText3;
};


USTRUCT(BlueprintType)
struct FWeapon_Client : public FTableRowBase
{
	GENERATED_BODY()

	/** Tag specified in the table */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = GameplayTag)
	FString Tag;

	/** Text that describes this category - not all tags have categories */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = GameplayTag)
	FText CategoryText;
};

USTRUCT(BlueprintType)
struct FWeapon_Spell_Entry : public FTableRowBase
{
	GENERATED_BODY()

	/** Tag specified in the table */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = GameplayTag)
	FString Tag;

	/** Text that describes this category - not all tags have categories */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = GameplayTag)
	FText CategoryText;
};

USTRUCT(BlueprintType)
struct FWeapon_Spell_Client : public FTableRowBase
{
	GENERATED_BODY()

	/** Tag specified in the table */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = GameplayTag)
	FString Tag;

	/** Text that describes this category - not all tags have categories */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = GameplayTag)
	FText CategoryText;
};