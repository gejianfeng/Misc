#pragma once

#include "HeroSelectionData.generated.h"

USTRUCT(BlueprintType)
struct FHeroSelectionDataRow : public FTableRowBase
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Hero")
	TAssetPtr<class USkeletalMesh> Asset;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Hero")
	TArray<int32> MeshElementHideIndices;
};

UCLASS(DefaultToInstanced, BlueprintType, Blueprintable)
class UHeroSelectionDataManager : public UObject
{
	GENERATED_BODY()

public:
	virtual class UWorld* GetWorld() const override;

	struct FHeroSelectionDataRow* UHeroSelectionDataManager::FindHeroData(const FName& RowName);

protected:
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Hero")
	class UDataTable* HeroDataTable;
};
