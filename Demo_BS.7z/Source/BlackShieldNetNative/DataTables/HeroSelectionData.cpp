#include "BlackShieldNetNative.h"
#include "HeroSelectionData.h"

class UWorld* UHeroSelectionDataManager::GetWorld() const
{
	if (!HasAnyFlags(RF_ClassDefaultObject) && GetOuter())
	{
		return GetOuter()->GetWorld();
	}

	return nullptr;
}

struct FHeroSelectionDataRow* UHeroSelectionDataManager::FindHeroData(const FName& RowName)
{
	FHeroSelectionDataRow* RetData = nullptr;

	if (HeroDataTable)
	{
		RetData = HeroDataTable->FindRow<FHeroSelectionDataRow>(RowName, TEXT("HeroData"));
	}

	return RetData;
}
