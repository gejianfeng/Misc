#include "BlackShieldNetNative.h"
#include "Player/BSNCharacterAircraft.h"
#include "Curves/CurveFloat.h"
#include "BSNAircraftMovementController.h"

UBSNAircraftMovementController::UBSNAircraftMovementController(const FObjectInitializer& ObjectInitializer /* = FObjectInitializer::Get() */)
	: Super(ObjectInitializer)
	, bCanSimulate(false)
	, bCanInitSimulate(false)
	, bSimulate(false)
	, DeviceStartLocation(FVector::ZeroVector)
	, DeviceStartRotation(FRotator::ZeroRotator)
{
	
}

void UBSNAircraftMovementController::CanInitSimulate()
{
	bCanInitSimulate = true;
	
	if (bCanSimulate)
	{
		InitSimulate();
	}
}

void UBSNAircraftMovementController::StartSimulate()
{
	bCanSimulate = true;

	if (bCanInitSimulate)
	{
		InitSimulate();
	}
}

void UBSNAircraftMovementController::StopSimulate()
{
	if (TimerHandler_InitSimulation.IsValid() && OwningCharacter)
	{
		OwningCharacter->GetWorldTimerManager().ClearTimer(TimerHandler_InitSimulation);
		TimerHandler_InitSimulation.Invalidate();
	}

	bCanInitSimulate = false;
	bCanSimulate = false;
	bSimulate = false;
}

void UBSNAircraftMovementController::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (bSimulate && OwningCharacter && OwningCharacter->IsLocallyControlled())
	{
		LocallySimulateAnalogInput();
	}
}

void UBSNAircraftMovementController::LocallySimulateAnalogInput()
{
	FVector DeviceLocation;
	FRotator DeviceRotation;
	UHeadMountedDisplayFunctionLibrary::GetOrientationAndPosition(DeviceRotation, DeviceLocation);

	ABSNCharacterAircraft* AircraftCharacter = Cast<ABSNCharacterAircraft>(OwningCharacter);
	if (AircraftCharacter)
	{
		FVector DiffLoc = DeviceLocation - DeviceStartLocation;

		float XAxisValue = DiffLoc.X * 10;
		float YAxisValue = DiffLoc.Y * 10;
		float Yaw = DeviceRotation.Yaw;

		float XAxisProjectionValue = ProjectToXAxis(XAxisValue, YAxisValue, Yaw);
		float YAxisProjectionValue = ProjectToYAxis(XAxisValue, YAxisValue, Yaw);

		float XAxisInput = 0.0f;
		float YAxisInput = 0.0f;

		if (CurveFloat)
		{
			XAxisInput = FMath::Clamp(CurveFloat->GetFloatValue(XAxisProjectionValue), -1.0f, 1.0f);
			YAxisInput = FMath::Clamp(CurveFloat->GetFloatValue(YAxisProjectionValue), -1.0f, 1.0f);
		}
		else
		{
			XAxisInput = FMath::Clamp(XAxisProjectionValue, -1.0f, 1.0f);
			YAxisInput = FMath::Clamp(YAxisProjectionValue, -1.0f, 1.0f);
		}

		FVector InputVector = FVector(XAxisInput, YAxisInput, 0);
		AircraftCharacter->AddMovementInput(InputVector);
	}
}

void UBSNAircraftMovementController::InitSimulate()
{
	if (OwningCharacter && !TimerHandler_InitSimulation.IsValid())
	{
		OwningCharacter->GetWorldTimerManager().SetTimer(
			TimerHandler_InitSimulation,
			FTimerDelegate::CreateLambda([this]()
			{
				UHeadMountedDisplayFunctionLibrary::GetOrientationAndPosition(DeviceStartRotation, DeviceStartLocation);
				bSimulate = true;

				if (OwningCharacter)
				{
					OwningCharacter->GetWorldTimerManager().ClearTimer(TimerHandler_InitSimulation);
					TimerHandler_InitSimulation.Invalidate();
				}
			}),
			0.01f, false);
	}
}

float UBSNAircraftMovementController::ProjectToXAxis(float XAxisInput, float YAxisInput, float Yaw)
{
	float YawCosdValue = FMath::Cos(PI / (180.f) * Yaw);
	return XAxisInput * YawCosdValue + YAxisInput * YawCosdValue;
}

float UBSNAircraftMovementController::ProjectToYAxis(float XAxisInput, float YAxisInput, float Yaw)
{
	float YawSindValue = FMath::Sin(PI / (180.f) * Yaw);
	return XAxisInput * YawSindValue + YAxisInput * YawSindValue;
}