// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "Components/ActorComponent.h"
#include "BlackShieldCommons.h"
#include "BSNMovementController.generated.h"

USTRUCT(BlueprintType)
struct FBSNClientMovementData
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FBSNLocationRotation MeshInfo;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FBSNLocationRotation NeckInfo;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FBSNLocationRotation LeftHandInfo;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FBSNLocationRotation RightHandInfo;

	void Initialize()
	{
		NeckInfo.Location = FVector(0, 0, 150.0f);
		NeckInfo.Rotation = FRotator(90.0f, 0, -90.0f);

		MeshInfo.Location = FVector(0, 0, 0);
		MeshInfo.Rotation = FRotator(0, 0, 0);

		LeftHandInfo.Location = FVector(22.f, -36.f, 138.f);
		LeftHandInfo.Rotation = FRotator(0, 0, 180.f);

		RightHandInfo.Location = FVector(22.f, 10.f, 120.f);
		RightHandInfo.Rotation = FRotator(0, 0, 0);
	}
};

USTRUCT(BlueprintType)
struct FBSNSmoothMovementData
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FBSNClientMovementData OrgData;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FBSNClientMovementData DestData;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float ReceivedTime;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float SentTimeStamp;

	FBSNSmoothMovementData()
		: ReceivedTime(0)
		, SentTimeStamp(0)
	{

	}
};

UCLASS(config=Player, Blueprintable, ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class UBSNMovementController : public UActorComponent
{
	GENERATED_BODY()

public:	
	// Sets default values for this component's properties
	UBSNMovementController(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());

	void SetUpdatedMeshComponent(class USkeletalMeshComponent* InMeshComponent);

	class USkeletalMeshComponent* GetUpdatedMeshComponent() const { return UpdatedMeshComponent; }

	// Called when the game starts
	virtual void BeginPlay() override;
	
	// Called every frame
	virtual void TickComponent( float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction ) override;

	void LocallyControlledMotionTick();

	virtual void InitializeComponent() override;

	virtual void PostInitProperties() override;

	void RemoteSimulatedTick();

	FBSNClientMovementData InterpolateSmoothMovement(const FBSNClientMovementData& AData, const FBSNClientMovementData& BData, float Alpha);

	void UpdateLocalClientMovementData();

	UFUNCTION(Unreliable, Server, WithValidation, BlueprintCallable, Category = "RPC|Move")
	void ReplicateMoveToServer(const FBSNClientMovementData& InClinetMovementData, float SentTimeStamp);

	virtual bool ReplicateMoveToServer_Validate(const FBSNClientMovementData& InClinetMovementData, float SentTimeStamp);

	virtual void ReplicateMoveToServer_Implementation(const FBSNClientMovementData& InClinetMovementData, float SentTimeStamp);

	UFUNCTION(Unreliable, NetMulticast, BlueprintCallable, Category = "RPC|Move")
	void MulticastMove(const FBSNClientMovementData& InClinetMovementData, float SentTimeStamp);

	virtual void MulticastMove_Implementation(const FBSNClientMovementData& InClinetMovementData, float SentTimeStamp);

	void SetNeckInfo(const FVector& DeviceLocation, const FRotator& DeviceRotation);

	void SetMeshInfo(const FVector& DeviceLocation, const FRotator& DeviceRotation);

	void SetLeftHandInfo(const FVector& DeviceLocation, const FRotator& DeviceRotation);

	void SetRightHandInfo(const FVector& DeviceLocation, const FRotator& DeviceRotation);

	void UpdateCharacterAnimation();

	void UpdateMeshTransform();

	FVector CalculateHandOffset(const FRotator& InHandOrientation, float InHandOffset);

	void SetTickStatus(bool status);

	void SetUpdateMeshTransform(bool status);

public:
	UPROPERTY(Transient, VisibleAnywhere, BlueprintReadOnly, Category = "Mesh")
	USkeletalMeshComponent* UpdatedMeshComponent;

	UPROPERTY(Transient, VisibleAnywhere, BlueprintReadOnly, Category = "Character")
	class ABSNCharacter* OwningCharacter;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Movement")
	FBSNClientMovementData ClientMovementData;

	UPROPERTY(Transient, VisibleAnywhere, BlueprintReadOnly, Category = "Movement")
	float ReplicateToServerTime;

	UPROPERTY(Transient, VisibleAnywhere, BlueprintReadOnly, Category = "Movement")
	FBSNSmoothMovementData ReceivedMovementData;

	UPROPERTY(Transient, VisibleAnywhere, BlueprintReadOnly, Category = "Movement")
	float InterpolationTime;

	UPROPERTY(Transient, VisibleAnywhere, BlueprintReadOnly, Category = "Offset")
	FRotator RotationOffset;

protected:
	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Offset")
	float HandOffset;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Offset")
	FVector HeadOffset;

	UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Offset")
	float MinReplicateToServerInterval;

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Tick")
	uint32 bEnableTick : 1;

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Tick")
	uint32 bUpdateMeshTransform : 1;
};
