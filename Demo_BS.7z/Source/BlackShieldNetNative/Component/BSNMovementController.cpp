// Fill out your copyright notice in the Description page of Project Settings.

#include "BlackShieldNetNative.h"
#include "BSNMovementController.h"
#include "Features/IModularFeatures.h"
#include "IHeadMountedDisplay.h"
#include "Player/BSNCharacter.h"
#include "Kismet/HeadMountedDisplayFunctionLibrary.h"
#include "Interface/CharacterAnimInterface.h"
#include "BlackShieldNetNativeConfig.h"

// Sets default values for this component's properties
UBSNMovementController::UBSNMovementController(const FObjectInitializer& ObjectInitializer /*= FObjectInitializer::Get()*/) 
	: Super(ObjectInitializer)
{
	// Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	bWantsBeginPlay = true;
	bWantsInitializeComponent = true;

	bUpdateMeshTransform = true;

	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.TickGroup = TG_PrePhysics;

	ClientMovementData.Initialize();

	HandOffset = -12.0f;

	InterpolationTime = 0.5f;

	ReplicateToServerTime = 0.0f;

	bEnableTick = true;

	MinReplicateToServerInterval = 0.025; // 40 FPS
}

void UBSNMovementController::SetUpdatedMeshComponent(class USkeletalMeshComponent* InMeshComponent)
{
	UpdatedMeshComponent = InMeshComponent;
}

// Called when the game starts
void UBSNMovementController::BeginPlay()
{
	Super::BeginPlay();
}

void UBSNMovementController::InitializeComponent()
{
	Super::InitializeComponent();

	USkeletalMeshComponent* NewUpdatedMeshComponent = nullptr;
	if (UpdatedMeshComponent != nullptr)
	{
		NewUpdatedMeshComponent = UpdatedMeshComponent;
	}

	SetUpdatedMeshComponent(NewUpdatedMeshComponent);
}

void UBSNMovementController::PostInitProperties()
{
	Super::PostInitProperties();

	ReceivedMovementData.OrgData = ClientMovementData;
	ReceivedMovementData.DestData = ClientMovementData;
}

void UBSNMovementController::RemoteSimulatedTick()
{
	float InterpAlpha = (GetWorld()->TimeSeconds - ReceivedMovementData.ReceivedTime) / InterpolationTime;
	InterpAlpha = FMath::Clamp(InterpAlpha, 0.0f, 1.0f);
	
	ClientMovementData = InterpolateSmoothMovement(ReceivedMovementData.OrgData, ReceivedMovementData.DestData, InterpAlpha);

	UpdateCharacterAnimation();

	UpdateMeshTransform();
}

static inline FBSNLocationRotation LerpLocationRotation(const FBSNLocationRotation& A, const FBSNLocationRotation& B, float Alpha)
{
	FBSNLocationRotation Result;

	Result.Location = FMath::Lerp(A.Location, B.Location, Alpha);
	Result.Rotation = FQuat::Slerp(A.Rotation.Quaternion(), B.Rotation.Quaternion(), Alpha).Rotator();

	return Result;
}

FBSNClientMovementData UBSNMovementController::InterpolateSmoothMovement(const FBSNClientMovementData& AData, const FBSNClientMovementData& BData, float Alpha)
{
	FBSNClientMovementData ResultMovementData;

	ResultMovementData.MeshInfo = LerpLocationRotation(AData.MeshInfo, BData.MeshInfo, Alpha);
	ResultMovementData.NeckInfo = LerpLocationRotation(AData.NeckInfo, BData.NeckInfo, Alpha);
	ResultMovementData.LeftHandInfo = LerpLocationRotation(AData.LeftHandInfo, BData.LeftHandInfo, Alpha);
	ResultMovementData.RightHandInfo = LerpLocationRotation(AData.RightHandInfo, BData.RightHandInfo, Alpha);

	return ResultMovementData;
}

void UBSNMovementController::UpdateLocalClientMovementData()
{
	if (OwningCharacter && OwningCharacter->IsLocallyControlled())
	{
		if (GetBlackShieldConfig().InputType == EBSInputType::HTCVive)
		{
			FVector DeviceLocation;
			FRotator DeviceRotation;
			UHeadMountedDisplayFunctionLibrary::GetOrientationAndPosition(DeviceRotation, DeviceLocation);

			SetNeckInfo(DeviceLocation, DeviceRotation);

			SetMeshInfo(DeviceLocation, DeviceRotation);

			SetLeftHandInfo(DeviceLocation, DeviceRotation);

			SetRightHandInfo(DeviceLocation, DeviceRotation);
		}
	}
}

bool UBSNMovementController::ReplicateMoveToServer_Validate(const FBSNClientMovementData& InClinetMovementData, float SentTimeStamp)
{
	return true;
}

void UBSNMovementController::ReplicateMoveToServer_Implementation(const FBSNClientMovementData& InClinetMovementData, float SentTimeStamp)
{
	MulticastMove(InClinetMovementData, SentTimeStamp);
}

void UBSNMovementController::MulticastMove_Implementation(const FBSNClientMovementData& InClinetMovementData, float SentTimeStamp)
{
	if (SentTimeStamp < ReceivedMovementData.SentTimeStamp)
	{
		return;
	}

	ReceivedMovementData.DestData = InClinetMovementData;
	InterpolationTime = GetWorld()->TimeSeconds - ReceivedMovementData.ReceivedTime;
	InterpolationTime = FMath::Clamp(InterpolationTime, 1 / 120.0f, 1 / 5.0f);

	ReceivedMovementData.ReceivedTime = GetWorld()->TimeSeconds;
	ReceivedMovementData.SentTimeStamp = SentTimeStamp;

	ReceivedMovementData.OrgData = ClientMovementData;
}

void UBSNMovementController::SetNeckInfo(const FVector& DeviceLocation, const FRotator& DeviceRotation)
{
	ClientMovementData.NeckInfo.Location = FVector(0, 0, DeviceLocation.Z);
	ClientMovementData.NeckInfo.Rotation = DeviceRotation;

	// Some correction for Neck rotation
	ClientMovementData.NeckInfo.Rotation.Yaw = 0;
	ClientMovementData.NeckInfo.Rotation.Roll += -90.0f;
	ClientMovementData.NeckInfo.Rotation.Pitch += 71.0f;
}

void UBSNMovementController::SetMeshInfo(const FVector& DeviceLocation, const FRotator& DeviceRotation)
{
	ClientMovementData.MeshInfo.Location = FVector(DeviceLocation.X, DeviceLocation.Y, 0);
	ClientMovementData.MeshInfo.Rotation = FRotator(0, DeviceRotation.Yaw, 0);

	RotationOffset = FRotator(0, -DeviceRotation.Yaw, 0);
}

void UBSNMovementController::SetLeftHandInfo(const FVector& DeviceLocation, const FRotator& DeviceRotation)
{
	FVector HandLocation;
	FRotator HandRotation;
	FRotator FinalHandRotation;
	FVector Difference;

	OwningCharacter->GetHandLocationAndRotation(EControllerHand::Left, HandLocation, HandRotation);
	Difference = HandLocation - FVector(DeviceLocation.X, DeviceLocation.Y, 0);
	Difference += CalculateHandOffset(HandRotation, HandOffset);
	ClientMovementData.LeftHandInfo.Location = RotationOffset.RotateVector(Difference);

	FinalHandRotation = HandRotation;
	FinalHandRotation.Roll += -180;
	FinalHandRotation.Yaw -= ClientMovementData.MeshInfo.Rotation.Yaw;
	ClientMovementData.LeftHandInfo.Rotation = FinalHandRotation;
}

void UBSNMovementController::SetRightHandInfo(const FVector& DeviceLocation, const FRotator& DeviceRotation)
{
	FVector HandLocation;
	FRotator HandRotation;
	FRotator FinalHandRotation;
	FVector Difference;

	OwningCharacter->GetHandLocationAndRotation(EControllerHand::Right, HandLocation, HandRotation);
	Difference = HandLocation - FVector(DeviceLocation.X, DeviceLocation.Y, 0);
	Difference += CalculateHandOffset(HandRotation, HandOffset);
	ClientMovementData.RightHandInfo.Location = RotationOffset.RotateVector(Difference);

	FinalHandRotation = HandRotation;
	FinalHandRotation.Yaw -= ClientMovementData.MeshInfo.Rotation.Yaw;
	ClientMovementData.RightHandInfo.Rotation = FinalHandRotation;
}

void UBSNMovementController::UpdateCharacterAnimation()
{
	if (UpdatedMeshComponent)
	{
		UAnimInstance* AnimInstance = UpdatedMeshComponent->GetAnimInstance();
		if (AnimInstance && AnimInstance->Implements<UCharacterAnimInterface>())
		{
			ICharacterAnimInterface::Execute_SetNeckInfo(AnimInstance, ClientMovementData.NeckInfo.Location + HeadOffset, ClientMovementData.NeckInfo.Rotation);
			ICharacterAnimInterface::Execute_SetHandInfo(AnimInstance, EControllerHand::Left, ClientMovementData.LeftHandInfo.Location, ClientMovementData.LeftHandInfo.Rotation);
			ICharacterAnimInterface::Execute_SetHandInfo(AnimInstance, EControllerHand::Right, ClientMovementData.RightHandInfo.Location, ClientMovementData.RightHandInfo.Rotation);
		}
	}
}

FVector UBSNMovementController::CalculateHandOffset(const FRotator& InHandOrientation, float InHandOffset)
{
	return FRotationMatrix(InHandOrientation).GetUnitAxis(EAxis::X) * InHandOffset;
}

void UBSNMovementController::UpdateMeshTransform()
{
	if (UpdatedMeshComponent && bUpdateMeshTransform)
	{
		FVector Offset = FVector::ZeroVector;
		if (!Cast<ACharacter>(GetOwner())->IsLocallyControlled()) {
			Offset = FVector(0,0,sin(GetWorld()->GetTimeSeconds()*3)*2+2);
		}
		UpdatedMeshComponent->SetRelativeLocationAndRotation(ClientMovementData.MeshInfo.Location + Offset, ClientMovementData.MeshInfo.Rotation);

		if (OwningCharacter)
		{
			OwningCharacter->SetVehicleRelativeRotation(ClientMovementData.MeshInfo.Rotation);
		}
	}
}

// Called every frame
void UBSNMovementController::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	if (!bEnableTick) {
		return;
	}

	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (!OwningCharacter || !OwningCharacter->IsLocallyControlled())
	{
		RemoteSimulatedTick();
	}
	else if (OwningCharacter && OwningCharacter->IsLocallyControlled())
	{
		LocallyControlledMotionTick();

		if (GetWorld()->TimeSeconds - ReplicateToServerTime >= MinReplicateToServerInterval)
		{
			ReplicateMoveToServer(ClientMovementData, GetWorld()->TimeSeconds);
			ReplicateToServerTime = GetWorld()->TimeSeconds;
		}
	}

	return;
}

void UBSNMovementController::LocallyControlledMotionTick()
{
	if (UpdatedMeshComponent == nullptr || OwningCharacter == nullptr)
		return;

	UpdateLocalClientMovementData();

	UpdateCharacterAnimation();

	UpdateMeshTransform();
}

void UBSNMovementController::SetTickStatus(bool status)
{
	bEnableTick = status;
}

void UBSNMovementController::SetUpdateMeshTransform(bool status)
{
	bUpdateMeshTransform = status;
}