#pragma once

#include "GameFramework//CharacterMovementComponent.h"
#include "BlackShieldCommons.h"
#include "BSNCharacterMovementComponent.generated.h"

UCLASS(Within=BSNCharacter)
class UBSNCharacterMovementComponent : public UCharacterMovementComponent
{
	GENERATED_BODY()

public:
	UBSNCharacterMovementComponent(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());

	virtual void TickComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction *ThisTickFunction) override;

	void PerformBlinkMove(float DeltaTime);

	void Blink(const FVector& Destination);

	virtual FVector ComputeMoveDelta(const FVector& InVelocity, float DeltaTime) const;

	UFUNCTION(Reliable, Server, WithValidation)
	void StartServerBlink(const FVector& Destination, const FVector& InBlinkDirection);

	virtual bool StartServerBlink_Validate(const FVector& Destination, const FVector& InBlinkDirection);
	virtual void StartServerBlink_Implementation(const FVector& Destination, const FVector& InBlinkDirection);

	UFUNCTION(Reliable, Server, WithValidation)
	void StopServerBlink(const FVector& InCurrentLocation);

	virtual bool StopServerBlink_Validate(const FVector& InCurrentLocation);
	virtual void StopServerBlink_Implementation(const FVector& InCurrentLocation);

protected:
	UPROPERTY(Transient)
	uint8 bWantsToBlink : 1;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Blink")
	float BlinkSpeed;

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Blink")
	FVector BlinkDestination;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Blink")
	FVector BlinkDirection;
};
