#include "BlackShieldNetNative.h"
#include "VRMotionControllerComponent.h"
#include "Features/IModularFeatures.h"
#include "IMotionController.h"

UVRMotionControllerComponent::UVRMotionControllerComponent(const FObjectInitializer& ObjectInitializer /*= FObjectInitializer::Get()*/) 
	: Super(ObjectInitializer)
{
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.bStartWithTickEnabled = true;
	PrimaryComponentTick.TickGroup = TG_PrePhysics;

	PlayerIndex = INDEX_NONE;
	Hand = EControllerHand::Left;

	bLocalPlayerControlled = false;

	bTracked = false;
}

void UVRMotionControllerComponent::TickComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction *ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	FVector Position;
	FRotator Orientation;
	bTracked = PollControllerState(Position, Orientation);
	if (bTracked)
	{
		SetRelativeLocationAndRotation(Position, Orientation);
	}
}

bool UVRMotionControllerComponent::PollControllerState(FVector& Position, FRotator& Orientation)
{
	if (IsInGameThread())
	{
		// Cache state from the game thread for use on the render thread
		const APlayerController* PlayerController = Cast<APlayerController>(GetOwner());
		const APawn* Pawn = Cast<APawn>(GetOwner());
		bLocalPlayerControlled = PlayerController && PlayerController->IsLocalPlayerController();
		if (!bLocalPlayerControlled)
		{
			if (Pawn)
			{
				AController* Controller = Pawn->GetController();
				bLocalPlayerControlled = Controller && Controller->IsLocalPlayerController();
			}
		}
	}

	if (!bLocalPlayerControlled)
		return false;

	if ((PlayerIndex != INDEX_NONE))
	{
		TArray<IMotionController*> MotionControllers = IModularFeatures::Get().GetModularFeatureImplementations<IMotionController>(IMotionController::GetModularFeatureName());
		for (auto MotionController : MotionControllers)
		{
			if ((MotionController != nullptr) && MotionController->GetControllerOrientationAndPosition(PlayerIndex, Hand, Orientation, Position))
			{
				CurrentTrackingStatus = MotionController->GetControllerTrackingStatus(PlayerIndex, Hand);
				return true;
			}
		}
	}
	return false;
}
