#include "BlackShieldNetNative.h"
#include "BSNCharacterMovementComponent.h"
#include "Player/BSNCharacter.h"

UBSNCharacterMovementComponent::UBSNCharacterMovementComponent(const FObjectInitializer& ObjectInitializer /*= FObjectInitializer::Get()*/)
	: Super(ObjectInitializer)
{
	bWantsToBlink = false;
	BlinkSpeed = 9000;
}

void UBSNCharacterMovementComponent::TickComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction *ThisTickFunction)
{
	if (bWantsToBlink && GetOwnerRole() > ROLE_SimulatedProxy)
	{
		PerformBlinkMove(DeltaTime);
	}
	else
	{
		Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
	}
}

void UBSNCharacterMovementComponent::PerformBlinkMove(float DeltaTime)
{
	// Consume Input and saved info
	if (GetCharacterOwner()->IsLocallyControlled())
	{
		ConsumeInputVector();
		FNetworkPredictionData_Client_Character* ClientData = GetPredictionData_Client_Character();
		if (ClientData)
		{
			ClientData->SavedMoves.Empty();
		}
	}

	Velocity = BlinkDirection * BlinkSpeed;

	FVector MoveDelta = ComputeMoveDelta(Velocity, DeltaTime);

	UpdateComponentVelocity();

	if (UpdatedComponent)
	{
		FRotator NewRotator = UpdatedComponent->GetComponentRotation();
		MoveUpdatedComponent(MoveDelta, NewRotator, false);

		FVector UpdatedCompLocation = UpdatedComponent->GetComponentLocation();

		FVector DiffVec = BlinkDestination - UpdatedCompLocation;
		if ((DiffVec | BlinkDirection) <= 0)
		{
			bWantsToBlink = false;
			UpdatedComponent->SetWorldLocation(BlinkDestination);
			Velocity = FVector::ZeroVector;

			if (GetCharacterOwner()->IsControlled())
			{
				StopServerBlink(BlinkDestination);
			}
		}
	}
}

void UBSNCharacterMovementComponent::Blink(const FVector& Destination)
{
	if (!bWantsToBlink)
	{
		BlinkDestination = Destination;
		BlinkDirection = (BlinkDestination - GetActorLocation()).GetSafeNormal();
		bWantsToBlink = true;

		StartServerBlink(BlinkDestination, BlinkDirection);

		ABSNCharacter *pCharacter = Cast<ABSNCharacter>(GetOwner());
		if (pCharacter != NULL)
		{
			pCharacter->SimulateTelportEffect();
		}
	}
}

FVector UBSNCharacterMovementComponent::ComputeMoveDelta(const FVector& InVelocity, float DeltaTime) const
{
	FVector ResultDelta = InVelocity * DeltaTime;
	return ResultDelta;
}

bool UBSNCharacterMovementComponent::StartServerBlink_Validate(const FVector& Destination, const FVector& InBlinkDirection)
{
	return true;
}

void UBSNCharacterMovementComponent::StartServerBlink_Implementation(const FVector& Destination, const FVector& InBlinkDirection)
{
	bWantsToBlink = true;
	BlinkDestination = Destination;
	BlinkDirection = InBlinkDirection;
	
	ABSNCharacter *pCharacter = Cast<ABSNCharacter>(GetOwner());
	if (pCharacter != NULL)
	{
		pCharacter->SimulateTelportEffect();
	}
}

bool UBSNCharacterMovementComponent::StopServerBlink_Validate(const FVector& InCurrentLocation)
{
	return true;
}

void UBSNCharacterMovementComponent::StopServerBlink_Implementation(const FVector& InCurrentLocation)
{
	bWantsToBlink = false;
	UpdatedComponent->SetWorldLocation(InCurrentLocation);
	UpdateComponentVelocity();
	Velocity = FVector::ZeroVector;
}