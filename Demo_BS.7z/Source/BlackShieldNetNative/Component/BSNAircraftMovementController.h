#pragma once

#include "BSNMovementController.h"
#include "BSNAircraftMovementController.generated.h"

UCLASS(BlueprintType)
class UBSNAircraftMovementController : public UBSNMovementController
{
	GENERATED_BODY()

public:
	UBSNAircraftMovementController(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());

	// Called every frame
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	void CanInitSimulate();
	void StartSimulate();
	void StopSimulate();
	void LocallySimulateAnalogInput();

	void InitSimulate();

protected:
	float ProjectToXAxis(float XAxisInput, float YAxisInput, float Yaw);
	float ProjectToYAxis(float XAxisInput, float YAxisInput, float Yaw);

protected:
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Default)
	class UCurveFloat* CurveFloat;

	bool bCanInitSimulate;	// Control Simulation Can Be Init (Called after USBNCharacter::FixesHMDOrientation() executed.)
	bool bCanSimulate;		// Control Enable / Disable Simulation
	bool bSimulate;			// Real Simulation Execute Flag

	FVector DeviceStartLocation;
	FRotator DeviceStartRotation;

	FTimerHandle	TimerHandler_InitSimulation;
};