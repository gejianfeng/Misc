#include "BlackShieldNetNative.h"
#include "BSNSkillManager.h"
#include "Engine/ActorChannel.h"
#include "Skill/SkillBase.h"
#include "Player/BSNCharacter.h"

UBSNSkillManager::UBSNSkillManager(const FObjectInitializer& ObjectInitialzier /*= FObjectInitializer::Get()*/)
	: Super(ObjectInitialzier)
{
	bReplicates = true;
	bWantsBeginPlay = true;
	bWantsInitializeComponent = true;
}

void UBSNSkillManager::LocalPlayerInit()
{
	for (int32 i = 0; i < SkillObjects.Num(); ++i)
	{
		if (SkillObjects[i])
		{
			SkillObjects[i]->LocalPlayerInit();
		}
	}
}

void UBSNSkillManager::OnDying()
{
	DestroySkills();
}

void UBSNSkillManager::InitializeComponent()
{
	Super::InitializeComponent();

	if (GetOwnerRole() == ROLE_Authority)
	{
		OwningCharacter = GetTypedOuter<ABSNCharacter>();

		for (auto SkillClass : BornSkillTypes)
		{
			ASkillBase* SkillObj = GetWorld()->SpawnActor<ASkillBase>(SkillClass);
			if (SkillObj)
			{
				SkillObj->SetOwningCharacter(OwningCharacter);
				SkillObj->AttachToComponent(OwningCharacter->GetSkeletalMesh(), FAttachmentTransformRules::KeepRelativeTransform, SkillObj->GetBindToSocketName());
				SkillObjects.Add(SkillObj);
			}
		}
	}
}

void UBSNSkillManager::UninitializeComponent()
{
	Super::UninitializeComponent();

	DestroySkills();
}

void UBSNSkillManager::DestroySkills()
{
	if (GetOwnerRole() == ROLE_Authority)
	{
		for (auto SkillObj : SkillObjects)
		{
			SkillObj->Destroy();
		}
		SkillObjects.Empty();
	}
}

void UBSNSkillManager::BeginPlay()
{
	Super::BeginPlay();
}

void UBSNSkillManager::OnRep_SkillObjects(const TArray<ASkillBase*>& OldSkillObjects)
{

}

class ASkillBase* UBSNSkillManager::GetFirstSkillObject() const
{
	if (SkillObjects.Num() >= 1)
		return SkillObjects[0];

	return nullptr;
}

class ASkillBase* UBSNSkillManager::GetSecondSkillObject() const
{
	if (SkillObjects.Num() >= 2)
		return SkillObjects[1];

	return nullptr;
}

void UBSNSkillManager::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(UBSNSkillManager, SkillObjects);
	DOREPLIFETIME(UBSNSkillManager, OwningCharacter);
}
