#pragma once

#include "Components/ActorComponent.h"
#include "Skill/SkillEnums.h"
#include "BSNSkillManager.generated.h"

UCLASS(BlueprintType, Config = Skill, Blueprintable, meta=(BlueprintSpawnableComponent))
class UBSNSkillManager : public UActorComponent
{
	GENERATED_BODY()
public:
	UBSNSkillManager(const FObjectInitializer& ObjectInitialzier = FObjectInitializer::Get());

	void LocalPlayerInit();

	void OnDying();

	virtual void InitializeComponent() override;

	virtual void UninitializeComponent() override;

	void DestroySkills();

	virtual void BeginPlay() override;

	UFUNCTION()
	virtual void OnRep_SkillObjects(const TArray<ASkillBase*>& OldSkillObjects);

	class ASkillBase* GetFirstSkillObject() const;

	class ASkillBase* GetSecondSkillObject() const;

	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

public:
	UPROPERTY(Transient, VisibleAnywhere, BlueprintReadOnly, Replicated, Category = "Character")
	class ABSNCharacter* OwningCharacter;

protected:
	UPROPERTY(Transient, VisibleAnywhere, BlueprintReadOnly, ReplicatedUsing = OnRep_SkillObjects)
	TArray<ASkillBase*> SkillObjects;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Skill")
	TArray<TSubclassOf<ASkillBase>> BornSkillTypes;
};
