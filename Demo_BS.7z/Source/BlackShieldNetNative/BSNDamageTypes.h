#pragma once

#include "BSNDamageTypes.generated.h"

UCLASS(BlueprintType, Abstract)
class UBSNPDamageType :public UDamageType
{
	GENERATED_UCLASS_BODY()
};

UCLASS(BlueprintType)
class UBSNPDamageType_Point :public UBSNPDamageType
{
	GENERATED_UCLASS_BODY()
public:
};

UCLASS(BlueprintType)
class UBSNPDamageType_Radial :public UBSNPDamageType
{
	GENERATED_UCLASS_BODY()
public:
	UPROPERTY(EditAnywhere, Category = RadialDamage)
	float InnerRadius;
	UPROPERTY(EditAnywhere, Category = RadialDamage)
	float OuterRadius;
	UPROPERTY(EditAnywhere, Category = RadialDamage)
	float Falloff;
};

