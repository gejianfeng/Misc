
#include "BlackShieldNetNative.h"
#include "BSNEngine.h"
#include "BlackShieldGameInstance.h"
#include "IBSNOnline.h"
#include "BsnNetDriver.h"

UBSNEngine::UBSNEngine(const FObjectInitializer &ObjectInitializer)
	:Super(ObjectInitializer)
{
}

void UBSNEngine::Init(IEngineLoop* InEngineLoop)
{
	FNetDriverDefinition NewDriverEntry;
	NewDriverEntry.DefName = BSNONLINE_MODULE_NAME;
	NewDriverEntry.DriverClassName = *UBsnNetDriver::StaticClass()->GetPathName();
	NewDriverEntry.DriverClassNameFallback = *UBsnNetDriver::StaticClass()->GetPathName();
	NetDriverDefinitions.Add(NewDriverEntry);

	IBNSOnline::Get().Init();

	Super::Init(InEngineLoop);
}

void UBSNEngine::PreExit()
{
	IBNSOnline::Get().UnInit();

	Super::PreExit();
}

void UBSNEngine::HandleNetworkFailure(UWorld *World, UNetDriver *NetDriver, ENetworkFailure::Type FailureType, const FString& ErrorString)
{
	bool bTravel = false;

	if (NetDriver)
	{
		switch (FailureType)
		{
		case ENetworkFailure::FailureReceived:
		case ENetworkFailure::PendingConnectionFailure:
		{
			UBlackShieldGameInstance *GI = Cast<UBlackShieldGameInstance>(GameInstance);
			if (GI && NetDriver->GetNetMode() == NM_Client)
			{
				bTravel = true;
				GI->OnLoginFailed();
			}
			break;
		}
		default: break;
		}
	}

	Super::HandleNetworkFailure(World, NetDriver, FailureType, ErrorString);

	//Travel to level
	if (bTravel && World)
	{
		FString LevelName = World->GetCurrentLevel()->GetOutermost()->GetName();
		SetClientTravel(World, *LevelName, ETravelType::TRAVEL_Absolute);
	}
}