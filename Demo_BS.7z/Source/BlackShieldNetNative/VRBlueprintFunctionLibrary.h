// Fill out your copyright notice in the Description page of Project Settings.

#pragma once
#include "IHeadMountedDisplay.h"
#include "BlackShieldCommons.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "VRBlueprintFunctionLibrary.generated.h"

/**
 * 
 */
UCLASS()
class UVRBlueprintFunctionLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()
	
public:

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = "Config")
	static EBSInputType GetInputType();

	UFUNCTION(BlueprintCallable, meta = (WorldContext = "WorldContextObject"), Category = "Utilities")
	static UObject* LoadAssetSync(UObject* WorldContextObject, const TAssetPtr<UObject>& Asset);

	UFUNCTION(BlueprintCallable, Category = "Game")
		static void ComputeCPUGPUPerfIndex(float& CPUIndex, float& GPUIndex);

	UFUNCTION(BlueprintCallable, Category = "File")
		static bool FileSaveString(FString SaveTextB, FString FileNameB);

	UFUNCTION(BlueprintPure, Category = "File")
		static bool FileLoadString(FString FileNameA, FString& SaveTextA);

	UFUNCTION(BlueprintPure, Category = "Game|Localization")
		static int32 GetLocalizationType();

	UFUNCTION(BlueprintCallable, Category = "Game|Localization")
		static void SetLocalizationType(const int32 LocalType);

	UFUNCTION(BlueprintCallable, Category = "Game")
		static FString GetToken();

	UFUNCTION(BlueprintCallable, Category = "Game")
		static FString GetGameCmdLine();
	UFUNCTION(BlueprintCallable, Category = "Game")
		static bool IsDevelopMode();

	UFUNCTION(BlueprintPure, Category = "Game")
		static bool IsViveDeviceAttached();

	UFUNCTION(BlueprintPure, Category = "Game")
		static bool IsOculusDeviceAttached();
	UFUNCTION(BlueprintPure, Category = "Game")
		static int32 GetAttachedHMDDeviceType();
private:
	static bool IsDeviceAttached(EHMDDeviceType::Type DeviceType);

};
