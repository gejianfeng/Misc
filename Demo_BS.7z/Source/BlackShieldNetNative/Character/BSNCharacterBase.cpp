#include "BlackShieldNetNative.h"
#include "BSNCharacterBase.h"
#include "Game/BSNGameModeBase.h"

ABSNCharacterBase::ABSNCharacterBase(const FObjectInitializer& ObjectInitializer /*= FObjectInitializer::Get()*/)
	: Super(ObjectInitializer)
{
	MaxHealth = 100;
	Health = 0;
	bIsDying = false;
	bInvincible = false;
}

bool ABSNCharacterBase::IsLocalPlayerControlled() const
{
	AController* Controller = GetController();
	if (Controller)
	{
		return Controller->IsLocalPlayerController();
	}

	return false;
}

void ABSNCharacterBase::InitCharAttributes()
{
	if (Role == ROLE_Authority)
	{
		Health = MaxHealth;
		bIsDying = false;
	}
}

void ABSNCharacterBase::SetHealth(int32 InHealth)
{
	int32 OldHealth = Health;

	if (Role == ROLE_Authority)
	{
		Health = FMath::Clamp(InHealth, 0, MaxHealth);

		OnHealthModified(OldHealth);
	}
}

void ABSNCharacterBase::OnHealthModified(int32 OldHealth)
{

}

void ABSNCharacterBase::SetIsDying(bool bInIsDying)
{
	if (Role == ROLE_Authority)
	{
		bool bOldIsDying = bIsDying;
		bIsDying = bInIsDying;
		OnRep_IsDying(bOldIsDying);
	}
}

void ABSNCharacterBase::SetInvincible(bool bInInvincible)
{
	if (Role == ROLE_Authority)
	{
		bool bOldInvincible = bInvincible;
		bInvincible = bInInvincible;

		OnRep_Invincible(bOldInvincible);
	}
}

float ABSNCharacterBase::TakeDamage(float Damage, struct FDamageEvent const& DamageEvent, AController* EventInstigator, AActor* DamageCauser)
{
	bool bCanBeDamage = false;

	if (ABSNGameModeBase* GameMode = GetWorld()->GetAuthGameMode<ABSNGameModeBase>())
	{
		bCanBeDamage = GameMode->CanDamage(EventInstigator, GetController(), DamageCauser);
	}
	if (!bCanBeDamage)
		return 0;

	float AutalDamage = ACharacter::TakeDamage(Damage, DamageEvent, EventInstigator, DamageCauser);

	int32 NewHealth = Health - FMath::RoundToInt(AutalDamage);
	NewHealth = FMath::Clamp<int32>(NewHealth, 0, MaxHealth);
	AutalDamage = Health - NewHealth;
	SetHealth(NewHealth);

	HandleHealthDamaged(AutalDamage, DamageEvent, EventInstigator, DamageCauser);

	return AutalDamage;
}

void ABSNCharacterBase::HandleHealthDamaged(float Damage, struct FDamageEvent const& DamageEvent, class AController* EventInstigator, class AActor* DamageCauser)
{
	OnHealthDamaged(Damage, EventInstigator, DamageCauser);

	if (Health <= 0)
	{
		Die(Damage, DamageEvent, EventInstigator, DamageCauser);
	}
	else
	{
		CharacterHit(Damage, DamageEvent, EventInstigator, DamageCauser);
	}
}

void ABSNCharacterBase::Die(float Damage, struct FDamageEvent const& DamageEvent, class AController* EventInstigator, class AActor* DamageCauser)
{
	if (!CanDie(Damage, DamageEvent, EventInstigator, DamageCauser))
		return;

	OnDead(Damage, EventInstigator, DamageCauser);

	SetIsDying(true);
}

bool ABSNCharacterBase::CanDie(float Damage, struct FDamageEvent const& DamageEvent, class AController* EventInstigator, class AActor* DamageCauser)
{
	if (bIsDying										// already dying
		|| IsPendingKill()								// already destroyed
		|| Role != ROLE_Authority						// not authority
		|| GetWorld()->GetAuthGameMode() == NULL
		|| GetWorld()->GetAuthGameMode()->GetMatchState() == MatchState::LeavingMap)	// level transition occurring
	{
		return false;
	}

	return true;
}

void ABSNCharacterBase::CharacterHit(float Damage, struct FDamageEvent const& DamageEvent, class AController* EventInstigator, class AActor* DamageCauser)
{

}

void ABSNCharacterBase::OnRep_Health(int32 OldHealth)
{
	OnHealthModified(OldHealth);
}

void ABSNCharacterBase::OnRep_IsDying(bool bOldIsDying)
{

}

void ABSNCharacterBase::OnRep_Invincible(bool bOldInvincible)
{
	
}

void ABSNCharacterBase::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(ABSNCharacterBase, bIsDying);
	DOREPLIFETIME(ABSNCharacterBase, MaxHealth);
	DOREPLIFETIME(ABSNCharacterBase, Health);
	DOREPLIFETIME(ABSNCharacterBase, bInvincible);
}

void ABSNCharacterBase::PostInitializeComponents()
{
	Super::PostInitializeComponents();

	InitCharAttributes();
}
