#pragma once

#include "GameFramework/Character.h"
#include "BSNCharacterBase.generated.h"

UCLASS(BlueprintType)
class ABSNCharacterBase : public ACharacter
{
	GENERATED_BODY()

public:
	ABSNCharacterBase(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());

	bool IsLocalPlayerControlled() const;

	virtual void InitCharAttributes();

	virtual int32 GetHealth() const { return Health; }

	UFUNCTION(BlueprintCallable, Category = Pawn)
	virtual void SetHealth(int32 InHealth);

	virtual void OnHealthModified(int32 OldHealth);

	UFUNCTION(BlueprintCallable, Category = Pawn)
	virtual void SetIsDying(bool bInIsDying);

	bool GetIsDying() const { return bIsDying; }

	UFUNCTION(BlueprintCallable, Category = Pawn)
	virtual void SetInvincible(bool bInInvincible);

	bool GetInvincible() const { return bInvincible; }

	// Damage
	virtual float TakeDamage(float Damage, struct FDamageEvent const& DamageEvent, AController* EventInstigator, AActor* DamageCauser) override;
	virtual void HandleHealthDamaged(float Damage, struct FDamageEvent const& DamageEvent, class AController* EventInstigator, class AActor* DamageCauser);
	virtual void Die(float Damage, struct FDamageEvent const& DamageEvent, class AController* EventInstigator, class AActor* DamageCauser);
	virtual bool CanDie(float Damage, struct FDamageEvent const& DamageEvent, class AController* EventInstigator, class AActor* DamageCauser);
	virtual void CharacterHit(float Damage, struct FDamageEvent const& DamageEvent, class AController* EventInstigator, class AActor* DamageCauser);

	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = Damage)
	void OnHealthDamaged(float Damage, class AController* EventInstigator, class AActor* DamageCauser);

	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = Damage)
	void OnDead(float Damage, class AController* EventInstigator, class AActor* DamageCauser);

	UFUNCTION()
	virtual void OnRep_Health(int32 OldHealth);

	UFUNCTION()
	virtual void OnRep_IsDying(bool bOldIsDying);

	UFUNCTION(BlueprintCallable, Category = Pawn)
	virtual void OnRep_Invincible(bool bOldInvincible);

	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

	virtual void PostInitializeComponents() override;

protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, ReplicatedUsing = OnRep_Health, Category = Pawn)
	int32 Health;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Replicated, Category = Pawn)
	int32 MaxHealth;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, ReplicatedUsing = OnRep_IsDying, Category = Pawn)
	uint32 bIsDying : 1;

	// Means the player can not be damaged
	UPROPERTY(EditAnywhere, BlueprintReadOnly, ReplicatedUsing = OnRep_Invincible, Category = Pawn)
	uint32 bInvincible : 1;
};
