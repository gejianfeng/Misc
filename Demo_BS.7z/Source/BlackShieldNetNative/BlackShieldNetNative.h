// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "Engine.h"
#include "UnrealNetwork.h"

extern class FBlackShieldNetNativeModule* g_BlackShieldNetNativeModule;

DECLARE_LOG_CATEGORY_EXTERN(LogBlackShield, Log, All);


//Define Collision Channels
#define ECC_TeleportWall ECC_GameTraceChannel14