
#include "BlackShieldNetNative.h"
#include "BSNDamageTypes.h"

UBSNPDamageType::UBSNPDamageType(const FObjectInitializer &ObjectIntializer)
	:Super(ObjectIntializer)
{
}

UBSNPDamageType_Point::UBSNPDamageType_Point(const FObjectInitializer &ObjectIntializer)
	: Super(ObjectIntializer)
{
}

UBSNPDamageType_Radial::UBSNPDamageType_Radial(const FObjectInitializer &ObjectIntializer)
	: Super(ObjectIntializer)
{
}


