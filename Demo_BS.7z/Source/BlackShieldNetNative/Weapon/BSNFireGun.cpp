// Fill out your copyright notice in the Description page of Project Settings.

#include "BlackShieldNetNative.h"
#include "BSNFireGun.h"
#include "Animation/BSNAnimInstance.h"

ABSNFireGun::ABSNFireGun(const FObjectInitializer &ObjectIntializer)
	:Super(ObjectIntializer)
{
}

void ABSNFireGun::SimulateWeaponFire()
{
	if (Role == ROLE_Authority && CurrentState != EGunState::Firing)
	{
		return;
	}

	if (BSNOwner)
	{
		SetMuzzleFX(MuzzleFX);

		UBSNAnimInstance *AnimInstance = BSNOwner->GetAnimInstance();
		if (AnimInstance != NULL)
		{
			ICharacterAnimInterface::Execute_SetHandAction(AnimInstance, EControllerHand::Right, EBSHandAction::Fire);
		}

		if (FireSound != NULL)
		{
			UGameplayStatics::SpawnSoundAttached(FireSound, FireSpot);
		}

		if (Role == ROLE_Authority)
		{
			FireWeapon();
		}
		 
		APlayerController *PC = Cast<APlayerController>(BSNOwner->GetController());
		if (PC && PC->IsLocalController())
		{
			if (FireCameraShake != NULL)
			{
				PC->ClientPlayCameraShake(FireCameraShake, 1.0f);
			}
			if (FireFeedbackCurve)
			{
				ICharacterAnimInterface::Execute_FireActionWithRecoil(AnimInstance, EControllerHand::Right, GetAttachSocketName(), FireFeedbackCurve);
			}
		}
	}
}

void ABSNFireGun::StopSimulatingWeaponFire()
{
	Super::StopSimulatingWeaponFire();

	if (MuzzlePSC != NULL)
	{
		MuzzlePSC->Deactivate();
	}
}

