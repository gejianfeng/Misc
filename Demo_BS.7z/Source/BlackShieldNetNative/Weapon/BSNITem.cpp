// Fill out your copyright notice in the Description page of Project Settings.

#include "BlackShieldNetNative.h"
#include "BSNITem.h"
#include "Game/BSNGameState.h"
#include "Player/BSNCharacter.h"
#include "Weapon/BSNGun.h"
#include "Weapon/BSNHealthPotion.h"

ABSNItem::ABSNItem(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
	,PickEffect(NULL)
{
	RootComponent = ObjectInitializer.CreateDefaultSubobject<USceneComponent>(this, TEXT("Root"));
	WeaponMeshComponent = ObjectInitializer.CreateDefaultSubobject<UStaticMeshComponent>(this, TEXT("Weapon"));
	WeaponMeshComponent->SetupAttachment(RootComponent);
	WeaponMeshComponent->SetCollisionProfileName("Weapon");
}

void ABSNItem::PostInitializeComponents()
{
	Super::PostInitializeComponents();

	if (WeaponMeshComponent != NULL)
	{
		WeaponMeshComponent->SetStaticMesh(Mesh);
	}
}

void ABSNItem::OnConstruction(const FTransform& Transform)
{
	Super::OnConstruction(Transform);

	if (WeaponMeshComponent != NULL)
	{
		WeaponMeshComponent->SetStaticMesh(Mesh);
	}
}

void ABSNItem::OnRep_BSNOwner()
{
}

void ABSNItem::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
	DOREPLIFETIME(ABSNItem, BSNOwner);
}

/////////////////////////////////////////////////////////////////////////////
FItemDataRow *ABSNItem::GetRow(const FName &InRowName)
{
	UDataTable *pPropTable = (UDataTable *)StaticLoadObject(UDataTable::StaticClass(), NULL, TEXT("DataTable'/Game/BlackShieldNew/Table/DT_Item.DT_Item'"));
	if (pPropTable != NULL)
	{
		FItemDataRow *pPropData = pPropTable->FindRow<FItemDataRow>(InRowName, TEXT(""));
		return pPropData;
	}
	return NULL;
}

void ABSNItem::InstanceItemByItemInfo(ABSNItem *pItemActor, const FName &InName)
{
	ABSNItem *pItemInstance = NULL;

	if (ABSNGun *pWeapon = Cast<ABSNGun>(pItemActor))
	{
		FGunDataRow *pWeaponData = ABSNGun::GetRow(InName);
		if (pWeaponData != NULL)
		{
			pWeapon->Config = *pWeaponData;
		}
	}
	else if (ABSNHeathPotion *pHealthPotion = Cast<ABSNHeathPotion>(pItemActor))
	{
		FHeathPotionDataRow *pHealthPotionData = ABSNHeathPotion::GetRow(InName);
		if (pHealthPotion != NULL)
		{
			pHealthPotion->Config = *pHealthPotionData;
		}
	}
	else
	{
		FItemDataRow *pItemInfo = ABSNItem::GetRow(InName);
		if (pItemInfo!=NULL)
		{
			pItemActor->ItemInfo = *pItemInfo;
		}
	}
}

//////////////////////////////////////////////////////////////////////////
ABSAttachableItem::ABSAttachableItem(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{
}

