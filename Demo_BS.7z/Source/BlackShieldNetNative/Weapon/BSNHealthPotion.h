// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "GameFramework/Actor.h"
#include "BSNItem.h"
#include "BSNHealthPotion.generated.h"


USTRUCT(BlueprintType)
struct FHeathPotionDataRow :public FTableRowBase
{
	GENERATED_USTRUCT_BODY()
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	int32 HealthGive;
};

UCLASS(notplaceable)
class ABSNHeathPotion : public ABSNItem
{
	GENERATED_UCLASS_BODY()
public:
	static FHeathPotionDataRow *GetRow(const FName &InRowName);
public:
	UPROPERTY(EditDefaultsOnly, Category = Config)
	FHeathPotionDataRow Config;
};

