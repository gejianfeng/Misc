// Fill out your copyright notice in the Description page of Project Settings.

#include "BlackShieldNetNative.h"
#include "BSNGun.h"
#include "BSNBullet.h"
#include "Player/BSNCharacter.h"
#include "WeaponInterface.h"


FGunDataRow::FGunDataRow()
{
	MaxAmmo = 120;
	AmmoPerClip = 15;
	MaxClips = 10;
	InitClips = 6;
	Spread = 0.0f;
	TimeBetweenShots = 0.2f;
	NoAnimReloadDuration = 1.f;
	ItemClass = nullptr;
	bRepeatFire = true;
}

FInstantHitInfo::FInstantHitInfo()
	:EnsureReplicationByte(0)
{
}

void FInstantHitInfo::EnsureReplication()
{
	EnsureReplicationByte++;
}

//////////////////////////////////////////////////////////////////////////
ABSNGun::ABSNGun(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
	,bWantsToFire(false)
	,bPendingReload(false)
	,CurrentState(EGunState::Idle)
	,BurstCounter(0)
	,LastFireTime(0)
	,bRefiring(false)
	,MuzzlePSC(NULL)
	,BulletPSC(NULL)
	,TextComponent(NULL)
	,BulletTrailFX(NULL)
	,BulletExplodeFX(NULL)
{
	bIsUseBulletHit = true;
	BulletSpeed = 600;
	BulletRadius = 10.0f;

	Config.WeaponType = EGunType::FireGun;
	Config.SlotType = EWeaponSlotType::RightHand;
	
	FireSpot = ObjectInitializer.CreateDefaultSubobject<USceneComponent>(this, TEXT("FireSpot"));
	if (!FireSpot->IsAttachedTo(RootComponent))
	{
		FireSpot->SetupAttachment(RootComponent);
	}

	GuiSpot = ObjectInitializer.CreateDefaultSubobject<USceneComponent>(this, TEXT("GuiSpot"));
	GuiSpot->SetupAttachment(RootComponent);

	TextComponent = ObjectInitializer.CreateDefaultSubobject<UTextRenderComponent>(this,TEXT("Text"));
	TextComponent->SetupAttachment(GuiSpot);
	TextComponent->SetHorizontalAlignment(EHTA_Center);

	MuzzlePSC = ObjectInitializer.CreateAbstractDefaultSubobject<UParticleSystemComponent>(this, TEXT("MazzlePSC"));
	MuzzlePSC->bAutoDestroy = false;
	MuzzlePSC->bAllowAnyoneToDestroyMe = true;
	MuzzlePSC->SecondsBeforeInactive = 0.0f;
	MuzzlePSC->bAutoActivate = false;
	MuzzlePSC->bOverrideLODMethod = false;
	MuzzlePSC->SetupAttachment(FireSpot);

	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickGroup = TG_PrePhysics;
	SetRemoteRoleForBackwardsCompat(ROLE_SimulatedProxy);
	bReplicates = true;
	bNetUseOwnerRelevancy = true;
}

void ABSNGun::PostInitProperties()
{
	Super::PostInitProperties();

	if (Config.InitClips > 0)
	{
		CurrentAmmoInClip = Config.AmmoPerClip;
		CurrentAmmo = Config.AmmoPerClip * Config.InitClips;
		if (GetNetMode() != NM_DedicatedServer)
		{
			UpdateText();
		}
	}
}
void ABSNGun::PostInitializeComponents()
{
	Super::PostInitializeComponents();
	//WeaponCombine
	UDataTable *pDataTable = (UDataTable *)StaticLoadObject(UDataTable::StaticClass(), NULL, TEXT("DataTable'/Game/BlackShieldNew/Table/DT_WeaponCombine.DT_WeaponCombine'"));
	SetWeaponCombineBaseType(pDataTable,GetClass());
}

void ABSNGun::UpdateText()
{
	if (TextComponent != NULL)
	{
		bool bInfiniteAmmo = HasInfiniteAmmo();

		if (bInfiniteAmmo)
		{
			TextComponent->SetVisibility(false);
		}
		else
		{
			FString Desc = FString::Printf(TEXT("%d/%d"), CurrentAmmoInClip, CurrentAmmo);
			TextComponent->SetText(FText::FromString(Desc));
		}
	}
}

void ABSNGun::OnRep_Ammo()
{
	UpdateText();
}

void ABSNGun::OnRep_AmmoInClip()
{
	UpdateText();
}

void ABSNGun::StartFire()
{
	if (Role < ROLE_Authority)
	{
		ServerStartFire();
	}

	if (!bWantsToFire)
	{
		bWantsToFire = true;
		DetermineWeaponState();
	}
}

void ABSNGun::StopFire()
{
	if (Role < ROLE_Authority)
	{
		ServerStopFire();
	}
	
	if (bWantsToFire)
	{
		bWantsToFire = false;
		DetermineWeaponState();
	}
}

void ABSNGun::DetermineWeaponState()
{
	EGunState NewState = EGunState::Idle;
	if (BSNOwner)
	{
		if (bPendingReload)
		{
			if (CanReload())
			{
				NewState = EGunState::Reloading;
			}
			else
			{
				NewState = CurrentState;
			}
		}
		else if ((bPendingReload == false) && (bWantsToFire == true) && (CanFire() == true))
		{
			NewState = EGunState::Firing;
		}
	}
	SetWeaponState(NewState);
}

void ABSNGun::SetWeaponState(EGunState NewState)
{
	const EGunState PrevState = CurrentState;

	if (PrevState == EGunState::Firing && NewState != EGunState::Firing)
	{
		OnBurstFinished();
	}

	CurrentState = NewState;

	if (PrevState != EGunState::Firing && NewState == EGunState::Firing)
	{
		OnBurstStarted();
	}
}

void ABSNGun::OnRep_BSNOwner()
{
	if (BSNOwner)
	{
		check(BSNOwner == GetOwner());
		BSNOwner->EquipWeapon(this, true);
		UpdateText();
	}
}

bool ABSNGun::ServerStartFire_Validate()
{
	return true;
}

void ABSNGun::ServerStartFire_Implementation()
{
	StartFire();
}

bool ABSNGun::ServerStopFire_Validate()
{
	return true;
}

void ABSNGun::ServerStopFire_Implementation()
{
	StopFire();
}

void ABSNGun::OnRep_Reload()
{
	if (bPendingReload)
	{
		StartReload(true);
	}
	else
	{
		StopReload();
	}
}

void ABSNGun::OnRep_BurstCounter()
{
	if (BurstCounter > 0)
	{
		SimulateWeaponFire();
	}
	else
	{
		StopSimulatingWeaponFire();
	}
}

void ABSNGun::OnBurstStarted()
{
	// start firing, can be delayed to satisfy TimeBetweenShots
	const float GameTime = GetWorld()->GetTimeSeconds();
	if (LastFireTime > 0 && Config.TimeBetweenShots > 0.0f &&
		LastFireTime + Config.TimeBetweenShots > GameTime)
	{
		GetWorldTimerManager().SetTimer(TimerHandle_HandleFiring, this, &ABSNGun::HandleFiring, LastFireTime + Config.TimeBetweenShots - GameTime, false);
	}
	else
	{
		HandleFiring();
	}
}

void ABSNGun::OnBurstFinished()
{
	// stop firing FX on remote clients
	BurstCounter = 0;

	// stop firing FX locally, unless it's a dedicated server
	if (GetNetMode() != NM_DedicatedServer)
	{
		StopSimulatingWeaponFire();
	}

	GetWorldTimerManager().ClearTimer(TimerHandle_HandleFiring);
	bRefiring = false;
}

void ABSNGun::HandleFiring()
{
	if ((CurrentAmmoInClip > 0 || HasInfiniteClip() || HasInfiniteAmmo()) && CanFire())
	{
		if (BSNOwner && BSNOwner->IsLocallyControlled())
		{
			SimulateWeaponFire();
			UseAmmo();
			BurstCounter++;
		}
	}
	else if (CanReload())
	{
		StartReload();
	}
	else if (BSNOwner && BSNOwner->IsLocallyControlled())
	{
		if (BurstCounter > 0)
		{
			OnBurstFinished();
		}
	}

	if (BSNOwner && BSNOwner->IsLocallyControlled())
	{
		if (Role < ROLE_Authority)
		{
			ServerHandleFiring();
		}

		if (CurrentAmmoInClip < 0 && CanReload())
		{
			StartReload();
		}

		bRefiring = (CurrentState == EGunState::Firing && Config.bRepeatFire);
		if (bRefiring)
		{
			GetWorldTimerManager().SetTimer(TimerHandle_HandleFiring, this, &ABSNGun::HandleFiring, Config.TimeBetweenShots, false);
		}
	}

	LastFireTime = GetWorld()->GetTimeSeconds();
}

bool ABSNGun::ServerHandleFiring_Validate()
{
	return true;
}

void ABSNGun::ServerHandleFiring_Implementation()
{
	DetermineWeaponState();
	const bool bShouldUpdateAmmo = (CurrentAmmoInClip > 0 && CanFire());
	
	HandleFiring();

	if (bShouldUpdateAmmo)
	{
		SimulateWeaponFire();
		UseAmmo();
		BurstCounter++;
	}
}

void ABSNGun::SetMuzzleFX(UParticleSystem *InMuzzleFX)
{
	if (InMuzzleFX)
	{
		MuzzlePSC->SetTemplate(InMuzzleFX);
		MuzzlePSC->Activate(true);
	}
	else
	{
		MuzzlePSC->Deactivate();
	}
}

void ABSNGun::SimulateWeaponFire()
{
	if (Role == ROLE_Authority && CurrentState != EGunState::Firing)
	{
		return;
	}

	if (BSNOwner)
	{
		SetMuzzleFX(MuzzleFX);

		UBSNAnimInstance *AnimInstance = BSNOwner->GetAnimInstance();
		if (AnimInstance != NULL)
		{
			ICharacterAnimInterface::Execute_SetHandAction(AnimInstance, EControllerHand::Right, EBSHandAction::Fire);
		}

		if (FireSound != NULL)
		{
			UGameplayStatics::SpawnSoundAttached(FireSound, FireSpot);
		}

		FireWeapon();

		APlayerController *PC = Cast<APlayerController>(BSNOwner->GetController());
		if (PC && PC->IsLocalController())
		{
			if (FireCameraShake != NULL)
			{
				PC->ClientPlayCameraShake(FireCameraShake, 1.0f);
			}
			if (FireFeedbackCurve)
			{
				ICharacterAnimInterface::Execute_FireActionWithRecoil(AnimInstance, EControllerHand::Right, GetAttachSocketName(), FireFeedbackCurve);
			}
		}
	}
}

void ABSNGun::StopSimulatingWeaponFire()
{
}

bool ABSNGun::CanReload()
{
	return CurrentAmmo > 0;
}

void ABSNGun::StartReload(bool bReplicateFromServer/* = false*/)
{
	if (!bReplicateFromServer && Role < ROLE_Authority)
	{
		ServerStartReload();
	}
	else
	{
		if (bReplicateFromServer || !bPendingReload)
		{
			UBSNAnimInstance *AnimInstance = BSNOwner ? Cast<UBSNAnimInstance>(BSNOwner->GetAnimInstance()) : NULL;
			if (AnimInstance != NULL)
			{
				ICharacterAnimInterface::Execute_SetHandAction(AnimInstance, EControllerHand::Right, EBSHandAction::Reload);
				float ReloadTime = 1.0f;
				GetWorldTimerManager().SetTimer(TimerHandle_HandleReload, this, &ABSNGun::StopReload, ReloadTime, false);
			}
			bPendingReload = true;
			DetermineWeaponState();
		}
	}
}

bool ABSNGun::ServerStartReload_Validate()
{
	return true;
}

void ABSNGun::ServerStartReload_Implementation()
{
	StartReload();
}

void ABSNGun::StopReload()
{
	if (CurrentState == EGunState::Reloading)
	{
		bPendingReload = false;
		DetermineWeaponState();
	}

	if (Role == ROLE_Authority)
	{
		CurrentAmmoInClip = FMath::Min(Config.AmmoPerClip, CurrentAmmo) ;
	}

	if (GetNetMode() != NM_DedicatedServer)
	{
		UpdateText();
	}
}

void ABSNGun::FireWeapon()
{
	if (bIsUseBulletHit)
	{
		FVector FireLoc, FireDir;
		GetFireLocationAndDirection(FireLoc, FireDir);
		FTransform BulletInitTransform(FireDir.Rotation(), FireLoc);

		ABSNBullet_Instance *Bullet = GetWorld()->SpawnActorDeferred<ABSNBullet_Instance>(ABSNBullet_Instance::StaticClass(), BulletInitTransform);
		Bullet->pWeapon = this;
		Bullet->FinishSpawning(BulletInitTransform);
	}
	else
	{
		FVector ShootTrace, ShootEnd, ShootDir;
		GetFireLocationAndDirection(ShootTrace, ShootDir);
		ShootEnd = ShootTrace + ShootDir * Config.WeaponRange;

		const FHitResult Impact = WeaponTrace(ShootTrace, ShootEnd);
		ProcessHit(Impact, ShootTrace, ShootDir);
	}
}

FHitResult ABSNGun::WeaponTrace(const FVector &StartTrace, const FVector &EndTrace)
{
	static FName WeaponTraceTag = FName(TEXT("WeaponTrace"));

	FCollisionQueryParams TraceParams(WeaponTraceTag, true, BSNOwner);
	TraceParams.bTraceAsyncScene = true;
	TraceParams.bReturnPhysicalMaterial = true;
	TraceParams.AddIgnoredActor(this);
	TraceParams.AddIgnoredActor(GetOwner());

	FHitResult Hit(ForceInit);
	GetWorld()->LineTraceSingleByChannel(Hit, StartTrace, EndTrace, ECC_GameFireChannel, TraceParams);

	return Hit;
}

void ABSNGun::ProcessHit(const FHitResult &Impact, const FVector &StartTrace, const FVector &ShootDir)
{
	APlayerController *MyController = GEngine->GetFirstLocalPlayerController(GetWorld());
	if (BSNOwner && BSNOwner->GetController()==MyController && GetNetMode() == NM_Client)
	{
		if (Impact.GetActor() && Impact.GetActor()->GetRemoteRole() == ROLE_Authority)
		{
			ServerNotifyHit(Impact, ShootDir);
		}
		else if (Impact.GetActor() == NULL)
		{
			if (Impact.bBlockingHit)
			{
				ServerNotifyHit(Impact, ShootDir);
			}
			else
			{
				ServerNotifyMiss(ShootDir);
			}
		}
	}
	ProcessHitComfirmed(Impact, StartTrace, ShootDir);
}

void ABSNGun::ProcessHitComfirmed(const FHitResult &Impact, const FVector &StartTrace, const FVector &ShootDir)
{
	AActor *TestActor = Impact.GetActor();
	
	if ( TestActor && GetNetMode() != NM_Client && 
		 TestActor->Role == ROLE_Authority && !TestActor->bTearOff)
	{
		DealDamage(Impact, ShootDir);
	}

	if (Role == ROLE_Authority)
	{
		HitNotify.StartTace = StartTrace;
		HitNotify.EndTrace = StartTrace + ShootDir*Config.WeaponRange;
		HitNotify.EnsureReplication();
	}

	if (GetNetMode() != NM_DedicatedServer)
	{
		FVector EndTrace = StartTrace + ShootDir*Config.WeaponRange;
		FVector EndPoint = Impact.GetActor() ? Impact.ImpactPoint : EndTrace;

		SimulateHit(EndPoint, Impact);
	}
}

bool ABSNGun::ServerNotifyHit_Validate(const FHitResult &Impact, const FVector &ShootDir)
{
	return true;
}

void ABSNGun::ServerNotifyHit_Implementation(const FHitResult &Impact, const FVector &ShootDir)
{
	if (BSNOwner && (Impact.GetActor() || Impact.bBlockingHit))
	{
		FVector Original, FireDir;
		GetFireLocationAndDirection(Original, FireDir);
		FVector ViewDir = (Impact.Location - Original).GetSafeNormal();
		ProcessHitComfirmed(Impact, Original, ViewDir);
	}
}

bool ABSNGun::ServerNotifyMiss_Validate(const FVector &ShootDir)
{
	return true;
}

void ABSNGun::ServerNotifyMiss_Implementation(const FVector &ShootDir)
{
	if (GetNetMode() != NM_DedicatedServer)
	{
		FVector Original, FireDir;
		GetFireLocationAndDirection(Original, FireDir);
		FVector EndPoint = Original + ShootDir * Config.WeaponRange;
		SpawnTrailEffect(EndPoint);
	}
}

void ABSNGun::DealDamage(const FHitResult &Impact, const FVector &ShootDir)
{
	FPointDamageEvent PointDamage;
	PointDamage.DamageTypeClass = Config.DamageType;
	PointDamage.HitInfo = Impact;
	PointDamage.ShotDirection = ShootDir;
	PointDamage.Damage = Config.HitDamage;
	Impact.GetActor()->TakeDamage(PointDamage.Damage, PointDamage, BSNOwner->GetController(), this);
}

void ABSNGun::SpawnTrailEffect(const FVector &EndPosition)
{
	if (BulletTrailFX != NULL)
	{
		UGameplayStatics::SpawnEmitterAtLocation(this, BulletTrailFX, EndPosition);
	}
}

static float const_effect_offset = 20.0f;

void ABSNGun::SpawnImpactEffect(const FHitResult &Impact)
{
	if (Impact.bBlockingHit && BulletExplodeFX != NULL)
	{
		FVector ExplodePoint = Impact.ImpactPoint + const_effect_offset*Impact.ImpactNormal;
		UGameplayStatics::SpawnEmitterAtLocation(this, BulletExplodeFX, ExplodePoint);
	}
}

void ABSNGun::SpawnDecals(const FHitResult &Impact)
{
	UObject *WeaponInstance = GetWeaponInterface(GetGameInstance());
	if (WeaponInstance != NULL)
	{
		UPhysicalMaterial *PM = Impact.PhysMaterial.Get();
		EPhysicalSurface SurfaceType = PM? PM->SurfaceType : SurfaceType_Default;

		UMaterialInterface *DecalMtrl = NULL;
		float DecalSize = 12.0f, LifeSpan = 3.0f;
		IWeaponInterface::Execute_GetDecal(WeaponInstance, SurfaceType, DecalMtrl, DecalSize, LifeSpan);

		if (DecalMtrl != NULL)
		{
			UGameplayStatics::SpawnDecalAtLocation(this, DecalMtrl, FVector(DecalSize), Impact.ImpactPoint, Impact.ImpactNormal.Rotation(), LifeSpan);
		}
	}
}

void ABSNGun::OnRep_HitNotify()
{
	if (BSNOwner && !BSNOwner->IsLocallyControlled())
	{
		FHitResult Hit = WeaponTrace(HitNotify.StartTace, HitNotify.EndTrace);
		FVector EndPoint = Hit.GetActor() ? Hit.ImpactPoint : HitNotify.EndTrace;
		SimulateHit(EndPoint, Hit);
	}
}

void ABSNGun::SimulateHit(const FVector &EndPoint,const FHitResult &Hit)
{
	if (Hit.GetActor())
	{
		SpawnImpactEffect(Hit);
		SpawnDecals(Hit);
	}
	else
	{
		SpawnTrailEffect(EndPoint);
	}
}

void ABSNGun::UseAmmo()
{
	bool bInfiniteAmmo = HasInfiniteAmmo();

	if (!bInfiniteAmmo)
	{
		if (CurrentAmmoInClip > 0)
		{
			CurrentAmmoInClip--;
		}
		else
		{
			StartReload(false);
		}

		if (CurrentAmmo > 0)
		{
			CurrentAmmo--;
		}

		if (CurrentAmmo <= 0 && BSNOwner)
		{
			EWeaponSlotType slot = GetSlotType();
			BSNOwner->UnEquipWeapon((uint8)slot);
		}

		UpdateText();
	}
}

void ABSNGun::SetAmmo(int32 InAmmoCount)
{
	CurrentAmmoInClip = InAmmoCount % Config.AmmoPerClip;
	CurrentAmmo = InAmmoCount;
}

int32 ABSNGun::GetCurrentAmmo()
{
	return CurrentAmmo;
}

void ABSNGun::GiveAmmo(uint32 InAmmoCount)
{
	if (InAmmoCount > 0)
	{
		CurrentAmmo += InAmmoCount;
		UpdateText();
	}
}

FName ABSNGun::GetAttachSocketName()
{
	FName SocketName = NAME_None;
	switch (Config.SlotType)
	{
		case EWeaponSlotType::LeftHand:
			SocketName = TEXT("LeftWeaponSocket");
			break;
		case EWeaponSlotType::RightHand:
			SocketName = TEXT("RightWeaponSocket");
			break;
		case EWeaponSlotType::Max:
			break;

	default:
		break;
	}
// 	switch (Config.WeaponType)
// 	{
// 		case EGunType::HandGun:
// 		{
// 			SocketName = TEXT("HandGun");
// 			break;
// 		}
// 		case EGunType::FireGun:
// 		{
// 			SocketName = TEXT("FireGun");
// 			break;
// 		}
// 		case EGunType::MachineGun:
// 		{
// 			SocketName = TEXT("MachineGun");
// 			break;
// 		}
// 		case EGunType::ShotGun:
// 		{
// 			SocketName = TEXT("ShotGun");
// 			break;
// 		}
// 		default: break;
// 	}
	return SocketName;
}

FGunDataRow *ABSNGun::GetRow(const FName &InRowName)
{
	UDataTable *pPropTable = (UDataTable *)StaticLoadObject(UDataTable::StaticClass(), NULL, TEXT("DataTable'/Game/BlackShieldNew/Table/DT_Gun.DT_Gun'"));
	if (pPropTable != NULL)
	{
		FGunDataRow *pPropData = pPropTable->FindRow<FGunDataRow>(InRowName, TEXT(""));
		return pPropData;
	}
	return NULL;
}

void ABSNGun::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
	DOREPLIFETIME_CONDITION(ABSNGun, bPendingReload, COND_SkipOwner);
	DOREPLIFETIME_CONDITION(ABSNGun, CurrentAmmo, COND_OwnerOnly);
	DOREPLIFETIME_CONDITION(ABSNGun, CurrentAmmoInClip, COND_OwnerOnly);
	DOREPLIFETIME_CONDITION(ABSNGun, BurstCounter, COND_SkipOwner);
	DOREPLIFETIME(ABSNGun, HitNotify);
}
void ABSNGun::SetWeaponCombineBaseType(UDataTable *pDataTable,TSubclassOf<ABSNGun> WeaponType)
{
	if (WeaponType)
	{
		FName RowName = NAME_None;
		if (ABSNCharacter::FindElementFromWeaponCombineArray(WeaponType, RowName))
		{
//			UDataTable *pDataTable = (UDataTable *)StaticLoadObject(UDataTable::StaticClass(), NULL, TEXT("DataTable'/Game/BlackShieldNew/Table/DT_WeaponCombine.DT_WeaponCombine'"));
			if (pDataTable)
			{
				FWeaponCombine *GunCombineData = pDataTable->FindRow<FWeaponCombine>(RowName, TEXT(""));
				SetWeaponCombineBaseType(pDataTable,GunCombineData->FirstWeaponType);
				SetWeaponCombineBaseType(pDataTable,GunCombineData->SecondWeaponType);
			}
		}
		else
		{
			WeaponCombineBaseTypeArray.AddUnique(WeaponType);
		}
	}	
}

void ABSNGun::GetFireLocationAndDirection(FVector &OutLocation, FVector &OutDirection)
{
	OutDirection = FireSpot->GetForwardVector();
	OutLocation = FireSpot->GetComponentLocation();
}

