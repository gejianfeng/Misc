// Fill out your copyright notice in the Description page of Project Settings.

#include "BlackShieldNetNative.h"
#include "BSNWeaponBagItem.h"


// Sets default values
ABSNWeaponBagItem::ABSNWeaponBagItem() 
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	RootScene = CreateDefaultSubobject<USceneComponent>(TEXT("RootScane"));
	SetRootComponent(RootScene);
	WeaponMeshComponent = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Weapon"));
	WeaponMeshComponent->SetupAttachment(RootComponent);
	WeaponMeshComponent->SetStaticMesh(Mesh);

	BoxTrigger = CreateDefaultSubobject<UBoxComponent>(TEXT("BoxTrigger"));
	BoxTrigger->SetupAttachment(RootComponent);
	BoxTrigger->SetBoxExtent(FVector(20,20,20));
}

// Called when the game starts or when spawned
void ABSNWeaponBagItem::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void ABSNWeaponBagItem::Tick( float DeltaTime )
{
	Super::Tick( DeltaTime );

}
void ABSNWeaponBagItem::OnLeftHandPickup_Implementation()
{
	if (Bag&&WeaponClass)
	{
		Bag->EquipWeaponFromBag(0, WeaponClass);
	}
//	Destroy();
}
void ABSNWeaponBagItem::OnRightHandPickup_Implementation()
{
	if (Bag&&WeaponClass)
	{
		Bag->EquipWeaponFromBag(1, WeaponClass);
	}
//	Destroy();
}


