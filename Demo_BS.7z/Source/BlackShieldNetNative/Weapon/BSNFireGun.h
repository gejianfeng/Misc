// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "Weapon/BSNGun.h"
#include "BSNFireGun.generated.h"

UCLASS(BlueprintType)
class ABSNFireGun : public ABSNGun
{
	GENERATED_UCLASS_BODY()
protected:
	bool HasInfiniteAmmo() { return true; }
	virtual void SimulateWeaponFire();
	virtual void StopSimulatingWeaponFire();
};

