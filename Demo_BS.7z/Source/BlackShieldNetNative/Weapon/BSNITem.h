// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "GameFramework/Actor.h"
#include "BSNItem.generated.h"

class ABSNCharacter;

UENUM(BlueprintType)
enum class EItem_Use_Type: uint8
{
	Manual,
	Auto,
};

UENUM(BlueprintType)
enum class EItemType:uint8
{
	Normal,
	HealthPotion,
	Weapon,
};


USTRUCT(BlueprintType)
struct FItemDataRow :public FTableRowBase
{
	GENERATED_USTRUCT_BODY()
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	EItemType		ItemType;
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	EItem_Use_Type  UseType;
};

UCLASS(notplaceable, Abstract)
class BLACKSHIELDNETNATIVE_API ABSNItem : public AActor
{
	GENERATED_UCLASS_BODY()
public:
	UFUNCTION()
	virtual void OnRep_BSNOwner();
	UFUNCTION(BlueprintPure, Category = "Inventory")
	inline ABSNCharacter* GetBSNOwner() const { return BSNOwner; }
	UFUNCTION(BlueprintPure,Category="Inventory")
	UParticleSystem *GetPickEffect() { return PickEffect;  }
	void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const;
	static FItemDataRow *GetRow(const FName &InRowName);
	static void  InstanceItemByItemInfo(ABSNItem *pItemActor, const FName &InName);
	virtual void PostInitializeComponents() override;
	virtual void OnConstruction(const FTransform& Transform) override;
public:
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	UParticleSystem		 *PickEffect;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	UStaticMesh			  *Mesh;
	FItemDataRow		  ItemInfo;
public:
	UPROPERTY(Transient, VisibleInstanceOnly, BlueprintReadOnly, ReplicatedUsing = OnRep_BSNOwner, Category = "Inventory")
	ABSNCharacter		  *BSNOwner;
	UPROPERTY(VisibleInstanceOnly, BlueprintReadOnly)
	UStaticMeshComponent *WeaponMeshComponent;
};

UENUM(BlueprintType)
enum class EWeaponSlotType :uint8
{
	LeftHand,
	RightHand,
	HandGunSlot,
	Max,
};

USTRUCT(BlueprintType)
struct FAttachableItemDataRow :public FItemDataRow
{
	GENERATED_USTRUCT_BODY()
	UPROPERTY(EditAnywhere, Category = Weapon)
	EWeaponSlotType			SlotType;
};

UCLASS(notplaceable, Abstract)
class ABSAttachableItem :public ABSNItem
{
	GENERATED_UCLASS_BODY()
public:
	virtual EWeaponSlotType GetSlotType() { return EWeaponSlotType::Max; }
	virtual void SetSlotType(EWeaponSlotType SlotType) { }
	virtual FName GetAttachSocketName() { return NAME_None; }
};

