// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "GameFramework/Actor.h"
#include "Interface/PickupInterface.h"
#include "BSNWeaponBagItem.generated.h"
class UWeaponBag;
class ABSNGun;
UCLASS()
class BLACKSHIELDNETNATIVE_API ABSNWeaponBagItem : public AActor,public IPickupInterface
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	ABSNWeaponBagItem();

	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
	
	// Called every frame
	virtual void Tick( float DeltaSeconds ) override;

	UPROPERTY(VisibleInstanceOnly, BlueprintReadOnly)
		UStaticMeshComponent *WeaponMeshComponent;
	UPROPERTY(VisibleInstanceOnly, BlueprintReadOnly)
		UStaticMesh* Mesh;
	UPROPERTY(VisibleInstanceOnly, BlueprintReadOnly)
		USceneComponent* RootScene;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
		UBoxComponent* BoxTrigger;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
		UWeaponBag* Bag;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
		TSubclassOf<ABSNGun> WeaponClass;
public:
	virtual void OnLeftHandPickup_Implementation() override;
	
	virtual void OnRightHandPickup_Implementation() override;
};
