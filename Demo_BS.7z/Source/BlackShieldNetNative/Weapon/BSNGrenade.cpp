
#include "BlackShieldNetNative.h"
#include "BSNGrenade.h"

FGrenadeDataRow::FGrenadeDataRow()
	: HitDamage(20)
	, Radius(2.0f)
	, Speed(400.0f)
	, GravityScale(1.0f)
{
}

//////////////////////////////////////////////////////////////////////////
ABSNGrenade::ABSNGrenade(const FObjectInitializer &ObjectInitializer)
	: Super(ObjectInitializer)
	, TrailFX(NULL)
	, ExplodeFX(NULL)
	, TrailPSC(NULL)
	, bExploded(false)
	, MovementProj(NULL)
	, bFiring(false)
	, CollisionComp(NULL)
	, bExploding(false)
{	

	CollisionComp = ObjectInitializer.CreateDefaultSubobject<USphereComponent>(this,TEXT("CollisionComponent"));
	CollisionComp->AlwaysLoadOnClient = true;
	CollisionComp->AlwaysLoadOnServer = true;
	CollisionComp->bTraceComplexOnMove = true;
	CollisionComp->InitSphereRadius(20.0f);
	CollisionComp->SetCollisionProfileName(TEXT("Bullet"));
	CollisionComp->SetupAttachment(RootComponent);

	TrailPSC = ObjectInitializer.CreateDefaultSubobject<UParticleSystemComponent>(this, TEXT("ParticleComponent"));
	TrailPSC->SetupAttachment(RootComponent);
	TrailPSC->bAutoActivate = false;

	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickGroup = TG_PrePhysics;
	SetReplicateMovement(true);
	SetReplicates(true);
}

void ABSNGrenade::Fire(bool bReplicated /*= false*/)
{
	if (!bReplicated && Role < ROLE_Authority)
	{
		ServerFire();
	}
	else
	{
		if (TrailPSC != NULL&& TrailFX != NULL)
		{
			TrailPSC->SetTemplate(TrailFX);
			TrailPSC->ActivateSystem();
		}

		if (MovementProj == NULL && BSNOwner)
		{
			FVector Forward = BSNOwner->GetRootComponent()->GetForwardVector();
			FRotator Rotator = Forward.Rotation();
			Rotator.Roll = 0;
			Rotator.Pitch = 10.0f;
			Forward = Rotator.Vector();

			MovementProj = NewObject<UProjectileMovementComponent>();
			MovementProj->InitialSpeed = Config.Speed;
			MovementProj->MaxSpeed = Config.Speed;
			MovementProj->Velocity = Forward * Config.Speed;
			MovementProj->bRotationFollowsVelocity = true;
			MovementProj->ProjectileGravityScale = 0.3f;
			MovementProj->bInitialVelocityInLocalSpace = false;
			MovementProj->SetUpdatedComponent(RootComponent);
			MovementProj->RegisterComponentWithWorld(GetWorld());
		}
	}

	bFiring = true;
}

void ABSNGrenade::NotifyActorBeginOverlap(class AActor* Other)
{
	if ( !bExploding && Role == ROLE_Authority &&
		 Other!=BSNOwner && bFiring)
	{
		BeginExplode();
		bExploding = true;
	}
}

void ABSNGrenade::BeginExplode()
{
	if (MovementProj != NULL)
	{
		MovementProj->StopMovementImmediately();
	}
	GetWorld()->GetTimerManager().SetTimer(TimerHandle_HandleExplode, this, &ABSNGrenade::OnExplode, 1.0f, false);
}

void ABSNGrenade::OnExplode()
{
	if (TrailPSC != NULL)
	{
		TrailPSC->SetTemplate(ExplodeFX);
		TrailPSC->ActivateSystem();
	}
	bExploded = true;
	SetLifeSpan(2.0f); //time for explode
}

bool ABSNGrenade::ServerFire_Validate()
{
	return true;
}

void ABSNGrenade::ServerFire_Implementation()
{
	Fire();
}

void ABSNGrenade::OnRep_Explode()
{
	if (bExploded)
	{
		OnExplode();
	}
}

void ABSNGrenade::OnRep_Fire()
{
	if (bFiring)
	{
		Fire(true);
	}
}

void ABSNGrenade::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
	DOREPLIFETIME(ABSNGrenade, bExploded);
	DOREPLIFETIME_CONDITION(ABSNGrenade, bFiring, COND_SkipOwner);
}

