// Fill out your copyright notice in the Description page of Project Settings.

#include "BlackShieldNetNative.h"
#include "Weapon/BSNHealthPotion.h"

ABSNHeathPotion::ABSNHeathPotion(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{
}

FHeathPotionDataRow *ABSNHeathPotion::GetRow(const FName &InRowName)
{
	UDataTable *pPropTable = (UDataTable *)StaticLoadObject(UDataTable::StaticClass(), NULL, TEXT("DataTable'/Game/BlackShieldNew/Table/DT_HealthPotion.DT_HealthPotion'"));
	if (pPropTable != NULL)
	{
		FHeathPotionDataRow *pPropData = pPropTable->FindRow<FHeathPotionDataRow>(InRowName, TEXT(""));
		return pPropData;
	}
	return NULL;
}

