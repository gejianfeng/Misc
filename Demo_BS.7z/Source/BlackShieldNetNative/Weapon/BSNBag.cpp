
#include "BlackShieldNetNative.h"
#include "Player/BSNCharacter.h"

void ABSNCharacter::SaveItem(const FName &InName)
{
	if (InName != NAME_None)
	{
		FBagUnit *pUnit = GetItem(InName);
		if (pUnit == NULL)
		{
			InventoryItems.Add(FBagUnit(InName));
		}
		else
		{
			pUnit->Count += 1;
		}
	}
}

void ABSNCharacter::Drop(const FName &InName)
{
	for (int32 i = 0; i < InventoryItems.Num(); ++i)
	{
		FBagUnit &unit = InventoryItems[i];
		if (unit.RowName == InName)
		{
			unit.Count -= 1;
			if (unit.Count <= 0)
			{
				InventoryItems.RemoveAtSwap(i);
			}
			break;
		}
	}
}

uint32 ABSNCharacter::GetItemCount(const FName &InName)
{
	FBagUnit *pUnit = GetItem(InName);
	if (pUnit != NULL)
	{
		check(pUnit->Count > 0);
		return pUnit->Count;
	}
	return 0;
}

FBagUnit *ABSNCharacter::GetItem(const FName &InName)
{
	for (int32 i = 0; i < InventoryItems.Num(); ++i)
	{
		FBagUnit &unit = InventoryItems[i];
		if (unit.RowName == InName)
		{
			return &unit;
		}
	}
	return NULL;
}

void ABSNCharacter::DestroyItems()
{
	if (LeftHandWeapon)
	{
		LeftHandWeapon->Destroy();
		LeftHandWeapon = NULL;
	}

	if (RightHandWeapon)
	{
		RightHandWeapon->Destroy();
		RightHandWeapon = NULL;
	}
}