#include "BlackShieldNetNative.h"
#include "Player/BSNCharacter.h"
#include "BSNGun.h"


ABSNGun *ABSNCharacter::WeaponCombine(ABSNGun *FirstWeapon, ABSNGun *SecondWeapon)
{
	if (Role < ROLE_Authority)
	{
		return nullptr;
	}
	else
	{
		ABSNGun *pWeapon = nullptr;
		TSubclassOf<ABSNGun> GunType = nullptr;
		if (GetWeaponCombineType(FirstWeapon, SecondWeapon, GunType))
		{
			if (FirstWeapon && SecondWeapon && GunType != NULL)
			{
				pWeapon = Cast<ABSNGun>(GunType->GetDefaultObject());
				//pWeapon = Cast<ABSNGun>(DefBSNItem);
				if (pWeapon)
				{
					FName Name = *FPackageName::GetShortName(GunType->GetOuterUPackage());

					ABSNCharacter* pBSNOwer = FirstWeapon->BSNOwner;
					ABSNItem * pInstanceInventory = GetWorld()->SpawnActorDeferred<ABSNItem>(GunType, FTransform::Identity);
					ABSNItem::InstanceItemByItemInfo(pInstanceInventory, Name);
					pWeapon = Cast<ABSNGun>(pInstanceInventory);
					pWeapon->BSNOwner = pBSNOwer;

					pWeapon->SetAmmo(((float)FirstWeapon->GetCurrentAmmo() / (float)FirstWeapon->Config.MaxAmmo + (float)SecondWeapon->GetCurrentAmmo() / (float)SecondWeapon->Config.MaxAmmo) / 2 * pWeapon->Config.MaxAmmo);
					pInstanceInventory->FinishSpawning(FTransform::Identity, true);
					pWeapon->SetOwner(pBSNOwer);
					pWeapon->Instigator = pBSNOwer;
					pWeapon->ForceNetUpdate();

					UnEquipWeapon(0);
					UnEquipWeapon(1);
					if (pBSNOwer)
					{
						pBSNOwer->EquipWeapon(pWeapon);
					}
					
				}

			}
			
		}
		return pWeapon;
	}

}
bool ABSNCharacter::GetWeaponCombineType( ABSNGun *FirstWeapon,  ABSNGun *SecondWeapon,  TSubclassOf<ABSNGun>& CombinedWeaponType)
{
	if (!FirstWeapon || !SecondWeapon)
	{
		return false;
	}
	else
	{

		//	FirstWeapon->GetClass();
		//FWeaponCombine *pCombineData = nullptr;
		UDataTable *pDataTable = (UDataTable *)StaticLoadObject(UDataTable::StaticClass(), NULL, TEXT("DataTable'/Game/BlackShieldNew/Table/DT_WeaponCombine.DT_WeaponCombine'"));
		if (pDataTable != NULL)
		{
			TArray<FName> RowNames = pDataTable->GetRowNames();
			for (auto name : RowNames)
			{
				FWeaponCombine *pCombineData = pDataTable->FindRow<FWeaponCombine>(name, TEXT(""));
				if (pCombineData)
				{
					if ((FirstWeapon->GetClass() == pCombineData->FirstWeaponType&&SecondWeapon->GetClass() == pCombineData->SecondWeaponType)
						|| (FirstWeapon->GetClass() == pCombineData->SecondWeaponType&&SecondWeapon->GetClass() == pCombineData->FirstWeaponType))
					{
						CombinedWeaponType = pCombineData->CombineWeaponType;
						return true;
					}
				}
			}
		}
		return false;
	}
}


TArray<FName> ABSNCharacter::GetWeaponRowNameArray()
{
	TArray<FName> KeyArray;

	for (int32 i = 0; i < InventoryItems.Num(); ++i)
	{
		FBagUnit &unit = InventoryItems[i];
		FGunDataRow* GunData = ABSNGun::GetRow(unit.RowName);
		if (GunData && GunData->WeaponType != EGunType::Invalidate)
		{
			KeyArray.Add(unit.RowName);
		}
	}

	return KeyArray;
}

TArray<TSubclassOf<ABSNGun>> ABSNCharacter::GetWeaponCombineDataTableArray()
{
	TArray<TSubclassOf<ABSNGun>> CombineArray;
	UDataTable *pDataTable = (UDataTable *)StaticLoadObject(UDataTable::StaticClass(), NULL, TEXT("DataTable'/Game/BlackShieldNew/Table/DT_WeaponCombine.DT_WeaponCombine'"));
	if (pDataTable)
	{
		for (FName name : pDataTable->GetRowNames())
		{
			FWeaponCombine *pCombineData = pDataTable->FindRow<FWeaponCombine>(name, TEXT(""));
			if (pCombineData->CombineWeaponType)
			{
				CombineArray.Add(pCombineData->CombineWeaponType);
			}
			
		}
	}
	return CombineArray;
}
bool ABSNCharacter::FindElementFromWeaponCombineArray(TSubclassOf<ABSNGun> WeaponType,FName &RowName)
{
	UDataTable *pDataTable = (UDataTable *)StaticLoadObject(UDataTable::StaticClass(), NULL, TEXT("DataTable'/Game/BlackShieldNew/Table/DT_WeaponCombine.DT_WeaponCombine'"));
	if (pDataTable)
	{
		for (FName name : pDataTable->GetRowNames())
		{
			FWeaponCombine *pCombineData = pDataTable->FindRow<FWeaponCombine>(name, TEXT(""));
			if (pCombineData->CombineWeaponType)
			{
				if (WeaponType == pCombineData->CombineWeaponType)
				{
					RowName = name;
					return true;
				}
			}

		}
	}
	return false;
}
void ABSNCharacter::UpdateCombineTime(float DeltaTime)
{
	if (ABSNGun * rightWeapon = Cast<ABSNGun>(RightHandWeapon))
	{
		if (ABSNGun* leftWeapon = Cast<ABSNGun>(LeftHandWeapon))
		{
			if (GetWeaponsCanCombine(RightHandWeapon, LeftHandWeapon))
			{
				CombineTime += DeltaTime;
				if (CombineTime >= MaxCombineTime)
				{
					CombineTime = MaxCombineTime;
					GEngine->AddOnScreenDebugMessage(0, 5.f, FColor::Yellow, TEXT("CombineWeapon"), true);
					WeaponCombine(rightWeapon, leftWeapon);
					CombineTime = 0.f;
				}

			}
			else
			{
				CombineTime = FMath::Clamp(CombineTime - DeltaTime*5.0f, 0.f, MaxCombineTime);
			}
		}
		else
		{
			CombineTime = FMath::Clamp(CombineTime - DeltaTime*5.0f, 0.f, MaxCombineTime);
		}
		//GEngine->AddOnScreenDebugMessage(0, 5.f, FColor::Yellow, FString::Printf(TEXT("%10.1f"), CombineTime), true);
	}
	else
	{
		CombineTime = FMath::Clamp(CombineTime - DeltaTime*5.0f, 0.f, MaxCombineTime);
	}
	
}
bool ABSNCharacter::GetWeaponsCanCombine(ABSAttachableItem* RightWeapon, ABSAttachableItem* LeftWeapon)
{
	if (RightWeapon&&LeftWeapon)
	{
		GEngine->AddOnScreenDebugMessage(0, 5.f, FColor::Yellow, FString::Printf(TEXT("%10.1f"), ((RightWeapon->GetActorLocation() - LeftWeapon->GetActorLocation()).SizeSquared())), true);
		
		if ((RightWeapon->GetActorLocation() - LeftWeapon->GetActorLocation()).SizeSquared() < MaxCombineLengthSquared)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	else {
		return false;
	}


//	return false;
}
