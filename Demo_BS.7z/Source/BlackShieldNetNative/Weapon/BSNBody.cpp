
#include "BlackShieldNetNative.h"
#include "Player/BSNCharacter.h"
#include "BSNGun.h"
#include "BSNGrenade.h"

void ABSNCharacter::EquipWeapon(ABSAttachableItem *pWeapon, bool bReplicated /*= false*/)
{
	if (pWeapon != NULL)
	{
		if (!bReplicated && Role < ROLE_Authority)
		{
			ServerSetupWeapon(pWeapon);
		}
		else
		{
			if (!RightHandWeapon)
			{
				pWeapon->SetSlotType(EWeaponSlotType::RightHand);
			}
			else
			{
				if (!LeftHandWeapon)
				{
					pWeapon->SetSlotType(EWeaponSlotType::LeftHand);
				}
				else if (LeftHandWeapon)
				{
					pWeapon->SetSlotType(EWeaponSlotType::Max);
				}
			}
			AttachWeapon(pWeapon);
			if (pWeapon->GetSlotType() == EWeaponSlotType::RightHand)
			{
				RightHandWeapon = pWeapon;
			}
			else if (pWeapon->GetSlotType() == EWeaponSlotType::LeftHand)
			{
				LeftHandWeapon = pWeapon;
			}
		}
	}
}
void ABSNCharacter::EquipWeapon(ABSAttachableItem *pWeapon, uint8 InSlot, bool bReplicated /*= false*/)
{
	if (pWeapon != NULL)
	{
		EWeaponSlotType Slot = (EWeaponSlotType)InSlot;
		if (!bReplicated && Role < ROLE_Authority)
		{
			ServerSetupWeapon(pWeapon);
		}
		else
		{
			UnEquipWeapon(InSlot);
			pWeapon->SetSlotType(Slot);
			AttachWeapon(pWeapon);
			if (pWeapon->GetSlotType() == EWeaponSlotType::RightHand)
			{
				RightHandWeapon = pWeapon;
			}
			else if (pWeapon->GetSlotType() == EWeaponSlotType::LeftHand)
			{
				LeftHandWeapon = pWeapon;
			}
		}
	}
}



void ABSNCharacter::UnEquipWeapon(uint8 InSlot, bool bReplicated /*= false*/)
{
	EWeaponSlotType Slot = (EWeaponSlotType)InSlot;

	if (!bReplicated && Role < ROLE_Authority)
	{
		ServerUnEquipWeapon(InSlot);
	}
	else
	{
		if (Slot == EWeaponSlotType::RightHand)
		{
			DetachWeapon(RightHandWeapon);
			RightHandWeapon = NULL;
		}
		else if (Slot == EWeaponSlotType::LeftHand)
		{
			DetachWeapon(LeftHandWeapon);
			LeftHandWeapon = NULL;
		}
	}
}

bool ABSNCharacter::ServerSetupWeapon_Validate(ABSAttachableItem *pWeapon)
{
	return true;
}

void ABSNCharacter::ServerSetupWeapon_Implementation(ABSAttachableItem *pWeapon)
{
	EquipWeapon(pWeapon);
}

bool ABSNCharacter::ServerUnEquipWeapon_Validate(uint8 InSlot)
{
	return true;
}

void ABSNCharacter::ServerUnEquipWeapon_Implementation(uint8 InSlot)
{
	UnEquipWeapon(InSlot);
}

void ABSNCharacter::OnRep_RightHandWeapon()
{
	if (RightHandWeapon)
	{
		EquipWeapon(RightHandWeapon, true);
	}
	else
	{
		UnEquipWeapon((uint8)EWeaponSlotType::RightHand, true);
	}
}

void ABSNCharacter::OnRep_LeftHandWeapon()
{
	if (LeftHandWeapon)
	{
		EquipWeapon(LeftHandWeapon, true);
	}
	else
	{
		UnEquipWeapon((uint8)EWeaponSlotType::LeftHand, true);
	}
}

void ABSNCharacter::HideWeapon()
{
	if (RightHandWeapon != NULL)
	{
		RightHandWeapon->SetActorHiddenInGame(true);
	}
}

void ABSNCharacter::ShowWeapon()
{
	if (RightHandWeapon != NULL)
	{
		RightHandWeapon->SetActorHiddenInGame(false);
	}
}

void ABSNCharacter::UseGrenade(ABSNGrenade *pGrenade, bool bReplicated/* = false*/)
{
	if (!bReplicated && Role < ROLE_Authority)
	{
		ServerUseGrenade(pGrenade);
	}
	else
	{
		HideWeapon();
		Grenade = pGrenade;
		FName AttachSocketName = pGrenade->GetAttachSocketName();
		USkeletalMeshComponent *pSkeletalMeshComponent = GetSkeletalMesh();
		if (pSkeletalMeshComponent != NULL && AttachSocketName != NAME_None)
		{
			USceneComponent *WeaponRoot = pGrenade->GetRootComponent();
			WeaponRoot->AttachToComponent(pSkeletalMeshComponent, FAttachmentTransformRules::KeepRelativeTransform, AttachSocketName);
		}
	}
}

bool ABSNCharacter::ServerUseGrenade_Validate(ABSNGrenade *pGrenade)
{
	return true;
}

void ABSNCharacter::ServerUseGrenade_Implementation(ABSNGrenade *pGrenade)
{
	UseGrenade(pGrenade);
}

void ABSNCharacter::OnRep_Grenade()
{
	if (Grenade)
	{
		UseGrenade(Grenade,true);
	}
	else
	{
		FinishFireGrenade();
	}
}

void ABSNCharacter::AttachWeapon(ABSAttachableItem *pWeapon)
{
	if (pWeapon->GetSlotType() == EWeaponSlotType::RightHand)
	{
		if (pWeapon == RightHandWeapon)
		{
			return;
		}

		// Stop hand gun when equip new weapon
		if (AutoHandGun != NULL && AutoHandGun->GetWeaponState() == EGunState::Firing)
		{
			AutoHandGun->StopFire();
		}

		if (RightHandWeapon != NULL)
		{
			// Stop current gun when equip new weapon
			ABSNGun* pGun = Cast<ABSNGun>(RightHandWeapon);
			if (pGun &&  pGun->GetWeaponState() == EGunState::Firing)
			{
				pGun->StopFire();
			}
			DetachWeapon(RightHandWeapon);
		}
	}
	else if (pWeapon->GetSlotType() == EWeaponSlotType::LeftHand)
	{
		if (pWeapon == LeftHandWeapon)
		{
			return;
		}

		if (LeftHandWeapon != NULL)
		{
			DetachWeapon(LeftHandWeapon);
		}
	}

	FName AttachSocketName = pWeapon->GetAttachSocketName();
	USkeletalMeshComponent *pSkeletalMeshComponent = GetSkeletalMesh();
	if (pSkeletalMeshComponent != NULL && AttachSocketName != NAME_None)
	{
		USceneComponent *WeaponRoot = pWeapon->GetRootComponent();
		WeaponRoot->AttachToComponent(pSkeletalMeshComponent, FAttachmentTransformRules::KeepRelativeTransform, AttachSocketName);
	}
}

void ABSNCharacter::DetachWeapon(ABSAttachableItem *pWeapon)
{
	if (pWeapon != NULL)
	{
		USceneComponent *WeaponRoot = pWeapon->GetRootComponent();
		WeaponRoot->DetachFromComponent(FDetachmentTransformRules::KeepWorldTransform);
		GetWorld()->DestroyActor(pWeapon);
	}
}

void ABSNCharacter::CreateHandGun()
{
	if (!AutoHandGun && HandGunClass)
	{
		AutoHandGun = (ABSNHandGun *)(GetWorld()->SpawnActor(HandGunClass));
		AutoHandGun->SetOwner(this);
		AutoHandGun->BSNOwner = this;
		AttachWeapon(AutoHandGun);
	}
}

void ABSNCharacter::OnRep_HandGun()
{
	if (AutoHandGun)
	{
		AttachWeapon(AutoHandGun);
	}
}

