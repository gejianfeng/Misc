// Fill out your copyright notice in the Description page of Project Settings.

#include "BlackShieldNetNative.h"
#include "BSNHandGun.h"

ABSNHandGun::ABSNHandGun(const FObjectInitializer &ObjectIntializer)
	:Super(ObjectIntializer)
{
	WeaponMeshComponent->bVisible = false;
}

EWeaponSlotType ABSNHandGun::GetSlotType()
{ 
	return EWeaponSlotType::HandGunSlot; 
}



