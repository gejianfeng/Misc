// Fill out your copyright notice in the Description page of Project Settings.

#include "BlackShieldNetNative.h"
#include "Weapon/BSNGun.h"
#include "WeaponBag.h"


// Sets default values
UWeaponBag::UWeaponBag()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
//	PrimaryActorTick.bCanEverTick = true;
	BagLength = 100.f;
	HalfBagIncludedAngle = 30.f;
	bWantsBeginPlay = true;
	bReplicates = true;
	bWantsBeginPlay = true;
	bWantsInitializeComponent = true;
	PrimaryComponentTick.bCanEverTick = true;

}

// Called when the game starts or when spawned
void UWeaponBag::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame

void UWeaponBag::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	// ...
}
void UWeaponBag::ShowWeaponItems()
{
	SetWeaponItemArray();
	SetWeaponItemPosition();
}
void UWeaponBag::HidenWeaponItems()
{
	for (ABSNWeaponBagItem* item : WeaponItemArray)
	{
		item->Destroy();
	}
	WeaponItemArray.Empty();
}
void UWeaponBag::SetWeaponItemArray()
{
	HidenWeaponItems();
	ABSNCharacter* Player = Cast<ABSNCharacter>(GetOwner());
	if (Player)
	{
		TArray<FName> WeaponNameArray = Player->GetWeaponRowNameArray();
		for (auto name : WeaponNameArray)
		{
			FGunDataRow *pWeaponData = ABSNGun::GetRow(name);
			if (pWeaponData && pWeaponData->ItemClass!=nullptr)
			{
				ABSNWeaponBagItem*  pWeaponBagItem=  GetWorld()->SpawnActorDeferred<ABSNWeaponBagItem>(pWeaponData->ItemClass, FTransform::Identity);
				pWeaponBagItem->SetOwner(GetOwner());
				pWeaponBagItem->FinishSpawning(FTransform::Identity);
				pWeaponBagItem->WeaponClass = pWeaponData->WeaponClass;
				pWeaponBagItem->Bag = this;
				WeaponItemArray.Add(pWeaponBagItem);
			}
		}
	}
	Player->UnEquipWeapon(0, true);
	Player->UnEquipWeapon(1, true);
	
}
void UWeaponBag::SetWeaponItemPosition()
{
	ABSNCharacter* Player = Cast<ABSNCharacter>(GetOwner());
	if (Player)
	{
		FVector CameraLocation;
		FRotator CameraRotation;
		Player->GetCameraLocationAndRotation(CameraLocation, CameraRotation);
		for (size_t i = 0; i < WeaponItemArray.Num(); i++)
		{
			float AngleOffset = HalfBagIncludedAngle *2*i-HalfBagIncludedAngle*(WeaponItemArray.Num() - 1);
			FRotator Rot = FRotator(CameraRotation.Pitch, CameraRotation.Yaw + AngleOffset, 0.0f);		
			FVector Loc = FRotationMatrix(Rot).TransformVector(FVector(BagLength, 0, 0)) + CameraLocation;
			WeaponItemArray[i]->SetActorLocation(Loc);
		}
	}

}
void UWeaponBag::EquipWeaponFromBag(uint8 InSlot, TSubclassOf<ABSNGun> WeaponType)
{
	ABSNCharacter* Player = Cast<ABSNCharacter>(GetOwner());
	if (Player)
	{
		ABSNGun* pWeapon = Cast<ABSNGun>(WeaponType->GetDefaultObject());

			if (pWeapon)
			{
				FName Name = *FPackageName::GetShortName(WeaponType->GetOuterUPackage());
				ABSNItem * pInstanceInventory = GetWorld()->SpawnActorDeferred<ABSNItem>(WeaponType, FTransform::Identity);
				ABSNItem::InstanceItemByItemInfo(pInstanceInventory, Name);
				pWeapon = Cast<ABSNGun>(pInstanceInventory);
				pWeapon->BSNOwner = Player;
				pInstanceInventory->FinishSpawning(FTransform::Identity, true);
				pWeapon->SetOwner(GetOwner());
				pWeapon->Instigator = Cast<APawn>(Player);				
				Player->EquipWeapon(pWeapon, InSlot);
			}
	}
}