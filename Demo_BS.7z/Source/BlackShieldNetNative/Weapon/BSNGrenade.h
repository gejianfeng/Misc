// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "GameFramework/Actor.h"
#include "BSNItem.h"
#include "BSNGrenade.generated.h"

USTRUCT()
struct FGrenadeDataRow :public FAttachableItemDataRow
{
	GENERATED_USTRUCT_BODY()
public:
	FGrenadeDataRow();
	UPROPERTY(EditDefaultsOnly, Category = Grenade)
	int32 HitDamage;
	UPROPERTY(EditDefaultsOnly, Category = Grenade)
	float Radius;
	UPROPERTY(EditDefaultsOnly, Category = Grenade)
	float Speed;
	UPROPERTY(EditDefaultsOnly, Category = Grenade)
	float GravityScale;
};

UCLASS(notplaceable)
class ABSNGrenade : public ABSAttachableItem
{
	GENERATED_UCLASS_BODY()
public:
	void Fire(bool bReplicated = false);
	UFUNCTION(Reliable, Server, WithValidation)
	void ServerFire();
	UFUNCTION()
	void OnRep_Explode();
	UFUNCTION()
	void OnRep_Fire();
	virtual EWeaponSlotType GetSlotType() { return EWeaponSlotType::RightHand; }
	virtual FName GetAttachSocketName() { return TEXT("Gernade"); }//FireGun
	virtual void  GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const;
	virtual void  NotifyActorBeginOverlap(class AActor* Other) override;
protected:
	void BeginExplode();
	void OnExplode();
public:
	UPROPERTY(EditAnywhere)
	FGrenadeDataRow	  Config;
	UPROPERTY(EditAnywhere)
	UParticleSystem	 *TrailFX;
	UPROPERTY(EditAnywhere)
	UParticleSystem	 *ExplodeFX;
protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Grenade)
	UParticleSystemComponent *TrailPSC;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Grenade)
	UProjectileMovementComponent *MovementProj;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Grenade)
	USphereComponent  *CollisionComp;
	UPROPERTY(Transient, ReplicatedUsing = OnRep_Explode)
	bool	bExploded;
	UPROPERTY(Transient, ReplicatedUsing = OnRep_Fire)
	bool	bFiring;
	//////////////////////////////////////////////////////////////////////////
	bool	bExploding;
	FTimerHandle TimerHandle_HandleExplode;
};

