// Fill out your copyright notice in the Description page of Project Settings.

#include "BlackShieldNetNative.h"
#include "Animation/BSNAnimInstance.h"
#include "BSNShotGun.h"
#include "BSNBullet.h"

ABSNShotGun::ABSNShotGun(const FObjectInitializer &ObjectIntializer)
	:Super(ObjectIntializer)
	,ScatterCount(5)
	,ScatterRadius(0.5f)
	,HalfVRad(0.85f)
{
}

void ABSNShotGun::PostInitProperties()
{
	Super::PostInitProperties();
	HalfVRad = FMath::Atan(ScatterRadius);
	ScatterCount = FMath::Max<int32>(ScatterCount, 1);
}

void ABSNShotGun::StartFire()
{
	if (!HasAuthority())
	{
		int32 VConeSeed = FMath::Rand();
		VConRandomStream.Initialize(VConeSeed);
		ServerUpdateSeed(VConeSeed);
	}

	Super::StartFire();
}

void ABSNShotGun::FireWeapon()
{
	FVector FireLoc, FireDir;
	GetFireLocationAndDirection(FireLoc, FireDir);

	for (int32 i = 0; i < ScatterCount; ++i)
	{
		FVector RandomDir = VConRandomStream.VRandCone(FireDir, HalfVRad);

		if (bIsUseBulletHit)
		{
			FTransform BulletInitTransform(RandomDir.Rotation(), FireLoc);
			ABSNBullet_Instance *Bullet = GetWorld()->SpawnActorDeferred<ABSNBullet_Instance>(ABSNBullet_Instance::StaticClass(), BulletInitTransform);
			Bullet->pWeapon = this;
			Bullet->FinishSpawning(BulletInitTransform);
		}
		else
		{
			FVector ShootEnd;
			ShootEnd = FireLoc + RandomDir * Config.WeaponRange;
			const FHitResult Impact = WeaponTrace(FireLoc, ShootEnd);
			ProcessHit(Impact, FireLoc, ShootEnd);
		}
	}
}

bool ABSNShotGun::ServerUpdateSeed_Validate(int32 InSeed)
{
	return true;
}

void ABSNShotGun::ServerUpdateSeed_Implementation(int32 InSeed)
{	
	VConRandomStream.Initialize(InSeed);
}

