// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "GameFramework/Actor.h"
#include "BSNBullet.generated.h"

class ABSNGun;

USTRUCT(BlueprintType)
struct FBulletRowData :public FTableRowBase
{
	GENERATED_USTRUCT_BODY()
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	TSubclassOf<ABSNGun> WeaponSpecial;
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	int32  AmmoCount;
};

UCLASS(notplaceable)
class ABSNBullets : public ABSNItem
{
	GENERATED_UCLASS_BODY()
public:
	static FBulletRowData *GetRow(const FName &InRowName);
public:
	UPROPERTY(EditDefaultsOnly, Category = Config)
	FBulletRowData Config;
};

USTRUCT()
struct FBulletHitResult
{
	FBulletHitResult();
	GENERATED_USTRUCT_BODY()
	UPROPERTY()
	FVector HitPosition;
	UPROPERTY()
	FVector HitNormal;
	UPROPERTY()
	uint8   HitCounter;
	void EnsureReplication() { HitCounter++;  }
};

UCLASS(notplaceable)
class ABSNBullet_Instance : public AActor
{
	GENERATED_UCLASS_BODY()
public:
	virtual void PostInitializeComponents();
	virtual void NotifyHit(class UPrimitiveComponent* MyComp, AActor* Other, class UPrimitiveComponent* OtherComp, bool bSelfMoved, FVector HitLocation, FVector HitNormal, FVector NormalImpulse, const FHitResult& Hit) override;
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const;
	UFUNCTION()
	void OnRep_Weapon();
	UFUNCTION()
	void OnRep_Explode();
	void SpawnBullet();
protected:
	void SimulateExplode(const FHitResult &Hit);
public:
	FVector  ForwardDir;
	UPROPERTY(Transient, ReplicatedUsing = OnRep_Weapon)
	ABSNGun *pWeapon;
	UPROPERTY(Transient, ReplicatedUsing = OnRep_Explode)
	FBulletHitResult HitResult;
protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Bullet)
	USphereComponent		 *CollisionComp;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Bullet)
	UParticleSystemComponent *ParticleComp;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Bullet)
	UProjectileMovementComponent *ProjMovement;
};

#define ECC_GameFireChannel		ECC_GameTraceChannel13


