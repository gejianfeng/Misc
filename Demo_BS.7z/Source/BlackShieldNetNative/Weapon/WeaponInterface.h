// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "WeaponInterface.generated.h"

UINTERFACE(MinimalAPI)
class UWeaponInterface : public UInterface
{
	GENERATED_BODY()
public:	
};

class IWeaponInterface
{
	GENERATED_BODY()
public:
	UFUNCTION(BlueprintImplementableEvent)
	void SpawnDecal(const UPhysicalMaterial *InPhysicMaterial, const FHitResult &InHitResult);
	UFUNCTION(BlueprintImplementableEvent)
	void SpawnParticle(const UPhysicalMaterial *InPhysicMaterial, const FHitResult &InHitResult);
	UFUNCTION(BlueprintImplementableEvent)
	void ImpactHit(const UPhysicalMaterial *InPhysicMaterial, const FHitResult &InHitResult);
	UFUNCTION(BlueprintImplementableEvent)
	void SpawnSound(const UPhysicalMaterial *InPhysicMaterial, const FHitResult &InHitResult);
	UFUNCTION(BlueprintImplementableEvent)
	void GetDecal(EPhysicalSurface InSurfaceType, UMaterialInterface *&OutDecalMtrl, float &OutDecalSize, float &OutLifeSpan);
};

UObject *GetWeaponInterface(UGameInstance *InGI);
