// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "Weapon/BSNGun.h"
#include "BSNShotGun.generated.h"

UCLASS(BlueprintType)
class ABSNShotGun : public ABSNGun
{
	GENERATED_UCLASS_BODY()
protected:
	UPROPERTY(EditAnywhere, Category=ShotGun)
	float ScatterRadius;
	UPROPERTY(EditAnywhere, Category = ShotGun)
	int32 ScatterCount;
protected:
	UFUNCTION(Server, Reliable, WithValidation)
	void ServerUpdateSeed(int32 InSeed);

	virtual void StartFire();
	virtual void PostInitProperties() override;
	virtual void FireWeapon() override;
protected:
	float			HalfVRad;
	FRandomStream	VConRandomStream;
};

