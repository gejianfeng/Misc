// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "Components/ActorComponent.h"
#include "Weapon/BSNWeaponBagItem.h"
//#include "Player/BSNCharacter.h"
#include "WeaponBag.generated.h"

//#include "BSNCharacter.h"
UCLASS(BlueprintType, Config = WeaponBag, Blueprintable, meta = (BlueprintSpawnableComponent))
class BLACKSHIELDNETNATIVE_API UWeaponBag : public UActorComponent
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	UWeaponBag();

	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
	
	// Called every frame
//	virtual void Tick( float DeltaSeconds ) override;
//	UFUNCTION(BlueprintImplementableEvent, meta = (DisplayName = "Tick"))
//	virtual void ReceiveTick(float DeltaSeconds) ;
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;
	void SetWeaponItemArray();

	UFUNCTION()
	void ShowWeaponItems();
	UFUNCTION()
	void HidenWeaponItems();
	UFUNCTION()
	void SetWeaponItemPosition();

	UFUNCTION(BlueprintCallable, Category = WeaponBag)
	void EquipWeaponFromBag(uint8 InSlot,TSubclassOf<ABSNGun> WeaponType);
public:
	UPROPERTY(EditDefaultsOnly,Category = WeaponBag)
	float BagLength;
	UPROPERTY(EditDefaultsOnly, Category = WeaponBag)
	float HalfBagIncludedAngle;


protected:

	UPROPERTY()
		TArray<ABSNWeaponBagItem*> WeaponItemArray;

};
