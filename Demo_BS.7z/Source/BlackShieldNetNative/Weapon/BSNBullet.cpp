// Fill out your copyright notice in the Description page of Project Settings.

#include "BlackShieldNetNative.h"
#include "BSNBullet.h"
#include "Player/BSNCharacter.h"
#include "Monster/BSNCharacterMonster.h"
#include "UnrealNetwork.h"
#include "WeaponInterface.h"
#include "BSNDamageTypes.h"

FBulletHitResult::FBulletHitResult()
	:HitCounter(0)
{
}
//////////////////////////////////////////////////////////////////////////
ABSNBullets::ABSNBullets(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{
	SetReplicates(false);
}

FBulletRowData *ABSNBullets::GetRow(const FName &InRowName)
{
	UDataTable *pPropTable = (UDataTable *)StaticLoadObject(UDataTable::StaticClass(), NULL, TEXT("DataTable'/Game/BlackShieldNew/Table/DT_HealthPotion.DT_HealthPotion'"));
	if (pPropTable != NULL)
	{
		FBulletRowData *pPropData = pPropTable->FindRow<FBulletRowData>(InRowName, TEXT(""));
		return pPropData;
	}
	return NULL;
}

//////////////////////////////////////////////////////////////////////////
ABSNBullet_Instance::ABSNBullet_Instance(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{
	CollisionComp = ObjectInitializer.CreateDefaultSubobject<USphereComponent>(this, TEXT("SphereComp"));
	CollisionComp->AlwaysLoadOnClient = true;
	CollisionComp->AlwaysLoadOnServer = true;
	CollisionComp->bTraceComplexOnMove = true;
	CollisionComp->InitSphereRadius(20.0f);
	CollisionComp->SetCollisionProfileName(TEXT("Bullet"));

	RootComponent = CollisionComp;
	ParticleComp = ObjectInitializer.CreateDefaultSubobject<UParticleSystemComponent>(this, TEXT("ParticleComp"));
	ParticleComp->bAutoActivate = false;
	ParticleComp->bAutoDestroy = false;
	ParticleComp->SetupAttachment(RootComponent);

	ProjMovement = ObjectInitializer.CreateDefaultSubobject<UProjectileMovementComponent>(this, TEXT("ProjMovement"));
	ProjMovement->UpdatedComponent = RootComponent;
	ProjMovement->bRotationFollowsVelocity = true;
	ProjMovement->ProjectileGravityScale = 0;

	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickGroup = TG_PrePhysics;
	SetReplicateMovement(false);
	SetReplicates(false);
}

void ABSNBullet_Instance::PostInitializeComponents()
{
	Super::PostInitializeComponents();
	SpawnBullet();
}

void ABSNBullet_Instance::NotifyHit(class UPrimitiveComponent* MyComp, AActor* Other, class UPrimitiveComponent* OtherComp, bool bSelfMoved, FVector HitLocation, FVector HitNormal, FVector NormalImpulse, const FHitResult& Hit)
{
	Super::NotifyHit(MyComp, Other, OtherComp, bSelfMoved, HitLocation, HitNormal, NormalImpulse, Hit);

	if (HasAuthority() && HitResult.HitCounter == 0)
	{
		if (pWeapon->BulletExplodeFX)
		{
			ParticleComp->SetTemplate(pWeapon->BulletExplodeFX);
		}

		if (ProjMovement != NULL)
		{
			ProjMovement->StopMovementImmediately();
		}

		HitResult.HitPosition = HitLocation;
		HitResult.HitNormal = HitNormal;
		HitResult.EnsureReplication();

		SimulateExplode(Hit);
		
		ABSNCharacterBase *BSNHit = Cast<ABSNCharacterBase>(Other);
		if (BSNHit && BSNHit != pWeapon->GetOwner())
		{
			UClass *DamageType = pWeapon->Config.DamageType;
			if (DamageType->IsChildOf<UBSNPDamageType_Radial>())
			{
				UBSNPDamageType_Radial *pRadialDamage = DamageType->GetDefaultObject<UBSNPDamageType_Radial>();
				FRadialDamageEvent RadialDamage;
				RadialDamage.Origin = Hit.ImpactPoint;
				RadialDamage.Params.BaseDamage = pWeapon->Config.HitDamage;
				RadialDamage.Params.DamageFalloff = pRadialDamage->Falloff;
				RadialDamage.Params.InnerRadius = pRadialDamage->InnerRadius;
				RadialDamage.Params.OuterRadius = pRadialDamage->OuterRadius;
				RadialDamage.Params.MinimumDamage = 1;
				BSNHit->TakeDamage(RadialDamage.Params.BaseDamage, RadialDamage, pWeapon->BSNOwner->GetController(), pWeapon);
			}
			else
			{
				FPointDamageEvent PointDamage;
				PointDamage.Damage = pWeapon->Config.HitDamage;
				PointDamage.HitInfo = Hit;
				PointDamage.ShotDirection = ForwardDir;
				PointDamage.DamageTypeClass = pWeapon->Config.DamageType;
				BSNHit->TakeDamage(PointDamage.Damage, PointDamage, pWeapon->BSNOwner->GetController(), pWeapon);
			}
		}

		SetLifeSpan(2.0f); //time for explode
	}
}

void ABSNBullet_Instance::SpawnBullet()
{
	if (pWeapon != NULL)
	{
		if (CollisionComp != NULL)
		{
			CollisionComp->SetSphereRadius(pWeapon->BulletRadius);
		}

		FVector BulletDir = GetActorForwardVector();
		ForwardDir = FVector(BulletDir.X, BulletDir.Y, BulletDir.Z);

		if (ParticleComp != NULL)
		{
			ParticleComp->SetTemplate(pWeapon->BulletTrailFX);
			ParticleComp->ActivateSystem();
		}

		if (ProjMovement != NULL)
		{
			ProjMovement->InitialSpeed = pWeapon->BulletSpeed;
			ProjMovement->MaxSpeed = pWeapon->BulletSpeed;
			ProjMovement->Velocity = ForwardDir*ProjMovement->MaxSpeed;
		}

		SetLifeSpan(pWeapon->BulletLifeTime);
	}
}

void ABSNBullet_Instance::OnRep_Weapon()
{
	if (pWeapon != NULL)
	{
		SpawnBullet();
	}
}

void ABSNBullet_Instance::OnRep_Explode()
{
	if (HitResult.HitCounter>0)
	{
		FVector StartPoint = HitResult.HitPosition - HitResult.HitNormal*20.0f;
		FVector EndPoint = HitResult.HitPosition + HitResult.HitNormal*20.0f;

		static FName WeaponTraceTag = FName(TEXT("BulletTrace"));

		FCollisionQueryParams TraceParams(WeaponTraceTag, true);
		if (pWeapon != NULL)
		{
			TraceParams.AddIgnoredActor(pWeapon);
			TraceParams.AddIgnoredActor(pWeapon->GetOwner());
		}
		TraceParams.AddIgnoredActor(this);
		TraceParams.bTraceAsyncScene = true;
		TraceParams.bReturnPhysicalMaterial = true;

		FHitResult HitCompact(ForceInit);
		GetWorld()->LineTraceSingleByChannel(HitCompact, StartPoint, EndPoint, ECC_GameFireChannel, TraceParams);

		SimulateExplode(HitCompact);

		SetLifeSpan(2.0f); //time for explode
	}
}

void ABSNBullet_Instance::SimulateExplode(const FHitResult &Hit)
{
	if (!IsRunningDedicatedServer())
	{
		if (pWeapon && pWeapon->BulletExplodeFX)
		{
			ParticleComp->SetTemplate(pWeapon->BulletExplodeFX);
		}
		else
		{
			ParticleComp->DeactivateSystem();
		}

		if (ProjMovement != NULL)
		{
			ProjMovement->StopMovementImmediately();
		}

		UObject *WeaponInstance = GetWeaponInterface(GetGameInstance());
		if (WeaponInstance != NULL)
		{
			UPhysicalMaterial *PM = Hit.PhysMaterial.Get();
			if (PM == NULL)
			{
				PM = UPhysicalMaterial::StaticClass()->GetDefaultObject<UPhysicalMaterial>();
			}
			IWeaponInterface::Execute_SpawnDecal(WeaponInstance, PM, Hit);
		}
	}
}

void ABSNBullet_Instance::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(ABSNBullet_Instance, pWeapon)
	DOREPLIFETIME_CONDITION(ABSNBullet_Instance, HitResult, COND_SkipOwner)
}
