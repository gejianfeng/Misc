// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "Weapon/BSNITem.h"
#include "Weapon/BSNWeaponBagItem.h"
#include "BSNGun.generated.h"

UENUM(BlueprintType)
enum class EGunType : uint8
{
	Invalidate,
	HandGun,
	FireGun,
	MachineGun,
	ShotGun,
	Gernade,
};

USTRUCT()
struct FGunDataRow :public FAttachableItemDataRow
{
	GENERATED_USTRUCT_BODY()
public:
	FGunDataRow();
	UPROPERTY(EditAnywhere, Category = Weapon)
	EGunType				WeaponType;
	UPROPERTY(EditAnywhere, Category = Weapon)
	bool					bRepeatFire;
	UPROPERTY(EditDefaultsOnly, Category = Ammo)
	int32 MaxAmmo;
	UPROPERTY(EditDefaultsOnly, Category = Ammo)
	int32 AmmoPerClip;
	UPROPERTY(EditDefaultsOnly, Category = Ammo)
	int32 MaxClips;
	UPROPERTY(EditDefaultsOnly, Category = Ammo)
	int32 InitClips;
	UPROPERTY(EditDefaultsOnly, Category = Ammo)
	float Spread;

	UPROPERTY(EditDefaultsOnly, Category = WeaponStatus)
	float TimeBetweenShots;
	UPROPERTY(EditDefaultsOnly, Category = WeaponStatus)
	float NoAnimReloadDuration;

	UPROPERTY(EditAnywhere, Category = Accuracy)
	float	WeaponSpread;
	UPROPERTY(EditAnywhere, Category = Accuracy)
	float	TargetingSpreadMod;
	UPROPERTY(EditAnywhere, Category = Accuracy)
	float	FiringSpreadIncrement;
	UPROPERTY(EditDefaultsOnly, Category = Accuracy)
	float	FiringSpreadMax;

	UPROPERTY(EditDefaultsOnly, Category = WeaponStat)
	float WeaponRange;
	UPROPERTY(EditDefaultsOnly, Category = WeaponStat)
	int32 HitDamage;
	UPROPERTY(EditDefaultsOnly, Category = WeaponStat)
	TSubclassOf<UDamageType> DamageType;

	UPROPERTY(EditDefaultsOnly, Category = HitVerification)
	float ClientSideHitLeeway;
	UPROPERTY(EditDefaultsOnly, Category = HitVerification)
	float AllowedViewDotHitDir;

	UPROPERTY(EditAnywhere, Category = Weapon)
	TSubclassOf<ABSNWeaponBagItem> ItemClass;
	UPROPERTY(EditAnywhere, Category = Weapon)
	TSubclassOf<ABSNGun> WeaponClass;
};

USTRUCT()
struct FInstantHitInfo
{
	FInstantHitInfo();
	GENERATED_USTRUCT_BODY()
	UPROPERTY()
	FVector StartTace;
	UPROPERTY()
	FVector EndTrace;
	void EnsureReplication();
private:
	/** A rolling counter used to ensure the struct is dirty and will replicate. */
	UPROPERTY()
	uint8   EnsureReplicationByte;
};

enum class EGunState :uint8
{
	Idle,
	Firing,
	Reloading,
	Equipping,
};

UCLASS(Abstract, Blueprintable, hidecategories = (Object, Collision, Display, Input, Blueprint, Transform))
class ABSNGun : public ABSAttachableItem
{
	GENERATED_UCLASS_BODY()
public:
	virtual void PostInitProperties();
	virtual void StartFire();
	virtual void StopFire();

	UFUNCTION(BlueprintCallable, Category = "WeaponInfo")
	virtual EGunType	GetWeaponType() { return Config.WeaponType; }
	virtual EWeaponSlotType GetSlotType() { return Config.SlotType; }
	virtual void SetSlotType(EWeaponSlotType SlotType) { Config.SlotType = SlotType; };
	virtual FName GetAttachSocketName();
	virtual void PostInitializeComponents() override;
	static FGunDataRow *GetRow(const FName &InRowName);
	virtual void OnRep_BSNOwner();
	UFUNCTION(Reliable, Server, WithValidation)
	void ServerStartFire();
	UFUNCTION(Reliable, Server, WithValidation)
	void ServerStopFire();
	UFUNCTION(Reliable, Server, WithValidation)
	void ServerHandleFiring();
	void SetWeaponState(EGunState NewState);
	EGunState GetWeaponState() const { return CurrentState; }
	void DetermineWeaponState();
	UFUNCTION()
	void OnRep_Reload();
	UFUNCTION()
	void OnRep_HitNotify();
	UFUNCTION()
	void OnRep_BurstCounter();
	UFUNCTION()
	void OnRep_Ammo();
	UFUNCTION()
	void OnRep_AmmoInClip();

	bool CanReload();
	void StartReload(bool bReplicateFromServer = false);
	UFUNCTION(Reliable,Server,WithValidation)
	void ServerStartReload();
	void StopReload();
	bool CanCombine() { return true; }
	bool CanFire() { return true; }
 	virtual bool HasInfiniteClip() { return false; }
	virtual bool HasInfiniteAmmo() { return false; }
	virtual void OnBurstStarted();
	virtual void OnBurstFinished();
	void HandleFiring();
	virtual void SimulateWeaponFire();
	virtual void StopSimulatingWeaponFire();
	virtual void FireWeapon();
	virtual void UseAmmo();
	void GiveAmmo(uint32 InAmmoCount);
	UFUNCTION(BlueprintCallable, Category = "Gun")
	void SetAmmo(int32 InAmmoCount);
	UFUNCTION(BlueprintCallable,Category = "Gun")
	int32 GetCurrentAmmo();
	void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const;
	void SimulateHit(const FVector &EndPoint,const FHitResult &Hit);

	FHitResult WeaponTrace(const FVector &StartTrace, const FVector &EndTrace);
	void ProcessHit(const FHitResult &Impact, const FVector &StartTrace, const FVector &ShootDir);
	void ProcessHitComfirmed(const FHitResult &Impact, const FVector &StartTrace, const FVector &ShootDir);
	UFUNCTION(Reliable, Server, WithValidation)
	void ServerNotifyHit(const FHitResult &Impact, const FVector &ShootDir);
	UFUNCTION(Unreliable, Server, WithValidation)
	void ServerNotifyMiss(const FVector &ShootDir);
	void DealDamage(const FHitResult &Impact, const FVector &ShootDir);
	void SpawnTrailEffect(const FVector &EndPosition);
	void SpawnImpactEffect(const FHitResult &Impact);
	void SpawnDecals(const FHitResult &Impact);
	void UpdateText();

	//WeaponCombine
	UFUNCTION(BlueprintCallable,Category = "WeaponCombine")
	TArray<TSubclassOf<ABSNGun>> GetWeaponCombineBaseTypeArray(){	return WeaponCombineBaseTypeArray;	}
	void SetWeaponCombineBaseType(UDataTable *pDataTable, TSubclassOf<ABSNGun> WeaponType);

	//override
	virtual void GetFireLocationAndDirection(FVector &OutLocation, FVector &OutDirection);
protected:
	void SetMuzzleFX(UParticleSystem *InParticle);
public:
	UPROPERTY(EditDefaultsOnly, Category = Config)
	FGunDataRow				Config;
	UPROPERTY(EditAnywhere, Category = Weapon)
	UParticleSystem			*MuzzleFX;
	UPROPERTY(EditAnywhere, Category = Weapon)
	USoundCue				*FireSound;
	UPROPERTY(EditDefaultsOnly, Category = Weapon)
	TSubclassOf<UCameraShake> FireCameraShake;
	UPROPERTY(EditDefaultsOnly, Category = Weapon)
	UCurveVector			*FireFeedbackCurve;
	UPROPERTY(VisibleDefaultsOnly, Category = Weapon)
	USceneComponent			*FireSpot;
	UPROPERTY(VisibleDefaultsOnly, Category = Weapon)
	USceneComponent			*GuiSpot;
	UPROPERTY(VisibleDefaultsOnly, Category = Weapon)
	UTextRenderComponent	 *TextComponent;

	UPROPERTY(EditAnywhere, Category = Bullet)
	uint8					bIsUseBulletHit : 1;
	UPROPERTY(EditAnywhere, Category = Bullet)
	float					BulletSpeed;
	UPROPERTY(EditAnywhere, Category = Bullet)
	float					BulletLifeTime;
	UPROPERTY(EditAnywhere, Category = Bullet)
	float					BulletRadius;
	UPROPERTY(EditAnywhere, Category = Bullet)
	UParticleSystem			*BulletTrailFX;
	UPROPERTY(EditAnywhere, Category = Bullet)
	UParticleSystem			*BulletExplodeFX;

protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Muzzle)
	UParticleSystemComponent *MuzzlePSC;
	UPROPERTY(VisibleAnywhere)
	UParticleSystemComponent *BulletPSC;
	uint8					bWantsToFire : 1;
	uint32					bRefiring : 1;
	UPROPERTY(Transient, ReplicatedUsing = OnRep_Reload)
	uint32  bPendingReload : 1;
	UPROPERTY(Transient, ReplicatedUsing = OnRep_BurstCounter)
	int32	BurstCounter;
	UPROPERTY(Transient, ReplicatedUsing = OnRep_HitNotify)
	FInstantHitInfo HitNotify;
	UPROPERTY(Transient, ReplicatedUsing = OnRep_Ammo)
	int32 CurrentAmmo;
	UPROPERTY(Transient, ReplicatedUsing = OnRep_AmmoInClip)
	int32 CurrentAmmoInClip;
	EGunState CurrentState;
	float LastFireTime;
	FTimerHandle TimerHandle_HandleFiring;
	FTimerHandle TimerHandle_HandleReload;
	TArray<TSubclassOf<ABSNGun>> WeaponCombineBaseTypeArray;
};


