// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "Weapon/BSNGun.h"
#include "BSNHandGun.generated.h"

UCLASS(BlueprintType)
class ABSNHandGun : public ABSNGun
{
	GENERATED_UCLASS_BODY()
protected:
	bool HasInfiniteAmmo() { return true; }
	virtual EWeaponSlotType GetSlotType();
};

