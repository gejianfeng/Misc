// Fill out your copyright notice in the Description page of Project Settings.

#pragma once


#include "VRGameUserSettings.generated.h"

/**
 * 
 */
UCLASS(config = GameUserSettings, configdonotcheckdefaults)
class UVRGameUserSettings : public UGameUserSettings
{
	GENERATED_BODY()

public:
	UVRGameUserSettings(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());
};
