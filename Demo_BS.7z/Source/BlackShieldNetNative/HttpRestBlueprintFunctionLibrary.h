// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "Kismet/BlueprintFunctionLibrary.h"
#include "Json/VaRestJsonObject.h"
#include "HttpRestBlueprintFunctionLibrary.generated.h"

/**
 * 
 */
UCLASS()
class UHttpRestBlueprintFunctionLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:	



	UFUNCTION(BlueprintCallable, Category = "CMDLine")
		static FString GetGameCommandLine();

//	UFUNCTION(BlueprintCallable, Category = "Json")
//		static bool GetJsonBool(FString JsonString, FString Key);

	UFUNCTION(BlueprintPure, Category = "Json")
		static FString GetJsonString(FString JsonString, FString Key);

	UFUNCTION(BlueprintPure, Category = "Json")
		static  UVaRestJsonObject* GetJsonObject(FString JsonString, FString Key);

	UFUNCTION(BlueprintPure, Category = "Json")
		static TArray<UVaRestJsonObject*> GetJsonArray(FString JsonString, FString Key);

	UFUNCTION(BlueprintPure, Category = "Json")
		static float GetJsonFloat(FString JsonString, FString Key);

};
