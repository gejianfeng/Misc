// Fill out your copyright notice in the Description page of Project Settings.

#include "BlackShieldNetNative.h"
#include "HttpRestBlueprintFunctionLibrary.h"


FString UHttpRestBlueprintFunctionLibrary::GetGameCommandLine()
{
	const TCHAR * cmdline = FCommandLine::Get();
	return cmdline;
}


 FString UHttpRestBlueprintFunctionLibrary::GetJsonString(FString JsonString,FString Key)
{
	FString str;
	if (JsonString !=""&&Key != "")
	{

		TSharedPtr<FJsonObject> JsonObj;
		TSharedRef<TJsonReader<TCHAR>> JsonReader = TJsonReaderFactory<TCHAR>::Create(JsonString);

			if (FJsonSerializer::Deserialize(JsonReader, JsonObj))
			{
				str = JsonObj->GetStringField(Key);
			}
	}
	return str;
}
 
 UVaRestJsonObject* UHttpRestBlueprintFunctionLibrary::GetJsonObject(FString JsonString, FString Key)
 {
	 UVaRestJsonObject* vajsobj = NewObject<UVaRestJsonObject>();
	 if (JsonString != ""&&Key != "")
	 {
		 TSharedPtr<FJsonObject> JsonObj;
		 TSharedRef<TJsonReader<TCHAR>> JsonReader = TJsonReaderFactory<TCHAR>::Create(JsonString);

		 if (FJsonSerializer::Deserialize(JsonReader, JsonObj))
		 {
			 TSharedPtr<FJsonObject> outJsobj = JsonObj->GetObjectField(Key);

			 
			 vajsobj->SetRootObject(outJsobj);
			 
		 }
	 }
	 return vajsobj;
 }
 
 TArray<UVaRestJsonObject*> UHttpRestBlueprintFunctionLibrary::GetJsonArray(FString JsonString, FString Key)
 {
	 TArray<UVaRestJsonObject*> OutArray;


	 if (JsonString != ""&&Key != "")
	 {
		 TSharedPtr<FJsonObject> JsonObj;
		 TSharedRef<TJsonReader<TCHAR>> JsonReader = TJsonReaderFactory<TCHAR>::Create(JsonString);

		 if (FJsonSerializer::Deserialize(JsonReader, JsonObj))
		 {
			  TArray<TSharedPtr<FJsonValue>> ValArray = JsonObj->GetArrayField(Key);

			  for (auto Value : ValArray)
			  {
				  TSharedPtr<FJsonObject> NewObj = Value->AsObject();

				  UVaRestJsonObject* NewJson = NewObject<UVaRestJsonObject>();
				  NewJson->SetRootObject(NewObj);

				  OutArray.Add(NewJson);
			  }
		 }
	 }
	 return OutArray;

 }

 float UHttpRestBlueprintFunctionLibrary::GetJsonFloat(FString JsonString, FString Key)
 {
	 float value = 0.f;
	 if (JsonString != ""&&Key != "")
	 {

		 TSharedPtr<FJsonObject> JsonObj;
		 TSharedRef<TJsonReader<TCHAR>> JsonReader = TJsonReaderFactory<TCHAR>::Create(JsonString);

		 if (FJsonSerializer::Deserialize(JsonReader, JsonObj))
		 {
			 value = JsonObj->GetNumberField(Key);
		 }
	 }
	 return value;
 }
