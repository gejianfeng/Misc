#include "BlackShieldNetNative.h"
#include "BlackShieldNetNativeConfig.h"
#include "BlackShieldNetNativeModule.h"

FBlackShieldNetNativeConfig::FBlackShieldNetNativeConfig()
	: InputType(EBSInputType::HTCVive)
	, MoveType(EBSMoveType::Fly)
	, Port(7777)
{

}

void FBlackShieldNetNativeConfig::LoadGameConfig()
{
	int32 IntValue = 0;

	if (!GConfig)
		return;

	bool bIsValid = false;
	bIsValid = GConfig->GetInt(TEXT("Input"), TEXT("InputType"), IntValue, GGameIni);

	if (bIsValid)
	{
		InputType = static_cast<EBSInputType>(IntValue);
	}

	bIsValid = GConfig->GetInt(TEXT("Move"), TEXT("MoveType"), IntValue, GGameIni);

	if (bIsValid)
	{
		MoveType = static_cast<EBSMoveType>(IntValue);
	}

	bIsValid = GConfig->GetString(TEXT("DelicatedServer"), TEXT("Host"), Host, GGameIni);
	if (!bIsValid)
	{
		Host = "127.0.0.1";
	}

	GConfig->GetInt(TEXT("DelicatedServer"), TEXT("Port"), Port, GGameIni);
}

const FBlackShieldNetNativeConfig& GetBlackShieldConfig()
{
	static FBlackShieldNetNativeConfig NullBlackShieldConfig;
	if (g_BlackShieldNetNativeModule)
	{
		return g_BlackShieldNetNativeModule->GetConfig();
	}

	return NullBlackShieldConfig;
}

