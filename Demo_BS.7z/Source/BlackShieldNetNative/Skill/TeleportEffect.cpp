#include "BlackShieldNetNative.h"
#include "TeleportEffect.h"
#include "SkillTeleport.h"

ATeleportEffect::ATeleportEffect(const FObjectInitializer& ObjectInitializer /*= FObjectInitializer::Get()*/)
	: Super(ObjectInitializer)
{
	bReplicates = false;

	SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
	RootComponent = SceneRoot;

	TeleportSign = CreateDefaultSubobject<UParticleSystemComponent>(TEXT("TeleportSign"));
	TeleportSign->SetupAttachment(RootComponent);

	TeleBeamTrail = CreateDefaultSubobject<UParticleSystemComponent>(TEXT("TeleBeamTrail"));
	TeleBeamTrail->SetupAttachment(RootComponent);
}

void ATeleportEffect::SetTeleportSignLocationAndRotation(const FVector& Location, const FRotator& Rotation)
{
	TeleportSign->SetWorldLocationAndRotation(Location, Rotation);
}

void ATeleportEffect::GetTeleportSignLocationAndRotation(FVector& OutLocation, FRotator& OutRotation)
{
	OutLocation = TeleportSign->GetComponentLocation();
	OutRotation = TeleportSign->GetComponentRotation();
}

void ATeleportEffect::SetTeleportSignVisible(bool bVisible)
{
	TeleportSign->SetVisibility(bVisible, true);
}

bool ATeleportEffect::GetTeleportSignVisible() const
{
	return TeleportSign->bVisible;
}

void ATeleportEffect::SetTeleportBeamTrailVisible(bool bVisible)
{
	TeleBeamTrail->SetVisibility(bVisible);
}

bool ATeleportEffect::GetTeleportBeamtRailVisible() const
{
	return TeleBeamTrail->bVisible;
}

void ATeleportEffect::SetTeleportBeamTrail(const FVector& SourceLocation, const FVector& TargetLocation, const FVector& TracedVector, ETeleportHitType HitType)
{
	if (TeleBeamTrail)
	{
		TeleBeamTrail->SetBeamSourcePoint(0, SourceLocation, 0);
		TeleBeamTrail->SetBeamTargetPoint(0, TargetLocation, 0);

		FVector TargetTangentPoint = TargetLocation - SourceLocation;
		FVector2D Vec2D(TargetTangentPoint.X, TargetTangentPoint.Y);
		float Dist = Vec2D.Size();

		ASkillTeleport* SkillTeleport = Cast<ASkillTeleport>(GetOwner());
		float MaxTeleportDistance = 800;
		if (SkillTeleport)
		{
			MaxTeleportDistance = SkillTeleport->GetMaxTeleportDistance();
		}
		float Alpha = Dist / MaxTeleportDistance;

		Alpha = FMath::Pow(Alpha, 10);

		TargetTangentPoint.X = 0;
		TargetTangentPoint.Y = 0;
		TargetTangentPoint.Z *= Alpha * 0.3;

		TeleBeamTrail->SetBeamTargetTangent(0, TargetTangentPoint, 0);
	}
}
