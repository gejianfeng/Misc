#pragma once

UENUM(BlueprintType)
enum class ETeleportHitType : uint8
{
	OnTheFloor,
	OnTheWall
};

#define TELEPORT_GROUND_TAG TEXT("TeleportGround")