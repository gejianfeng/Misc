#pragma once

#include "SkillBase.h"
#include "SkillKnife.generated.h"

UCLASS(Abstract)
class ASkillKnife : public ASkillBase
{
	GENERATED_BODY()

public:
	ASkillKnife(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());

protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	class USkeletalMeshComponent* SkeletalMesh;
};