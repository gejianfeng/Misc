#pragma once

#include "SkillBase.h"
#include "SkillTeleport.generated.h"

UCLASS(Abstract)
class ASkillTeleport : public ASkillBase
{
	GENERATED_BODY()

public:
	ASkillTeleport(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());

	virtual void LocalPlayerInit() override;

	virtual void StartUse_Implementation() override;

	virtual void StopUse_Implementation() override;

	float GetMaxTeleportDistance() { return MaxTeleportDistance; }

	UFUNCTION(BlueprintCallable, Category = "Teleport")
	void TeleportToTarget(const FVector& TargetLocation);

	UFUNCTION(Server, WithValidation, Reliable, BlueprintCallable, Category = "Teleport")
	void ServerStartTeleport(const FVector& Location);

	bool ServerStartTeleport_Validate(const FVector& Location);

	void ServerStartTeleport_Implementation(const FVector& Location);

	virtual void FinishDestroy() override;

	virtual void Tick(float DeltaSeconds) override;

	void ReTractHitResult(const FVector& StartLocation, const FHitResult &HitResult);

	void CheckAndCorrectWhenBlocking();

	void CheckAndCorrectMaxTeleportDistance();

	virtual void BeginDestroy() override;

	virtual void Destroyed() override;

	void ClearCoolDownTimer();

	void HandleOnCoolDownTimeUp();

protected:
	virtual void OnRep_Owner() override;

	void InitLocalPlayerEffect();

protected:
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Effect")
	TSubclassOf<class ATeleportEffect> TeleportEffectClass;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Effect")
	ATeleportEffect* TeleportEffect;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Teleport")
	float MaxTraceDistance;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Teleport")
	float MaxTeleportDistance;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Effect")
	uint32 bActiveEffect : 1;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Teleport")
	uint32 bNeedCorrectDestinationLocation : 1;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Teleport")
	uint32 bRetrievedCorrectLocation : 1;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Teleport")
	float ReTractDistance;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Teleport")
	class AActor* TracedActor;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Teleport")
	FHitResult CachedHitResult;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Teleport")
	FVector StartTracePoint;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Teleport")
	FVector DestinationPoint;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Teleport")
	FTimerHandle CoolDownTimeHandle;
};
