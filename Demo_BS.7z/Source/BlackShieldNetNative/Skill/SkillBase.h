#pragma once

#include "SkillBase.generated.h"

UCLASS(Abstract, BlueprintType, Blueprintable, notplaceable)
class ASkillBase : public AActor
{
	friend class UBSNSkillManager;

	GENERATED_BODY()

public:
	ASkillBase(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());

	virtual void LocalPlayerInit();

	UFUNCTION(BlueprintCallable, Category = "Skill")
	void SetOwningCharacter(class ABSNCharacter* InCharacter);

	const FName& GetBindToSocketName() const { return BindToSocketName; }

	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Skill")
	void ActivateSkill();

	virtual void ActivateSkill_Implementation();

	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Skill")
	void DeactivateSkill();

	virtual void DeactivateSkill_Implementation();

	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Skill")
	void StartUse();

	virtual void StartUse_Implementation();

	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Skill")
	void StopUse();

	virtual void StopUse_Implementation();

	bool IsInCoolDown() const;

protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Replicated)
	class UBSNSkillManager* OwningSkillManager;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Replicated)
	class ABSNCharacter* OwningCharacter;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	uint32 bInCoolDown : 1;

	uint32 bLocalPlayerInited : 1;

	uint32 bStartUse : 1;

protected:
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	FName BindToSocketName;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	float DefaultCoolDown;
};
