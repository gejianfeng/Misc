#include "BlackShieldNetNative.h"
#include "SkillBase.h"
#include "Component/BSNSkillManager.h"
#include "Player/BSNCharacter.h"

ASkillBase::ASkillBase(const FObjectInitializer& ObjectInitializer /*= FObjectInitializer::Get()*/)
	: Super(ObjectInitializer)
{
	bReplicates = true;
	bReplicateMovement = false;
	bNetLoadOnClient = true;

	DefaultCoolDown = 0;
	bInCoolDown = false;

	RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));

	bLocalPlayerInited = false;

	bStartUse = false;
}

void ASkillBase::LocalPlayerInit()
{
	bLocalPlayerInited = true;
}

void ASkillBase::SetOwningCharacter(class ABSNCharacter* InCharacter)
{
	OwningCharacter = InCharacter;
	if (InCharacter)
	{
		OwningSkillManager = InCharacter->GetSkillManager();
	}

	SetOwner(InCharacter);
}

void ASkillBase::ActivateSkill_Implementation()
{

}

void ASkillBase::DeactivateSkill_Implementation()
{

}

void ASkillBase::StartUse_Implementation()
{

}

void ASkillBase::StopUse_Implementation()
{

}

void ASkillBase::GetLifetimeReplicatedProps(TArray<class FLifetimeProperty> & OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(ASkillBase, OwningSkillManager);
	DOREPLIFETIME(ASkillBase, OwningCharacter);
}

bool ASkillBase::IsInCoolDown() const
{
	return bInCoolDown;
}