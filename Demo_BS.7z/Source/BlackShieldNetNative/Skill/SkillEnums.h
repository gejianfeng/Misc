#pragma once

#include "SkillEnums.generated.h"

UENUM(BlueprintType)
enum class EBSNSkillType : uint8
{
	None,
	Knife,
	Teleport
};
