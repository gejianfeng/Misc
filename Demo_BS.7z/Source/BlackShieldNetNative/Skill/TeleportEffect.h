#pragma once

#include "SkillTeleportCommons.h"
#include "TeleportEffect.generated.h"

UCLASS(Abstract, Blueprintable, BlueprintType)
class ATeleportEffect : public AActor
{
	GENERATED_BODY()

public:
	ATeleportEffect(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());

	void SetTeleportSignLocationAndRotation(const FVector& Location, const FRotator& Rotation);

	void GetTeleportSignLocationAndRotation(FVector& OutLocation, FRotator& OutRotation);

	void SetTeleportSignVisible(bool bVisible);
	bool GetTeleportSignVisible() const;

	void SetTeleportBeamTrailVisible(bool bVisible);
	bool GetTeleportBeamtRailVisible() const;

	void SetTeleportBeamTrail(const FVector& SourceLocation, const FVector& TargetLocation, const FVector& TracedVector, ETeleportHitType HitType);

protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	class USceneComponent* SceneRoot;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	class UParticleSystemComponent* TeleportSign;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	class UParticleSystemComponent* TeleBeamTrail;
};
