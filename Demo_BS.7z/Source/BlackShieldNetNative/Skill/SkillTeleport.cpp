#include "BlackShieldNetNative.h"
#include "SkillTeleport.h"
#include "TeleportEffect.h"
#include "Player/BSNCharacter.h"
#include "BlackShieldNetNativeConfig.h"

ASkillTeleport::ASkillTeleport(const FObjectInitializer& ObjectInitializer /*= FObjectInitializer::Get()*/)
	: Super(ObjectInitializer)
{
	BindToSocketName = TEXT("TeleportTest");
	bReplicateMovement = false;

	DefaultCoolDown = 0.5f;

	MaxTraceDistance = 100000;

	MaxTeleportDistance = 800;

	TracedActor = nullptr;
	bNeedCorrectDestinationLocation = true;
	bRetrievedCorrectLocation = false;

	ReTractDistance = 40.0f;

	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickGroup = TG_PostPhysics;
}

void ASkillTeleport::LocalPlayerInit()
{
	if (!bLocalPlayerInited)
	{
		InitLocalPlayerEffect();
		bLocalPlayerInited = true;
	}
}

void ASkillTeleport::StartUse_Implementation()
{
	if (bStartUse)
		return;
	bStartUse = true;

	if (bInCoolDown)
		return;

	bInCoolDown = true;

	if (TeleportEffect)
	{
		TeleportEffect->SetTeleportSignVisible(true);
		TeleportEffect->SetTeleportBeamTrailVisible(true);
	}

	bActiveEffect = true;

	if (GetBlackShieldConfig().InputType == EBSInputType::Keyboard)
	{

	}
	else
	{

	}
}

void ASkillTeleport::StopUse_Implementation()
{
	if (!bStartUse)
		return;
	bStartUse = false;

	if (TeleportEffect)
	{
		TeleportEffect->SetTeleportSignVisible(false);
		TeleportEffect->SetTeleportBeamTrailVisible(false);
	}

	bActiveEffect = false;

	GetWorld()->GetTimerManager().SetTimer(CoolDownTimeHandle, this, &ASkillTeleport::HandleOnCoolDownTimeUp, DefaultCoolDown, false);

	if (bRetrievedCorrectLocation && OwningCharacter)
	{
		DestinationPoint.Z = OwningCharacter->GetActorLocation().Z;
		TeleportToTarget(DestinationPoint);
	}
}

void ASkillTeleport::TeleportToTarget(const FVector& TargetLocation)
{
	if (OwningCharacter)
	{
		OwningCharacter->Blink(TargetLocation); 
	}
}

bool ASkillTeleport::ServerStartTeleport_Validate(const FVector& Location)
{
	return true;
}

void ASkillTeleport::ServerStartTeleport_Implementation(const FVector& Location)
{
	// Temporary
	OwningCharacter->SetActorLocation(Location);
}

void ASkillTeleport::FinishDestroy()
{
	Super::FinishDestroy();
}

void ASkillTeleport::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	bRetrievedCorrectLocation = false;

	if (bActiveEffect)
	{
		StartTracePoint = GetActorLocation();

		if (GetBlackShieldConfig().InputType == EBSInputType::Keyboard)
		{
			APlayerController* PlayerController = Cast<APlayerController>(OwningCharacter->GetController());
			if (PlayerController)
			{
				FHitResult HitResult;
				if (PlayerController->GetHitResultUnderCursor(ECC_TeleportWall, false, HitResult))
				{
					AActor* ActorHit = HitResult.Actor.Get();
					if (ActorHit)
					{
						if (ActorHit->ActorHasTag(TELEPORT_GROUND_TAG))
						{
							TracedActor = ActorHit;
							bRetrievedCorrectLocation = true;
							DestinationPoint = HitResult.Location;

							if (bNeedCorrectDestinationLocation)
							{
								CheckAndCorrectWhenBlocking();
							}
						}
						else if (bNeedCorrectDestinationLocation)
						{
							ReTractHitResult(GetActorLocation(), HitResult);
						}
					}
				}
			}
		}
		else
		{
			FHitResult HitResult;
			FVector StartTraceLocatoin = GetActorLocation();
			FVector EndTraceLocation = StartTraceLocatoin + FRotationMatrix(GetActorRotation()).GetUnitAxis(EAxis::X) * MaxTraceDistance;
			FCollisionQueryParams QueryParams;
			QueryParams.AddIgnoredActor(this);
			QueryParams.AddIgnoredActor(GetOwner());
			QueryParams.AddIgnoredActor(TeleportEffect);

			if (GetWorld()->LineTraceSingleByChannel(HitResult, StartTraceLocatoin, EndTraceLocation, ECC_TeleportWall, QueryParams))
			{
				AActor* ActorHit = HitResult.Actor.Get();
				if (ActorHit)
				{
					if (ActorHit->ActorHasTag(TELEPORT_GROUND_TAG))
					{
						TracedActor = ActorHit;
						bRetrievedCorrectLocation = true;
						DestinationPoint = HitResult.Location;

						CachedHitResult = HitResult;

						if (bNeedCorrectDestinationLocation)
						{
							CheckAndCorrectWhenBlocking();
						}
					}
					else if (bNeedCorrectDestinationLocation)
					{
						ReTractHitResult(GetActorLocation(), HitResult);
					}
				}
			}
		}

		if (bRetrievedCorrectLocation)
		{
			CheckAndCorrectMaxTeleportDistance(); // Finally check the distance

			TeleportEffect->SetTeleportSignLocationAndRotation(DestinationPoint, FRotator::ZeroRotator);
			TeleportEffect->SetTeleportBeamTrail(GetActorLocation(), DestinationPoint, CachedHitResult.ImpactPoint - CachedHitResult.TraceStart, ETeleportHitType::OnTheFloor);
		}
	}
}

void ASkillTeleport::ReTractHitResult(const FVector& StartLocation, const FHitResult &HitResult)
{
	bool bReTractSuccess = false;

	FVector StartReTractLocation;
	FVector EndReTractLocation;

	float CosNU = HitResult.Normal | FVector::UpVector;
	if (FMath::Abs(CosNU) <= 0.08f) // Hit the wall
	{
		FVector FixedNormal(HitResult.Normal.X, HitResult.Normal.Y, 0);
		FixedNormal.Normalize();
		StartReTractLocation.X = (HitResult.Location.X);
		StartReTractLocation.Y = (HitResult.Location.Y);
		StartReTractLocation.Z = (HitResult.Location.Z + 10);
		StartReTractLocation += FixedNormal * ReTractDistance;

		EndReTractLocation = StartReTractLocation + (-FVector::UpVector) * 1000;

		bReTractSuccess = true;
	}
	else if (FMath::Abs(CosNU) >= 0.99) // Hit the prop's top
	{
		FVector TraceVector = HitResult.ImpactPoint - StartLocation;

		float NDotF = TraceVector | FVector::ForwardVector;
		float NDotR = TraceVector | FVector::RightVector;

		FVector OffsetDirection = FVector::ForwardVector;

		float MaxDotValue = 0;

		if (FMath::Abs(NDotF) > FMath::Abs(NDotR))
		{
			MaxDotValue = NDotF;
			OffsetDirection = FVector::ForwardVector;
		}
		else
		{
			MaxDotValue = NDotR;
			OffsetDirection = FVector::RightVector;
		}

		if (MaxDotValue > 0)
		{
			OffsetDirection = -OffsetDirection;
		}

		AActor* HitActor = HitResult.Actor.Get();
		if (HitActor)
		{
			FVector Center;
			FVector Extent;
			HitActor->GetActorBounds(false, Center, Extent);

			StartReTractLocation = Center + (Extent * OffsetDirection) * OffsetDirection + ReTractDistance * OffsetDirection;
			StartReTractLocation.Z += 10.0f;

			EndReTractLocation = StartReTractLocation + (-FVector::UpVector) * 1000;

			bReTractSuccess = true;
		}
	}

	if (bReTractSuccess)
	{
		FHitResult ReTractHitResult;
		FCollisionQueryParams QueryParams;
		QueryParams.AddIgnoredActor(this);
		QueryParams.AddIgnoredActor(GetOwner());
		QueryParams.AddIgnoredActor(TeleportEffect);

		if (GetWorld()->LineTraceSingleByChannel(ReTractHitResult, StartReTractLocation, EndReTractLocation, ECC_TeleportWall, QueryParams))
		{
			AActor* ReTractActor = ReTractHitResult.Actor.Get();
			if (ReTractActor && ReTractActor->ActorHasTag(TELEPORT_GROUND_TAG))
			{
				TracedActor = ReTractActor;
				bRetrievedCorrectLocation = true;
				DestinationPoint = ReTractHitResult.Location;

				CachedHitResult = HitResult;

				CheckAndCorrectWhenBlocking();
			}
		}
	}
}

void ASkillTeleport::CheckAndCorrectWhenBlocking()
{
	FHitResult HitResult;
	
	if (!OwningCharacter)
	{
		return;
	}

	float HalfSize = ReTractDistance;

	FVector CharLocation = OwningCharacter->GetActorLocation();
	float MaxZ = FMath::Max(CharLocation.Z, DestinationPoint.Z);

	FVector StartTraceLocatoin = CharLocation;
	FVector EndTraceLocation = DestinationPoint;
	StartTraceLocatoin.Z = MaxZ + HalfSize * 1.2f;
	EndTraceLocation.Z = MaxZ + HalfSize * 1.2f;

	FQuat QuatOrient = (EndTraceLocation - StartTraceLocatoin).ToOrientationQuat();

	FVector BoxExtent(HalfSize, HalfSize, HalfSize);

	TArray<AActor*> ActorsToIgnore;
	ActorsToIgnore.Add(this);
	ActorsToIgnore.Add(GetOwner());
	ActorsToIgnore.Add(TeleportEffect);

	static const FName BoxTraceSingleName(TEXT("BoxTraceSingle"));

	FCollisionQueryParams Params(BoxTraceSingleName, false);
	Params.bReturnPhysicalMaterial = true;
	Params.bTraceAsyncScene = true;
	Params.AddIgnoredActors(ActorsToIgnore);

	UWorld* World = GetWorld();
	bool const bHit = World ? World->SweepSingleByChannel(HitResult, StartTraceLocatoin, EndTraceLocation, QuatOrient, ECC_TeleportWall, FCollisionShape::MakeBox(BoxExtent), Params) : false;
	if (bHit) // Need correct location
	{
		bRetrievedCorrectLocation = false;

		FVector FixedNormal(HitResult.Normal.X, HitResult.Normal.Y, 0);
		FixedNormal.Normalize();
		FVector StartReTractLocation(HitResult.Location.X, HitResult.Location.Y, HitResult.Location.Z);
		StartReTractLocation += FixedNormal * ReTractDistance;

		FVector EndReTractLocation;
		EndReTractLocation = StartReTractLocation + (-FVector::UpVector) * 1000;

		FHitResult ReTractHitResult;
		FCollisionQueryParams QueryParams;
		QueryParams.AddIgnoredActor(this);
		QueryParams.AddIgnoredActor(GetOwner());
		QueryParams.AddIgnoredActor(TeleportEffect);

		if (GetWorld()->LineTraceSingleByChannel(ReTractHitResult, StartReTractLocation, EndReTractLocation, ECC_TeleportWall, QueryParams))
		{
			AActor* ReTractActor = ReTractHitResult.Actor.Get();
			if (ReTractActor && ReTractActor->ActorHasTag(TELEPORT_GROUND_TAG))
			{
				TracedActor = ReTractActor;
				bRetrievedCorrectLocation = true;
				DestinationPoint = ReTractHitResult.Location;

				CachedHitResult = HitResult;
			}
		}
	}
}

void ASkillTeleport::CheckAndCorrectMaxTeleportDistance()
{
	if (!OwningCharacter)
	{
		return;
	}

	if (!bRetrievedCorrectLocation)
		return;

	FVector CharLocation = OwningCharacter->GetActorLocation();

	FVector2D Delta2D(DestinationPoint.X - CharLocation.X, DestinationPoint.Y - CharLocation.Y);
	float PlaneDist = Delta2D.Size();

	FVector TeleportDirection = (DestinationPoint - CharLocation).GetSafeNormal();

	if (PlaneDist > MaxTeleportDistance)
	{
		DestinationPoint = CharLocation + MaxTeleportDistance * TeleportDirection;
	}
}

void ASkillTeleport::BeginDestroy()
{
	Super::BeginDestroy();

	ClearCoolDownTimer();
}

void ASkillTeleport::Destroyed()
{
	if (TeleportEffect)
	{
		TeleportEffect->Destroy();
		TeleportEffect = nullptr;
	}

	ClearCoolDownTimer();

	Super::Destroyed();
}

void ASkillTeleport::ClearCoolDownTimer()
{
	if (CoolDownTimeHandle.IsValid())
	{
		UWorld* World = GetWorld();
		if (World)
		{
			World->GetTimerManager().ClearTimer(CoolDownTimeHandle);
			CoolDownTimeHandle.Invalidate();
		}
	}
}

void ASkillTeleport::HandleOnCoolDownTimeUp()
{
	bInCoolDown = false;
}

void ASkillTeleport::OnRep_Owner()
{
	if (GetOwner() && GetOwner()->Role == ROLE_AutonomousProxy)
	{
		InitLocalPlayerEffect();
	}
}

void ASkillTeleport::InitLocalPlayerEffect()
{
	if (TeleportEffectClass)
	{
		TeleportEffect = GetWorld()->SpawnActor<ATeleportEffect>(TeleportEffectClass);
		TeleportEffect->SetOwner(this);
		if (TeleportEffect)
		{
			TeleportEffect->SetTeleportSignVisible(false);
			TeleportEffect->SetTeleportBeamTrailVisible(false);
		}
	}
}
