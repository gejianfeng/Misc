// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "Kismet/BlueprintFunctionLibrary.h"
#include "RecordBlueprintFunctionLibrary.generated.h"

/**
 * 
 */
UCLASS()
class URecordBlueprintFunctionLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()
	
public:
	UFUNCTION(BlueprintCallable, Category = "Game")
		static void LoadRecored(FString FileName, TArray<float>& Atime, TArray<FVector>& AHeadLoc, TArray<FRotator>& AHeadRot,
			TArray<FVector>& AHandLoc_L, TArray<FRotator>& AHandRot_L,
			TArray<FVector>& AHandLoc_R, TArray<FRotator>& AHandRot_R);

	UFUNCTION(BlueprintCallable, Category = "Game")
		static void SaveRecored(FString FileName, TArray<float> ATime, TArray<FVector> AHeadLoc, TArray<FRotator> AHeadRot,
			TArray<FVector> AHandLoc_L, TArray<FRotator> AHandRot_L,
			TArray<FVector> AHandLoc_R, TArray<FRotator> AHandRot_R);
	
};
