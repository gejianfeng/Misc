#pragma once

#include "BlackShieldCommons.h"

class FBlackShieldNetNativeConfig
{
public:
	FBlackShieldNetNativeConfig();
	void LoadGameConfig();
public:
	EBSInputType InputType;
	EBSMoveType MoveType;
	FString Host;
	int32 Port;
};

const FBlackShieldNetNativeConfig& GetBlackShieldConfig();