#include "BlackShieldNetNative.h"
#include "BSNAnimInstance.h"
#include "Player/BSNCharacter.h"

UBSNAnimInstance::UBSNAnimInstance(const FObjectInitializer& ObjectInitializer /*= FObjectInitializer::Get()*/)
	: Super(ObjectInitializer)
{

}

class ABSNCharacter* UBSNAnimInstance::TryGetBSNCharacter() const
{
	USkeletalMeshComponent* OwnerComponent = GetSkelMeshComponent();
	if (AActor* OwnerActor = OwnerComponent->GetOwner())
	{
		return Cast<class ABSNCharacter>(OwnerActor);
	}

	return NULL;
}
