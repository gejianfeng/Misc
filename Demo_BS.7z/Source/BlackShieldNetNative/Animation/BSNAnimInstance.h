#pragma once

#include "Interface/CharacterAnimInterface.h"
#include "Animation/AnimInstance.h"
#include "BSNAnimInstance.generated.h"

UCLASS(transient, Blueprintable, hideCategories = AnimInstance, BlueprintType)
class UBSNAnimInstance 
	: public UAnimInstance
	, public ICharacterAnimInterface
{
	GENERATED_BODY()

public:
	UBSNAnimInstance(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());

	UFUNCTION(BlueprintCallable, Category = "Animation")
	class ABSNCharacter* TryGetBSNCharacter() const;
};
