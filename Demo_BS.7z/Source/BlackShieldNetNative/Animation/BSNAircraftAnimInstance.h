#pragma once

#include "Interface/AircraftAnimInterface.h"
#include "Animation/AnimInstance.h"
#include "BSNAircraftAnimInstance.generated.h"

UCLASS(transient, Blueprintable, hideCategories = AnimInstance, BlueprintType)
class UBSNAircraftAnimInstance
	: public UAnimInstance
	, public IAircraftAnimInterface
{
	GENERATED_BODY()

public:
	UBSNAircraftAnimInstance(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());

	virtual void SetAccelerate_Implementation(float ForwardVal, float RightVal) override;
	virtual void SetAccelerateForward_Implementation(float ForwardVal) override;
	virtual void SetAccelerateRight_Implementation(float RightVal) override;

protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Default")
	float MoveRight;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Default")
	float MoveForward;
};
