#include "BlackShieldNetNative.h"
#include "BSNAircraftAnimInstance.h"

UBSNAircraftAnimInstance::UBSNAircraftAnimInstance(const FObjectInitializer& ObjectInitializer /*= FObjectInitializer::Get()*/)
	: Super(ObjectInitializer)
{
	MoveForward = 0;
	MoveRight = 0;
}

void UBSNAircraftAnimInstance::SetAccelerate_Implementation(float ForwardVal, float RightVal)
{
	MoveForward = ForwardVal;
	MoveRight = RightVal;
}

void UBSNAircraftAnimInstance::SetAccelerateForward_Implementation(float ForwardVal)
{
	MoveForward = ForwardVal;
}

void UBSNAircraftAnimInstance::SetAccelerateRight_Implementation(float RightVal)
{
	MoveRight = RightVal;
}