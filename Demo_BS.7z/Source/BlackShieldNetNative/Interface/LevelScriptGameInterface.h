#pragma once

#include "LevelScriptGameInterface.generated.h"

UINTERFACE(MinimalAPI)
class ULevelScriptGameInterface : public UInterface
{
	GENERATED_BODY()
};

class ILevelScriptGameInterface
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "GameMode")
	void GameModeStarted();
	
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "GameMode")
	FName GetWaitingRoomMapName();

	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "GameMode")
	void GetGameMapNames(TArray<FName>& MapNames);

	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "GameMode")
	bool NeedWaitingRoom();
};
