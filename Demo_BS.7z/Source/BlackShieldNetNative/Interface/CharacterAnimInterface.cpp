#include "BlackShieldNetNative.h"
#include "CharacterAnimInterface.h"

void ICharacterAnimInterface::SetNeckInfo_Implementation(const FVector& Location, const FRotator& Rotation)
{

}

void ICharacterAnimInterface::SetHandInfo_Implementation(EControllerHand Hand, const FVector& Location, const FRotator& Rotatoin)
{

}

void ICharacterAnimInterface::SetHandEnableOrientation_Implementation(EControllerHand Hand, bool Enabled)
{

}

void ICharacterAnimInterface::SetHandAction_Implementation(EControllerHand Hand, EBSHandAction Action)
{

}

void ICharacterAnimInterface::SetBodyInfo_Implementation(float Speed, float Direction, float RotateSpeed)
{

}

void ICharacterAnimInterface::SetDoFKAnim_Implementation(EFKAnimState FKAnimState)
{

}

void ICharacterAnimInterface::UseIKAnim_Implementation()
{

}

void ICharacterAnimInterface::SetIKAnim_Implementation(EIKAnimState IKAnimState)
{

}

void ICharacterAnimInterface::FireActionWithRecoil_Implementation(EControllerHand Hand, const FName& SocketName, UCurveVector* Curve)
{

}
