#pragma once

#include "BlackShieldCommons.h"
#include "PickupInterface.generated.h"

UINTERFACE(MinimalAPI)
class UPickupInterface : public UInterface
{
	GENERATED_BODY()
};

class IPickupInterface
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "PickUp")
	void OnLeftHandPickup();

	virtual void OnLeftHandPickup_Implementation();

	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "PickUp")
		void OnRightHandPickup();

	virtual void OnRightHandPickup_Implementation();

};
