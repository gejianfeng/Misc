#include "BlackShieldNetNative.h"
#include "PickupInterface.h"

void IPickupInterface::OnLeftHandPickup_Implementation()
{

}
void IPickupInterface::OnRightHandPickup_Implementation()
{

}
