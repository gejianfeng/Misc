#pragma once

#include "BlackShieldCommons.h"
#include "CharacterAnimInterface.generated.h"

UINTERFACE(MinimalAPI)
class UCharacterAnimInterface : public UInterface
{
	GENERATED_BODY()
};

class ICharacterAnimInterface
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Anim")
	void SetNeckInfo(const FVector& Location, const FRotator& Rotation);

	virtual void SetNeckInfo_Implementation(const FVector& Location, const FRotator& Rotation);

	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Anim")
	void SetHandInfo(EControllerHand Hand, const FVector& Location, const FRotator& Rotatoin);

	virtual void SetHandInfo_Implementation(EControllerHand Hand, const FVector& Location, const FRotator& Rotatoin);

	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Anim")
	void SetHandEnableOrientation(EControllerHand Hand, bool Enabled);

	virtual void SetHandEnableOrientation_Implementation(EControllerHand Hand, bool Enabled);

	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Anim")
	void SetHandAction(EControllerHand Hand, EBSHandAction Action);

	virtual void SetHandAction_Implementation(EControllerHand Hand, EBSHandAction Action);

	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Anim")
	void SetBodyInfo(float Speed, float Direction, float RotateSpeed);

	virtual void SetBodyInfo_Implementation(float Speed, float Direction, float RotateSpeed);

	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Anim")
	void SetDoFKAnim(EFKAnimState FKAnimState);

	virtual void SetDoFKAnim_Implementation(EFKAnimState FKAnimState);

	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Anim")
	void UseIKAnim();

	virtual void UseIKAnim_Implementation();

	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Anim")
	void SetIKAnim(EIKAnimState IKAnimState);

	virtual void SetIKAnim_Implementation(EIKAnimState IKAnimState);

	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Anim")
	void FireActionWithRecoil(EControllerHand Hand, const FName& SocketName, UCurveVector* Curve);

	virtual void FireActionWithRecoil_Implementation(EControllerHand Hand, const FName& SocketName, UCurveVector* Curve);
};
