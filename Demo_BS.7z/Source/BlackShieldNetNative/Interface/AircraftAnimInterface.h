#pragma once

#include "AircraftAnimInterface.generated.h"

UINTERFACE(MinimalAPI)
class UAircraftAnimInterface : public UInterface
{
	GENERATED_BODY()
};

class IAircraftAnimInterface
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Anim")
	void SetAccelerate(float ForwardVal, float RightVal);

	virtual void SetAccelerate_Implementation(float ForwardVal, float RightVal);

	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Anim")
	void SetAccelerateForward(float ForwardVal);

	virtual void SetAccelerateForward_Implementation(float ForwardVal);

	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Anim")
	void SetAccelerateRight(float RightVal);

	virtual void SetAccelerateRight_Implementation(float RightVal);
};