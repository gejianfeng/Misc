#pragma once

#include "MatchGameInterface.generated.h"

UINTERFACE(MinimalAPI)
class UMatchGameInterface : public UInterface
{
	GENERATED_BODY()
};

class IMatchGameInterface
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = Match)
	void OnMatchStarted();

	virtual void OnMatchStarted_Implementation();
};
