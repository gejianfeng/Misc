#include "BlackShieldNetNative.h"
#include "OperatorTableActivateInterface.h"

void IOperatorTableActivateInterface::TableActivate_Implementation()
{

}
