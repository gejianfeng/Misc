#pragma once

#include "OperatorTableActivateInterface.generated.h"

UINTERFACE(MinimalAPI)
class UOperatorTableActivateInterface : public UInterface
{
	GENERATED_BODY()
};

class IOperatorTableActivateInterface
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = Table)
	void TableActivate();

	virtual void TableActivate_Implementation();
};
