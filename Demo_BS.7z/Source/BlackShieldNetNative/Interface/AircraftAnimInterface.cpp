#include "BlackShieldNetNative.h"
#include "AircraftAnimInterface.h"

void IAircraftAnimInterface::SetAccelerate_Implementation(float ForwardVal, float RightVal)
{

}

void IAircraftAnimInterface::SetAccelerateForward_Implementation(float ForwardVal)
{

}

void IAircraftAnimInterface::SetAccelerateRight_Implementation(float RightVal)
{

}