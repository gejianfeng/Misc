#include "BlackShieldNetNative.h"
#include "MatchGameInterface.h"

void IMatchGameInterface::OnMatchStarted_Implementation()
{

}
