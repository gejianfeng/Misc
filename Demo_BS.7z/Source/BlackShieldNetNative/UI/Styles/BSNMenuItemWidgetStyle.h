#pragma once

#include "SlateWidgetStyleContainerBase.h"
#include "BSNMenuItemWidgetStyle.generated.h"

USTRUCT()
struct FBSNMenuItemStyle : public FSlateWidgetStyle
{
	GENERATED_USTRUCT_BODY()

	FBSNMenuItemStyle();
	virtual ~FBSNMenuItemStyle();
	
	virtual void GetResources(TArray<const FSlateBrush*> & OutBrushes) const override;
	static  const FName TypeName;
	virtual const FName GetTypeName() const override { return TypeName; }
	static  const FBSNMenuItemStyle &GetDefault();

	UPROPERTY(EditAnywhere, Category = Appearance)
	FSlateBrush BackgroundBrush;
	FBSNMenuItemStyle &SetBackgroundBrush(const FSlateBrush &InBackgroundBrush) { BackgroundBrush = InBackgroundBrush; return *this; }

	UPROPERTY(EditAnywhere, Category = Appearance)
	FSlateBrush LeftArrowImage;
	FBSNMenuItemStyle &SetLeftArrowImage(const FSlateBrush &InLeftArrowImage) { LeftArrowImage = InLeftArrowImage; return *this; }

	UPROPERTY(EditAnywhere, Category = Appearance)
	FSlateBrush RightArrowImage;
	FBSNMenuItemStyle &SetRightArrowImage(const FSlateBrush &InRightArrowImage) { RightArrowImage = InRightArrowImage; return *this; }
};

UCLASS(hidecategories=Object,MinimalAPI)
class UBSNMenuItemWidgetStyle : public USlateWidgetStyleContainerBase
{
	GENERATED_UCLASS_BODY()
public:
	UPROPERTY(Category = Appearance, EditAnywhere, meta = (ShowOnlyInnerProperties))
	FBSNMenuItemStyle MenuItemStyle;
	virtual const struct FSlateWidgetStyle *const GetStyle() const override
	{
		return static_cast<const struct FSlateWidgetStyle *>(&MenuItemStyle);
	}
};


