
#include "BlackShieldNetNative.h"
#include "BSNMenuWidgetStyle.h"

FBSNMenuStyle::FBSNMenuStyle()
{
}

FBSNMenuStyle::~FBSNMenuStyle()
{
}

const FName FBSNMenuStyle::TypeName(TEXT("FBSNMenuStyle"));

const FBSNMenuStyle& FBSNMenuStyle::GetDefault()
{
	static FBSNMenuStyle Default;
	return Default;
}

void FBSNMenuStyle::GetResources(TArray<const FSlateBrush*>& OutBrushes) const
{
	OutBrushes.Add(&HeaderBackgroundBrush);
	OutBrushes.Add(&LeftBackgroundBrush);
	OutBrushes.Add(&RightBackgroundBrush);
}


UBSNMenuWidgetStyle::UBSNMenuWidgetStyle(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}
