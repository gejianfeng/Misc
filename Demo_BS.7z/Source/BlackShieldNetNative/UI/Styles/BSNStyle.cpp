
#include "BlackShieldNetNative.h"
#include "BSNStyle.h"
#include "SlateGameResources.h"

TSharedPtr< FSlateStyleSet > FBSNStyle::BSNStyleInstance = NULL;

void FBSNStyle::Initialize()
{
	if (!BSNStyleInstance.IsValid())
	{
		BSNStyleInstance = Create();
		FSlateStyleRegistry::RegisterSlateStyle(*BSNStyleInstance);
	}
}

void FBSNStyle::Shutdown()
{
	FSlateStyleRegistry::UnRegisterSlateStyle(*BSNStyleInstance);
	ensure(BSNStyleInstance.IsUnique());
	BSNStyleInstance.Reset();
}


FName FBSNStyle::GetStyleSetName()
{
	static FName StyleSetName(TEXT("BSNStyle"));
	return StyleSetName;
}

#define IMAGE_BRUSH( RelativePath, ... ) FSlateImageBrush( FPaths::GameContentDir() / "Slate"/ RelativePath + TEXT(".png"), __VA_ARGS__ )
#define BOX_BRUSH( RelativePath, ... ) FSlateBoxBrush( FPaths::GameContentDir() / "Slate"/ RelativePath + TEXT(".png"), __VA_ARGS__ )
#define BORDER_BRUSH( RelativePath, ... ) FSlateBorderBrush( FPaths::GameContentDir() / "Slate"/ RelativePath + TEXT(".png"), __VA_ARGS__ )
#define TTF_FONT( RelativePath, ... ) FSlateFontInfo( FPaths::GameContentDir() / "Slate"/ RelativePath + TEXT(".ttf"), __VA_ARGS__ )
#define OTF_FONT( RelativePath, ... ) FSlateFontInfo( FPaths::GameContentDir() / "Slate"/ RelativePath + TEXT(".otf"), __VA_ARGS__ )


TSharedRef< FSlateStyleSet > FBSNStyle::Create()
{
	TSharedRef<FSlateStyleSet> StyleRef = FSlateGameResources::New(FBSNStyle::GetStyleSetName(), "/Game/BlackShieldNew/UI/Styles", "/Game/BlackShieldNew/UI/Styles");
	FSlateStyleSet& Style = StyleRef.Get();

	Style.Set("BSNGame.MenuTextStyle", FTextBlockStyle()
		.SetFont(TTF_FONT("Fonts/Roboto-Black", 20))
		.SetColorAndOpacity(FLinearColor::White)
		.SetShadowOffset(FIntPoint(-1, 1))
	);

	Style.Set("BSNGame.MenuHeaderTextStyle", FTextBlockStyle()
		.SetFont(TTF_FONT("Fonts/Roboto-Black", 26))
		.SetColorAndOpacity(FLinearColor::White)
		.SetShadowOffset(FIntPoint(-1, 1))
	);

	// Fonts still need to be specified in code for now
	Style.Set("BSNGame.MenuServerListTextStyle", FTextBlockStyle()
		.SetFont(TTF_FONT("Fonts/Roboto-Black", 14))
		.SetColorAndOpacity(FLinearColor::White)
		.SetShadowOffset(FIntPoint(-1, 1))
	);

	Style.Set("BSNGame.ScoreboardListTextStyle", FTextBlockStyle()
		.SetFont(TTF_FONT("Fonts/Roboto-Black", 20))
		.SetColorAndOpacity(FLinearColor::White)
		.SetShadowOffset(FIntPoint(-1, 1))
	);

	Style.Set("BSNGame.MenuProfileNameStyle", FTextBlockStyle()
		.SetFont(TTF_FONT("Fonts/Roboto-Black", 18))
		.SetColorAndOpacity(FLinearColor::White)
		.SetShadowOffset(FIntPoint(-1, 1))
	);

	return StyleRef;
}

#undef IMAGE_BRUSH
#undef BOX_BRUSH
#undef BORDER_BRUSH
#undef TTF_FONT
#undef OTF_FONT

void FBSNStyle::ReloadTextures()
{
	FSlateApplication::Get().GetRenderer()->ReloadTextureResources();
}

const ISlateStyle& FBSNStyle::Get()
{
	return *BSNStyleInstance;
}

