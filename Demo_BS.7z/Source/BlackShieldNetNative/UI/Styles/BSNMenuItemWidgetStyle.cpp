
#include "BlackShieldNetNative.h"
#include "BSNMenuItemWidgetStyle.h"


FBSNMenuItemStyle::FBSNMenuItemStyle()
{
}

FBSNMenuItemStyle::~FBSNMenuItemStyle()
{
}

const FName FBSNMenuItemStyle::TypeName(TEXT("FMenuItemStyle"));

const FBSNMenuItemStyle &FBSNMenuItemStyle::GetDefault()
{
	static FBSNMenuItemStyle Default;
	return Default;
}

void FBSNMenuItemStyle::GetResources(TArray<const FSlateBrush*> & OutBrushes) const
{
	OutBrushes.Add(&BackgroundBrush);
	OutBrushes.Add(&LeftArrowImage);
	OutBrushes.Add(&RightArrowImage);
}

UBSNMenuItemWidgetStyle::UBSNMenuItemWidgetStyle(const FObjectInitializer &ObjectInitializer)
	:Super(ObjectInitializer)
{
}

