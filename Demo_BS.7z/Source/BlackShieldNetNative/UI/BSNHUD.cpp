
#include "BlackShieldNetNative.h"
#include "BSNHUD.h"
#include "Game/BSNGameState.h"
#include "Player/BSNPlayerController.h"
#include "Game/BSNPlayerState.h"

ABSNHUD::ABSNHUD(const FObjectInitializer &ObjectIntializer)
	:Super(ObjectIntializer)
{
#if !UE_SERVER
	static ConstructorHelpers::FObjectFinder<UFont> BigFontOb(TEXT("/Game/BlackShieldNew/UI/HUD/Roboto51"));
	static ConstructorHelpers::FObjectFinder<UFont> NormalFontOb(TEXT("/Game/BlackShieldNew/UI/HUD/Roboto18"));
	BigFont = BigFontOb.Object;
	NormalFont = NormalFontOb.Object;
	TinyFont = NormalFont;
	bShowOverlays = true;
#endif
}

void ABSNHUD::DrawHUD()
{
	Super::DrawHUD();

	ABSNGameState * MyGameState = Cast<ABSNGameState>(GetWorld()->GetGameState());
	if (MyGameState)
	{
		FName State = MyGameState->GetMatchState();

		if (State == ABSNGameState::WaitForEnter)
		{
			DrawWaitPlayerJoin(MyGameState);
		}
		else if (State == ABSNGameState::WaitForPlay)
		{
			DrawWaitPVPPlay(MyGameState);
		}
		else if (State == ABSNGameState::LevelLoading)
		{
			DrawLoading();
		}
	}
}

void ABSNHUD::DrawWaitPlayerJoin(ABSNGameState *MyGameState)
{
	Canvas->SetDrawColor(FColor::White);
	FCanvasTextItem TipText(FVector2D::ZeroVector, FText::GetEmpty(), BigFont, FColor::White);

	FString Text = FString::Printf(TEXT("PVP Game Waiting: %d/%d"), MyGameState->PlayerNumeber, MyGameState->PlayerNumberNeed);
	TipText.Text = FText::FromString(Text);
	float SizeX = 0, SizeY = 0;
	Canvas->StrLen(BigFont, Text, SizeX, SizeY);
	Canvas->DrawItem(TipText, 0.5f*(Canvas->SizeX - SizeX), 0.5f*(Canvas->SizeY - SizeY));
}

void ABSNHUD::DrawWaitPVPPlay(ABSNGameState *MyGameState)
{
	int32 WaitTime = MyGameState->GetWaitTimeInt();
	if (WaitTime>0)
	{
		Canvas->SetDrawColor(FColor::White);
		FCanvasTextItem TipText(FVector2D::ZeroVector, FText::GetEmpty(), BigFont, FColor::White);

		FString Text = FString::Printf(TEXT("Match Waiting: %ds"), FMath::RoundToInt(WaitTime));
		TipText.Text = FText::FromString(Text);

		float SizeX = 0, SizeY = 0;
		Canvas->StrLen(BigFont, Text, SizeX, SizeY);
		Canvas->DrawItem(TipText, 0.5f*(Canvas->SizeX - SizeX), 0.5f*(Canvas->SizeY - SizeY));
	}
}

void ABSNHUD::DrawLoading()
{
	Canvas->SetDrawColor(FColor::White);
	FCanvasTextItem TipText(FVector2D::ZeroVector, FText::GetEmpty(), BigFont, FColor::White);

	FString Text = TEXT("Loading...");
	TipText.Text = FText::FromString(Text);

	float SizeX = 0, SizeY = 0;
	Canvas->StrLen(BigFont, Text, SizeX, SizeY);
	Canvas->DrawItem(TipText, 0.5f*(Canvas->SizeX - SizeX), 0.5f*(Canvas->SizeY - SizeY));
}





