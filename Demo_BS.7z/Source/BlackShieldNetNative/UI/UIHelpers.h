// Copyright 1998-2016 Epic Games, Inc. All Rights Reserved.

#pragma once

#include "SlateBasics.h"
#include "SlateExtras.h"

class BSNUIHelpers
{
public:
	/** gets the singleton. */
	static BSNUIHelpers& Get()
	{
		static BSNUIHelpers Singleton;
		return Singleton;
	}
	FText GetProfileOpenText() const;
	bool ProfileOpenedUI(const FUniqueNetId& Requestor, const FUniqueNetId& Requestee, const FOnProfileUIClosedDelegate* Delegate) const;
	FText GetProfileSwapText() const;
	bool ProfileSwapUI(const int ControllerIndex, bool bShowOnlineOnly, const FOnLoginUIClosedDelegate* Delegate) const;
};