
#include "BlackShieldNetNative.h"
#include "RespawnEffect.h"
#include "Player/BSNPlayerController.h"

ARespawnEffect::ARespawnEffect(const FObjectInitializer &ObjectInitializer)
	:Super(ObjectInitializer)
	,MyPC(NULL)
	,WaitTime(0)
{
	RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));

	TextRoot = CreateDefaultSubobject<USceneComponent>(TEXT("TextRoot"));
	TextRoot->SetupAttachment(RootComponent);

	TextKiller = CreateDefaultSubobject<UTextRenderComponent>(TEXT("Killer"));
	TextKiller->SetupAttachment(TextRoot);

	TextWait = CreateDefaultSubobject<UTextRenderComponent>(TEXT("Wait"));
	TextWait->SetupAttachment(TextRoot);
}

void ARespawnEffect::Start(ABSNPlayerController *InOwner, const FString &InKiller, float InWaitTime)
{
	WaitTime = FMath::CeilToInt(InWaitTime);

	if (TextKiller != NULL)
	{
		FString KillMsg = FString::Printf(TEXT("You were killed by %s"), *InKiller);
		TextKiller->SetText(FText::FromString(KillMsg));
	}

	if (TextWait != NULL)
	{
		FString WaitMsg = FString::Printf(TEXT("Waiting %d seconds to respawn.  "), WaitTime);
		TextWait->SetText(FText::FromString(WaitMsg));
	}

	if (WaitTime > 0)
	{
		GetWorldTimerManager().SetTimer(TimerHandle_Count, this, &ARespawnEffect::DefaultTimer, 1.0f, true);
	}

	MyPC = InOwner;
	SetOwner(MyPC);

	UpdateWait();
}

void ARespawnEffect::UpdateWait()
{
	if (TextWait != NULL)
	{
		FString WaitMsg = FString::Printf(TEXT("Waiting %d seconds to respawn.  "), WaitTime);
		TextWait->SetText(FText::FromString(WaitMsg));
	}
	
	if (WaitTime <= 0)
	{
		GetWorldTimerManager().ClearTimer(TimerHandle_Count);
		SetLifeSpan(0.2f);
	}
}

void ARespawnEffect::DefaultTimer()
{
	--WaitTime;
	UpdateWait();
}


