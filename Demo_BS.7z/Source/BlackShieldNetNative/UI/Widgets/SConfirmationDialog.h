#pragma once

#include "BlackShieldCommons.h"
#include "SlateBasics.h"

class SConfirmationDialog : public SCompoundWidget
{
public:
	TWeakObjectPtr<ULocalPlayer> PlayerOwner;
	FOnClicked		OnConfirm;
	FOnClicked		OnCancel;
	EDialogType		DialogType;

	SLATE_BEGIN_ARGS(SConfirmationDialog) {}
	
	SLATE_ARGUMENT(TWeakObjectPtr<ULocalPlayer>, PlayerOwner)
	SLATE_ARGUMENT(EDialogType, DialogType)

	SLATE_ARGUMENT(FText, MessageText)
	SLATE_ARGUMENT(FText, ConfirmText)
	SLATE_ARGUMENT(FText, CancelText)

	SLATE_ARGUMENT(FOnClicked, OnConfirmClicked)
	SLATE_ARGUMENT(FOnClicked, OnCancelClicked)

	SLATE_END_ARGS()

	void Construct(const FArguments &InArgs);

	virtual bool SupportsKeyboardFocus() const override;
	virtual FReply OnFocusReceived(const FGeometry& MyGeometry, const FFocusEvent& InFocusEvent) override;
	virtual FReply OnKeyDown(const FGeometry& MyGeometry, const FKeyEvent& KeyEvent) override;
private:
	FReply OnConfirmHandler();
	FReply ExecuteConfirm(const int32 UserIndex);
};


