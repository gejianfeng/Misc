#pragma once

#include "BlackShieldCommons.h"
#include "SlateBasics.h"
#include "SMenuWidget.h"

struct FScoreRankEntry
{
	int32	Rank;
	FString Name;
	int32	Kill;
	int32	Death;
};

class SScoreRank : public SCompoundWidget
{
public:
	SScoreRank();
	~SScoreRank();
	SLATE_BEGIN_ARGS(SScoreRank) {}
	SLATE_ARGUMENT(TWeakObjectPtr<class UGameViewportClient>, Viewport)
	SLATE_END_ARGS()
	void Construct(const FArguments& InArgs);
protected:
	virtual bool SupportsKeyboardFocus() const override { return false; }
	TSharedRef<ITableRow> MakeListViewWidget(TSharedPtr<FScoreRankEntry> Item, const TSharedRef<STableViewBase>& OwnerTable);
	FText GetTimeText() const { return TimeStatus; }
	void  UpdateRankList();
protected:
	TArray< TSharedPtr<FScoreRankEntry> > RankDataSource;
	TSharedPtr< SListView< TSharedPtr<FScoreRankEntry> > > RankListWidget;
	TSharedPtr< STextBlock > Time;
	FText TimeStatus;
	TWeakObjectPtr<class UGameViewportClient> Viewport;
};


