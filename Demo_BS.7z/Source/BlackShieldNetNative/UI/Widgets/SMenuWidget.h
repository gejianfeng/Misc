
#pragma once

#include "BlackShieldCommons.h"
#include "SlateBasics.h"
#include "SMenuItem.h"

class SMenuWidget : public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(SMenuWidget) 
		:_PlayerOwner(NULL)
		,_IsGameMenu(false)
	{}
	SLATE_ARGUMENT(TWeakObjectPtr<ULocalPlayer>, PlayerOwner)
	SLATE_ARGUMENT(bool, IsGameMenu)
	SLATE_END_ARGS()

	DECLARE_DELEGATE(FOnMenuHidden)
	DECLARE_DELEGATE(FOnToggleMenu)
	DECLARE_DELEGATE_OneParam(FOnMenuGoBack, MenuPtr)

	void Construct(const FArguments &InArgs);
	virtual void Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime) override;

	virtual FReply OnMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;
	virtual FReply OnKeyDown(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent) override;

	virtual bool SupportsKeyboardFocus() const override { return true;  }
	virtual FReply OnFocusReceived(const FGeometry& MyGeometry, const FFocusEvent& InFocusEvent) override;

	void SetupAnimations();
	void BuildLeftPanel(bool bGoingback);
	void BuildRightPanel();

	void EnterSubMenu();
	void MenuGoBack(bool bSilent = false);

	void ConfirmMenuItem();
	void ControllerFacebuttonLeftPressed();
	void ControllerDownInputPressed();
	void ControllerUpInputPressed();
	void ControllerFacebuttonDownPressed();

	void BuildAndShowMenu();
	void HideMenu();
	void UpdateArrows(TSharedPtr<FMenuItem> MenuItem);
	void ChangeOption(int32 MoveBy);
	int32 GetNextValidIndex(int32 MoveBy);
	void LockControls(bool bEnable);
	int32 GetOwnerUserIndex();
	int32 GetMenuLevel();
public:
	MenuPtr MainMenu;
	MenuPtr CurrentMenu;
	MenuPtr NextMenu;
	TArray<FMenuInfo> MenuHistory;
	FOnMenuHidden OnMenuHidden;
	FOnToggleMenu OnToggleMenu;
	FOnMenuGoBack OnGoBack;
	FText CurrentMenuTitle;
	FKey  ControllerHideMenuKey;
	bool  bConsoleVisible;
private:
	EVisibility GetSlateVisibility() const;
	FVector2D GetBottomScale() const;
	FLinearColor GetBottomColor() const;
	FLinearColor GetTopColor() const;
	FMargin GetMenuOffset() const;
	FMargin GetLeftMenuOffset() const;
	FMargin GetSubMenuOffset() const;

	FSlateColor GetHeaderColor() const;
	FReply ButtonClicked(int32 ButtonIndex);
	FText GetOptionText(TSharedPtr<FMenuItem> MenuItem) const;
	FText GetMenuTitle() const;
	FMargin GetProfileSwapOffset() const;
	bool IsProfileSwapActive() const;
	EVisibility GetProfileSwapVisibility() const;

	bool ProfileUISwap(const int ControllerIndex) const;
	void HandleProfileUISwapClosed(TSharedPtr<const FUniqueNetId> UniqueId, const int ControllerIndex);
	void FadeIn();
private:
	FCurveSequence					MenuWidgetAnimation;
	FCurveHandle					BottomScaleYCurve;
	FCurveHandle					TopColorCurve;
	FCurveHandle					BottomColorCurve;
	FCurveHandle					ButtonsPosXCurve;
	FCurveSequence					SubMenuWidgetAnimation;
	FCurveHandle					SubMenuScrollOutCurve;
	FCurveSequence					LeftMenuWidgetAnimation;
	FCurveHandle					LeftMenuScrollOutCurve;
	TWeakObjectPtr<class ULocalPlayer> PlayerOwner;
	FIntPoint						ScreenRes;
	float							OutlineWidth;
	float							MenuHeaderHeight;
	float							MenuHeaderWidth;
	float							MenuProfileWidth;
	int32							AnimNumber;
	int32							SelectedIndex;
	bool							bSubMenuChanging;
	bool							bLeftMenuChanging;
	bool							bGoingBack;
	bool							bMenuHiding;
	bool							bGameMenu;
	bool							bControlsLocked;
	MenuPtr							PendingLeftMenu;
	TSharedPtr<SVerticalBox>		LeftBox;
	TSharedPtr<SVerticalBox>		 RightBox;
	const struct FBSNMenuStyle		*MenuStyle;
};


namespace MenuHelper
{
	FORCEINLINE void EnsureValid(TSharedPtr<FMenuItem>& MenuItem)
	{
		if (!MenuItem.IsValid())
		{
			MenuItem = FMenuItem::CreateRoot();
		}
	}

	//Helper functions for creating menu items
	FORCEINLINE TSharedRef<FMenuItem> AddMenuItem(TSharedPtr<FMenuItem>& MenuItem, const FText& Text)
	{
		EnsureValid(MenuItem);
		TSharedPtr<FMenuItem> Item = MakeShareable(new FMenuItem(Text));
		MenuItem->SubMenu.Add(Item);
		return Item.ToSharedRef();
	}

	/** add standard item to menu with UObject delegate */
	template< class UserClass >
	FORCEINLINE TSharedRef<FMenuItem> AddMenuItem(TSharedPtr<FMenuItem>& MenuItem, const FText& Text, UserClass* inObj, typename FMenuItem::FOnConfirmMenuItem::TUObjectMethodDelegate< UserClass >::FMethodPtr inMethod)
	{
		EnsureValid(MenuItem);
		TSharedPtr<FMenuItem> Item = MakeShareable(new FMenuItem(Text));
		Item->OnConfirmMenuItem.BindUObject(inObj, inMethod);
		MenuItem->SubMenu.Add(Item);
		return Item.ToSharedRef();
	}

	/** add standard item to menu with TSharedPtr delegate */
	template< class UserClass >
	FORCEINLINE TSharedRef<FMenuItem> AddMenuItemSP(TSharedPtr<FMenuItem>& MenuItem, const FText& Text, UserClass* inObj, typename FMenuItem::FOnConfirmMenuItem::TSPMethodDelegate< UserClass >::FMethodPtr inMethod)
	{
		EnsureValid(MenuItem);
		TSharedPtr<FMenuItem> Item = MakeShareable(new FMenuItem(Text));
		Item->OnConfirmMenuItem.BindSP(inObj, inMethod);
		MenuItem->SubMenu.Add(Item);
		return Item.ToSharedRef();
	}


	FORCEINLINE TSharedRef<FMenuItem> AddMenuOption(TSharedPtr<FMenuItem>& MenuItem, const FText& Text, const TArray<FText>& OptionsList)
	{
		EnsureValid(MenuItem);
		TSharedPtr<FMenuItem> Item = MakeShareable(new FMenuItem(Text, OptionsList));
		MenuItem->SubMenu.Add(Item);
		return MenuItem->SubMenu.Last().ToSharedRef();
	}

	/** add multi-choice item to menu with UObject delegate */
	template< class UserClass >
	FORCEINLINE TSharedRef<FMenuItem> AddMenuOption(TSharedPtr<FMenuItem>& MenuItem, const FText& Text, const TArray<FText>& OptionsList, UserClass* inObj, typename FMenuItem::FOnOptionChanged::TUObjectMethodDelegate< UserClass >::FMethodPtr inMethod)
	{
		EnsureValid(MenuItem);
		TSharedPtr<FMenuItem> Item = MakeShareable(new FMenuItem(Text, OptionsList));
		Item->OnOptionChanged.BindUObject(inObj, inMethod);
		MenuItem->SubMenu.Add(Item);
		return MenuItem->SubMenu.Last().ToSharedRef();
	}

	/** add multi-choice item to menu with TSharedPtr delegate */
	template< class UserClass >
	FORCEINLINE TSharedRef<FMenuItem> AddMenuOptionSP(TSharedPtr<FMenuItem>& MenuItem, const FText& Text, const TArray<FText>& OptionsList, UserClass* inObj, typename FMenuItem::FOnOptionChanged::TSPMethodDelegate< UserClass >::FMethodPtr inMethod)
	{
		EnsureValid(MenuItem);
		TSharedPtr<FMenuItem> Item = MakeShareable(new FMenuItem(Text, OptionsList));
		Item->OnOptionChanged.BindSP(inObj, inMethod);
		MenuItem->SubMenu.Add(Item);
		return MenuItem->SubMenu.Last().ToSharedRef();
	}


	FORCEINLINE TSharedRef<FMenuItem> AddExistingMenuItem(TSharedPtr<FMenuItem>& MenuItem, TSharedRef<FMenuItem> SubMenuItem)
	{
		EnsureValid(MenuItem);
		MenuItem->SubMenu.Add(SubMenuItem);
		return MenuItem->SubMenu.Last().ToSharedRef();
	}


	FORCEINLINE TSharedRef<FMenuItem> AddCustomMenuItem(TSharedPtr<FMenuItem>& MenuItem, TSharedPtr<SWidget> CustomWidget)
	{
		EnsureValid(MenuItem);
		MenuItem->SubMenu.Add(MakeShareable(new FMenuItem(CustomWidget)));
		return MenuItem->SubMenu.Last().ToSharedRef();
	}

	FORCEINLINE void ClearSubMenu(TSharedPtr<FMenuItem>& MenuItem)
	{
		EnsureValid(MenuItem);
		MenuItem->SubMenu.Empty();
	}

	template< class UserClass >
	FORCEINLINE void PlaySoundAndCall(UWorld* World, const FSlateSound& Sound, int32 UserIndex, UserClass* inObj, typename FMenuItem::FOnConfirmMenuItem::TSPMethodDelegate< UserClass >::FMethodPtr inMethod)
	{
		FSlateApplication::Get().PlaySound(Sound, UserIndex);
		if (World)
		{
			const float SoundDuration = FMath::Max(FSlateApplication::Get().GetSoundDuration(Sound), 0.1f);
			FTimerHandle DummyHandle;
			World->GetTimerManager().SetTimer(DummyHandle, FTimerDelegate::CreateSP(inObj, inMethod), SoundDuration, false);
		}
		else
		{
			FTimerDelegate D = FTimerDelegate::CreateSP(inObj, inMethod);
			D.ExecuteIfBound();
		}
	}
}


