
#include "BlackShieldNetNative.h"
#include "SMenuItem.h"
#include "UI/Styles/BSNStyle.h"

void FMenuItem::SetText(FText UpdatedText)
{
	Text = MoveTemp(UpdatedText);
	if (Widget.IsValid())
	{
		Widget->UpdateItemText(Text);
	}
}

void SMenuItem::Construct(const FArguments &InArgs)
{
	ItemStyle = &FBSNStyle::Get().GetWidgetStyle<FBSNMenuItemStyle>("DefaultMenuItemStyle");
	
	PlayerOwner = InArgs._PlayerOwner;
	Text = InArgs._Text;
	OptionText = InArgs._Text;
	OnClicked = InArgs._OnClicked;
	OnArrowPressed = InArgs._OnArrowPressed;
	bIsMultichoice = InArgs._bIsMultichoice;
	bIsActiveMenuItem = false;
	LeftArrowVisible = EVisibility::Collapsed;
	RightArrowVisible = EVisibility::Collapsed;
	InactiveTextAlpha = InArgs._InactiveTextAlpha.Get(1.0f);

	const float ArrowMargin = 3.0f;
	ItemMargin = 10.0f;
	TextColor = FLinearColor(FColor(155,164,182));

	ChildSlot
	.VAlign(VAlign_Fill)
	.HAlign(HAlign_Fill)
	[
		SNew(SOverlay)
		+SOverlay::Slot()
		.HAlign(HAlign_Fill)
		.VAlign(VAlign_Fill)
		[
			SNew(SBox)
			.WidthOverride(374.0f)
			.HeightOverride(23.0f)
			[
				SNew(SImage)
				.ColorAndOpacity(this, &SMenuItem::GetButtonBgColor)
				.Image(&ItemStyle->BackgroundBrush)
			]
		]
		+ SOverlay::Slot()
		.HAlign(bIsMultichoice ? HAlign_Left:HAlign_Center)
		.VAlign(VAlign_Center)
		.Padding(FMargin(ItemMargin,0,0,0))
		[
			SAssignNew(TextWidget, STextBlock)
			.TextStyle(FBSNStyle::Get(), "BSNGame.MenuTextStyle")
			.ColorAndOpacity(this,&SMenuItem::GetButtonTextColor)
			.ShadowColorAndOpacity(this,&SMenuItem::GetButtonTextShadowColor)
			.Text(Text)
		]
		+SOverlay::Slot()
		.HAlign(HAlign_Right)
		.VAlign(VAlign_Center)
		[
			SNew(SHorizontalBox)
			+SHorizontalBox::Slot()
			.AutoWidth()
			[
				SNew(SBorder)
				.BorderImage(FCoreStyle::Get().GetBrush("NoBorder"))
				.Padding(FMargin(0,0,ArrowMargin,0))
				.Visibility(this, &SMenuItem::GetLeftArrowVisibility)
				.OnMouseButtonDown(this,&SMenuItem::OnLeftArrowDown)
				[
					SNew(SOverlay)
					+SOverlay::Slot()
					.HAlign(HAlign_Center)
					.VAlign(VAlign_Center)
					[
						SNew(SImage)
						.Image(&ItemStyle->LeftArrowImage)
					]
				]
			]
			+ SHorizontalBox::Slot()
			.AutoWidth()
			.Padding(TAttribute<FMargin>(this, &SMenuItem::GetOptionPadding))
			[
				SNew(STextBlock)
				.TextStyle(FBSNStyle::Get(), "BSNGame.MenuTextStyle")
				.Visibility(bIsMultichoice ? EVisibility::Visible : EVisibility::Collapsed)
				.ColorAndOpacity(this, &SMenuItem::GetButtonTextColor)
				.ShadowColorAndOpacity(this, &SMenuItem::GetButtonTextShadowColor)
				.Text(OptionText)
			]
			+SHorizontalBox::Slot()
			.AutoWidth()
			[
				SNew(SBorder)
				.BorderImage(FCoreStyle::Get().GetBrush("NoBorder"))
				.Padding(FMargin(ArrowMargin,0,ItemMargin,0))
				.Visibility(this, &SMenuItem::GetRightArrowVisibility)
				.OnMouseButtonDown(this,&SMenuItem::OnRightArrowDown)
				[
					SNew(SOverlay)
					+SOverlay::Slot()
					.HAlign(HAlign_Center)
					.VAlign(VAlign_Center)
					[
						SNew(SImage)
						.Image(&ItemStyle->RightArrowImage)
					]
				]
			]
		]
	
	];
}

FReply SMenuItem::OnMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	if (OnClicked.IsBound() == true)
	{
		return OnClicked.Execute();
	}
	return FReply::Handled();
}

FReply SMenuItem::OnMouseButtonUp(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	return FReply::Handled();
}

void SMenuItem::SetMenuItemActive(bool bIsMenuItemActive)
{
	this->bIsActiveMenuItem = bIsMenuItemActive;
}

void SMenuItem::UpdateItemText(const FText &UpdateText)
{
	Text = UpdateText;
	if (TextWidget.IsValid())
	{
		TextWidget->SetText(Text);
	}
}

FSlateColor	SMenuItem::GetButtonBgColor() const
{
	const float MinAlpha = 0.1f;
	const float MaxAlpha = 1.0f;
	const float AnimSpeedModifier = 1.5f;

	float AnimPrecent = 0.f;
	ULocalPlayer *const Player = PlayerOwner.Get();
	if (Player)
	{
		UWorld *const World = Player->GetWorld();
		if (World != nullptr)
		{
			const float GameTime = World->GetRealTimeSeconds();
			AnimPrecent = FMath::Abs(FMath::Sin(GameTime*AnimSpeedModifier));
		}
	}

	const float BgAlpha = bIsActiveMenuItem ? FMath::Lerp(MinAlpha, MaxAlpha, AnimPrecent) : 0;
	return FLinearColor(1.0f, 1.0f, 1.0f, BgAlpha);
}

FSlateColor	SMenuItem::GetButtonTextColor() const
{
	FLinearColor Result;
	if (bIsActiveMenuItem)
	{
		Result = TextColor;
	}
	else
	{
		Result = FLinearColor(TextColor.R, TextColor.G, TextColor.B, InactiveTextAlpha);
	}
	return Result;
}

FLinearColor SMenuItem::GetButtonTextShadowColor() const
{
	FLinearColor Result;
	if (bIsActiveMenuItem)
	{
		Result = FLinearColor(0, 0, 0, 1);
	}
	else
	{
		Result = FLinearColor(0, 0, 0, InactiveTextAlpha);
	}
	return Result;
}

EVisibility	SMenuItem::GetLeftArrowVisibility() const
{
	return LeftArrowVisible;
}

EVisibility	SMenuItem::GetRightArrowVisibility() const
{
	return RightArrowVisible;
}

FMargin	SMenuItem::GetOptionPadding() const
{
	return RightArrowVisible == EVisibility::Visible ? FMargin(0) : FMargin(0, 0, ItemMargin, 0);
}

FReply	SMenuItem::OnRightArrowDown(const FGeometry &MyGeometry, const FPointerEvent &MouseEvent)
{
	FReply Result = FReply::Unhandled();
	
	const int32 MoveRight = 1;
	if (OnArrowPressed.IsBound() && bIsActiveMenuItem)
	{
		OnArrowPressed.Execute(MoveRight);
		Result = FReply::Handled();
	}

	return Result;
}

FReply	SMenuItem::OnLeftArrowDown(const FGeometry &MyGeometry, const FPointerEvent &MouseEvent)
{
	FReply Result = FReply::Unhandled();

	const int32 MoveLeft = -1;
	if (OnArrowPressed.IsBound() && bIsActiveMenuItem)
	{
		OnArrowPressed.Execute(MoveLeft);
		Result = FReply::Handled();
	}

	return Result;
}


