#pragma once

#include "SlateBasics.h"
#include "SlateExtras.h"

enum class EMenuItemType :uint8
{
	Root,
	Standard,
	MultiChoice,
	CustomWidget,
};

typedef TArray< TSharedPtr<class FMenuItem> > MenuPtr;

class FMenuInfo
{
public:
	MenuPtr Menu;
	int32 SelectedIndex;
	FText MenuTitle;
	FMenuInfo(MenuPtr _Menu, int32 _SelectedIndex, FText _MenuTitle)
	{
		Menu = _Menu;
		SelectedIndex = _SelectedIndex;
		MenuTitle = MoveTemp(_MenuTitle);
	}
};

class FMenuItem :public TSharedFromThis<FMenuItem>
{
public:
	DECLARE_DELEGATE(FOnConfirmMenuItem);
	DECLARE_DELEGATE(FOnControllerFacebuttonLeftPressed);
	DECLARE_DELEGATE(FOnControllerDownInputPressed);
	DECLARE_DELEGATE(FOnControllerUpInputPressed);
	DECLARE_DELEGATE(FOnOnControllerFacebuttonDownPressed);
	DECLARE_DELEGATE_TwoParams(FOnOptionChanged, TSharedPtr<FMenuItem>, int32);
	
	FOnConfirmMenuItem OnConfirmMenuItem;
	FOnOptionChanged OnOptionChanged;
	FOnControllerFacebuttonLeftPressed OnControllerFacebuttonLeftPressed;
	FOnControllerDownInputPressed OnControllerDownInputPressed;
	FOnControllerUpInputPressed OnControllerUpInputPressed;
	FOnOnControllerFacebuttonDownPressed OnControllerFacebuttonDownPressed;

	EMenuItemType MenuItemType;
	bool bVisible;
	TArray<TSharedPtr<FMenuItem>> SubMenu;
	TSharedPtr<class SMenuItem> Widget;

	TSharedPtr<SWidget> CustomWidget;
	TArray<FText> MultiChoice;

	int32 MinMultiChoiceIndex;
	int32 MaxMultiChoiceIndex;
	int32 SelectedMultiChoice;

	FMenuItem(FText _text)
	{
		bVisible = true;
		Text = MoveTemp(_text);
		MenuItemType = EMenuItemType::Standard;
	}

	FMenuItem(TSharedPtr<SWidget> _Widget)
	{
		bVisible = true;
		MenuItemType = EMenuItemType::CustomWidget;
		CustomWidget = _Widget;
	}

	FMenuItem(FText _text, TArray<FText> _choices, int32 DefaultIndex = 0)
	{
		bVisible = true;
		Text = MoveTemp(_text);
		MenuItemType = EMenuItemType::MultiChoice;
		MultiChoice = MoveTemp(_choices);
		MinMultiChoiceIndex = MaxMultiChoiceIndex = -1;
		SelectedMultiChoice = DefaultIndex;
	}

	const FText &GetText() const
	{
		return Text;
	}

	void SetText(FText UpdatedText);

	static TSharedRef<FMenuItem> CreateRoot()
	{
		return MakeShareable(new FMenuItem());
	}
private:

	FMenuItem()
	{
		bVisible = false;
		MenuItemType = EMenuItemType::Root;
	}

	FText Text;
};

class SMenuItem :public SCompoundWidget
{
public:
	DECLARE_DELEGATE_OneParam(FOnArrowPressed, int);

	SLATE_BEGIN_ARGS(SMenuItem) {}

	SLATE_ARGUMENT(TWeakObjectPtr<ULocalPlayer>,PlayerOwner)
	SLATE_EVENT(FOnClicked, OnClicked)
	SLATE_EVENT(FOnArrowPressed, OnArrowPressed)
	SLATE_ATTRIBUTE(FText, Text)
	SLATE_ARGUMENT(bool, bIsMultichoice)
	SLATE_ATTRIBUTE(FText, OptionText)
	SLATE_ARGUMENT(TOptional<float>, InactiveTextAlpha)

	SLATE_END_ARGS()

	void Construct(const FArguments &InArgs);
	virtual bool SupportsKeyboardFocus() const override { return true; }
	virtual FReply OnMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;
	virtual FReply OnMouseButtonUp(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;
	
	void SetMenuItemActive(bool bIsMenuItemActive);
	void UpdateItemText(const FText &UpdateText);
	
	EVisibility		LeftArrowVisible;
	EVisibility		RightArrowVisible;
protected:
	FSlateColor		GetButtonBgColor() const;
	FSlateColor		GetButtonTextColor() const;
	FLinearColor	GetButtonTextShadowColor() const;
	EVisibility		GetLeftArrowVisibility() const;
	EVisibility		GetRightArrowVisibility() const;
	FMargin			GetOptionPadding() const;
	FReply			OnRightArrowDown(const FGeometry &MyGeometry, const FPointerEvent &MouseEvent);
	FReply			OnLeftArrowDown(const FGeometry &MyGeometry, const FPointerEvent &MouseEvent);
protected:
	FOnClicked		OnClicked;
	FOnArrowPressed	OnArrowPressed;
protected:
	TAttribute<FText>		Text;
	TAttribute<FText>		OptionText;
	TSharedPtr<STextBlock>	TextWidget;
	FLinearColor			TextColor;
	float					ItemMargin;
	float					InactiveTextAlpha;
	bool					bIsActiveMenuItem;
	bool					bIsMultichoice;
	TWeakObjectPtr<class ULocalPlayer>  PlayerOwner;
	const struct FBSNMenuItemStyle	   *ItemStyle;
};

