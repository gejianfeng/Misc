
#include "BlackShieldNetNative.h"
#include "SServerList.h"
#include "SHeaderRow.h"
#include "BlackShieldGameInstance.h"
#include "Online/BSNGameSession.h"

#define LOCTEXT_NAMESPACE "BSNGame.HUD.Menu"

SBSNServerList::SBSNServerList()
	:MainMenu(NULL)
{
}

SBSNServerList::~SBSNServerList()
{
}

void SBSNServerList::Construct(const FArguments& InArgs)
{
	PlayerOwner = InArgs._PlayerOwner;
	MainMenu = InArgs._MainMenu;
	MapFilterName = "Any";
	bSearchingForServers = false;
	StatusText = FText::GetEmpty();
	BoxWidth = 125;

	{
		TSharedPtr<FServerEntry> NewServerEntry = MakeShareable(new FServerEntry());
		NewServerEntry->GameType = "FreeForAll";
		NewServerEntry->CurrentPlayers = "0";
		NewServerEntry->MaxPlayers = "10";
		NewServerEntry->Ping = "127.0.0.1";
		NewServerEntry->SearchResultsIndex = 1;
		NewServerEntry->ServerName = "DelicatedServer";
		NewServerEntry->MapName = "TestMap";
		ServerList.Add(NewServerEntry);
	}

	ChildSlot
	.VAlign(VAlign_Fill)
	.HAlign(HAlign_Fill)
	[
		SNew(SVerticalBox)
		+ SVerticalBox::Slot()
		.AutoHeight()
		[
			SNew(SBox)
			.WidthOverride(600)
			.HeightOverride(300)
			[
				SAssignNew(ServerListWidget, SListView<TSharedPtr<FServerEntry>>)
				.ItemHeight(20)
				.ListItemsSource(&ServerList)
				.SelectionMode(ESelectionMode::Single)
				.OnGenerateRow(this, &SBSNServerList::MakeListViewWidget)
				.OnSelectionChanged(this, &SBSNServerList::EntrySelectionChanged)
				.OnMouseButtonDoubleClick(this, &SBSNServerList::OnListItemDoubleClicked)
				.HeaderRow(
				SNew(SHeaderRow)
				+ SHeaderRow::Column("ServerName").FixedWidth(BoxWidth * 2).DefaultLabel(NSLOCTEXT("ServerList", "ServerNameColumn", "Server Name"))
				+ SHeaderRow::Column("GameType").DefaultLabel(NSLOCTEXT("ServerList", "GameTypeColumn", "Game Type"))
				+ SHeaderRow::Column("Map").DefaultLabel(NSLOCTEXT("ServerList", "MapNameColumn", "Map"))
				+ SHeaderRow::Column("Players").DefaultLabel(NSLOCTEXT("ServerList", "PlayersColumn", "Players"))
				+ SHeaderRow::Column("Ping").DefaultLabel(NSLOCTEXT("ServerList", "NetworkPingColumn", "Ping")))
			]
		]
		+ SVerticalBox::Slot()
		.AutoHeight()
		[
			SNew(SOverlay)
			+ SOverlay::Slot()
			.VAlign(VAlign_Center)
			.HAlign(HAlign_Center)
			[
				SNew(STextBlock)
				.Text(this, &SBSNServerList::GetBottomText)
				.TextStyle(FBSNStyle::Get(), "BSNGame.MenuServerListTextStyle")
			]
		]
	];
}

void SBSNServerList::UpdateSearchStatus()
{
 	bool bFinishSearch = true;

	TSharedPtr<FServerEntry> NewServerEntry = MakeShareable(new FServerEntry());
	NewServerEntry->GameType = "FreeForAll";
	NewServerEntry->CurrentPlayers = "0";
	NewServerEntry->MaxPlayers = "10";
	NewServerEntry->Ping = "127.0.0.1";
	NewServerEntry->SearchResultsIndex = 1;
	NewServerEntry->ServerName = "DelicatedServer";
	NewServerEntry->MapName = "TestMap";
	
	ServerList.Add(NewServerEntry);

	if (bFinishSearch)
	{
		OnServerSearchFinished();
	}
}

FText SBSNServerList::GetBottomText() const
{
	return StatusText;
}

void SBSNServerList::Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime)
{
	SCompoundWidget::Tick(AllottedGeometry, InCurrentTime, InDeltaTime);

	if (bSearchingForServers)
	{
		UpdateSearchStatus();
	}
}

void SBSNServerList::BeginServerSearch(const FString& InMapFilterName)
{
	MapFilterName = InMapFilterName;
	bSearchingForServers = true;
	ServerList.Empty();
}

void SBSNServerList::OnServerSearchFinished()
{
	bSearchingForServers = false;
	UpdateServerList();
}

void SBSNServerList::UpdateServerList()
{
	if (MapFilterName != "Any")
	{
		for (int32 i = 0; i < ServerList.Num(); ++i)
		{
			/** Only filter maps if a specific map is specified */
			if (ServerList[i]->MapName != MapFilterName)
			{
				ServerList.RemoveAt(i);
			}
		}
	}

	int32 SelectedItemIndex = ServerList.IndexOfByKey(SelectedItem);
	ServerListWidget->RequestListRefresh();

	if (ServerList.Num() > 0)
	{
		ServerListWidget->UpdateSelectionSet();
		ServerListWidget->SetSelection(ServerList[SelectedItemIndex > -1 ? SelectedItemIndex : 0], ESelectInfo::OnNavigation);
	}

}

void SBSNServerList::ConnectToServer()
{
	if (SelectedItem.IsValid())
	{
		if (GEngine && GEngine->GameViewport)
		{
			GEngine->GameViewport->RemoveAllViewportWidgets();
		}

		UBlackShieldGameInstance* const GI = Cast<UBlackShieldGameInstance>(PlayerOwner->GetGameInstance());
		if (GI!=NULL)
		{
			FURL URL;
			URL.Map = SelectedItem->MapName;
			URL.Host = SelectedItem->Ping;
			GI->TravelToServer(URL);
		}
	}
}

void SBSNServerList::OnFocusLost(const FFocusEvent& InFocusEvent)
{
	if (InFocusEvent.GetCause() != EFocusCause::SetDirectly)
	{
		FSlateApplication::Get().SetKeyboardFocus(SharedThis(this));
	}
}

FReply SBSNServerList::OnFocusReceived(const FGeometry& MyGeometry, const FFocusEvent& InFocusEvent)
{
	return FReply::Handled().SetUserFocus(ServerListWidget.ToSharedRef(), EFocusCause::SetDirectly).SetUserFocus(SharedThis(this), EFocusCause::SetDirectly, true);
}

void SBSNServerList::EntrySelectionChanged(TSharedPtr<FServerEntry> InItem, ESelectInfo::Type SelectInfo)
{
	SelectedItem = InItem;
}

void SBSNServerList::OnListItemDoubleClicked(TSharedPtr<FServerEntry> InItem)
{
	SelectedItem = InItem;
	ConnectToServer();
	FSlateApplication::Get().SetKeyboardFocus(SharedThis(this));
}

void SBSNServerList::MoveSelection(int32 MoveBy)
{
	int32 SelectedItemIndex = ServerList.IndexOfByKey(SelectedItem);

	if (SelectedItemIndex + MoveBy > -1 && SelectedItemIndex + MoveBy < ServerList.Num())
	{
		ServerListWidget->SetSelection(ServerList[SelectedItemIndex + MoveBy]);
	}
}

FReply SBSNServerList::OnKeyDown(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent)
{
	if (bSearchingForServers) // lock input
	{
		return FReply::Handled();
	}

	FReply Result = FReply::Unhandled();
	const FKey Key = InKeyEvent.GetKey();

	if (Key == EKeys::Up || Key == EKeys::Gamepad_DPad_Up || Key == EKeys::Gamepad_LeftStick_Up)
	{
		MoveSelection(-1);
		Result = FReply::Handled();
	}
	else if (Key == EKeys::Down || Key == EKeys::Gamepad_DPad_Down || Key == EKeys::Gamepad_LeftStick_Down)
	{
		MoveSelection(1);
		Result = FReply::Handled();
	}
	else if (Key == EKeys::Enter || Key == EKeys::Gamepad_FaceButton_Bottom)
	{
		ConnectToServer();
		Result = FReply::Handled();
		FSlateApplication::Get().SetKeyboardFocus(SharedThis(this));
	}
	//hit space bar to search for servers again / refresh the list, only when not searching already
	else if (Key == EKeys::SpaceBar || Key == EKeys::Gamepad_FaceButton_Left)
	{
		BeginServerSearch(MapFilterName);
	}
	else if (Key == EKeys::Escape)
	{
		if (MainMenu!=NULL)
		{
			GEngine->GameViewport->RemoveAllViewportWidgets();
			MainMenu->AddMenuToGameViewport(EFocusCause::SetDirectly);
		}
	}
	return Result;
}

TSharedRef<ITableRow> SBSNServerList::MakeListViewWidget(TSharedPtr<FServerEntry> Item, const TSharedRef<STableViewBase>& OwnerTable)
{
	class SServerEntryWidget : public SMultiColumnTableRow<TSharedPtr<FServerEntry>>
	{
	public:
		SLATE_BEGIN_ARGS(SServerEntryWidget) {}
		SLATE_END_ARGS()

		void Construct(const FArguments& InArgs, const TSharedRef<STableViewBase>& InOwnerTable, TSharedPtr<FServerEntry> InItem)
		{
			Item = InItem;
			SMultiColumnTableRow< TSharedPtr<FServerEntry> >::Construct(FSuperRowType::FArguments(), InOwnerTable);
		}

		TSharedRef<SWidget> GenerateWidgetForColumn(const FName& ColumnName)
		{
			FText ItemText = FText::GetEmpty();
			if (ColumnName == "ServerName")
			{
				ItemText = FText::FromString(Item->ServerName + "'s Server");
			}
			else if (ColumnName == "GameType")
			{
				ItemText = FText::FromString(Item->GameType);
			}
			else if (ColumnName == "Map")
			{
				ItemText = FText::FromString(Item->MapName);
			}
			else if (ColumnName == "Players")
			{
				ItemText = FText::Format(FText::FromString("{0}/{1}"), FText::FromString(Item->CurrentPlayers), FText::FromString(Item->MaxPlayers));
			}
			else if (ColumnName == "Ping")
			{
				ItemText = FText::FromString(Item->Ping);
			}
			return SNew(STextBlock)
				.Text(ItemText)
				.TextStyle(FBSNStyle::Get(), "BSNGame.MenuServerListTextStyle");
		}
		TSharedPtr<FServerEntry> Item;
	};
	return SNew(SServerEntryWidget, OwnerTable, Item);
}

#undef LOCTEXT_NAMESPACE

