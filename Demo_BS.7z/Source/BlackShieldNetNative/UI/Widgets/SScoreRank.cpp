
#include "BlackShieldNetNative.h"
#include "SScoreRank.h"
#include "SHeaderRow.h"
#include "UI/Styles/BSNStyle.h"
#include "Player/BSNPlayerController.h"
#include "Game/BSNPlayerState.h"

#define LOCTEXT_NAMESPACE "BSNGame.HUD.SScoreRank"

SScoreRank::SScoreRank()
{
}

SScoreRank::~SScoreRank()
{
}

void SScoreRank::Construct(const FArguments& InArgs)
{
	Viewport = InArgs._Viewport;

	UpdateRankList();

	TimeStatus = FText::FromString(("00:00"));

	int32 BoxWidth = 50;
	ChildSlot
	.VAlign(VAlign_Fill)
	.HAlign(HAlign_Center)
	[
		SNew(SVerticalBox)
		+SVerticalBox::Slot()
		.AutoHeight()
		[
			SNew(SOverlay)
			+ SOverlay::Slot()
			.VAlign(VAlign_Center)
			.HAlign(HAlign_Center)
			[
				SNew(STextBlock)
				.Text(this, &SScoreRank::GetTimeText)
				.TextStyle(FBSNStyle::Get(), "BSNGame.MenuHeaderTextStyle")
			]
		]
		+SVerticalBox::Slot()
		.AutoHeight()
		[
			SNew(SBox)
			.WidthOverride(900)
			.HeightOverride(500)
			[
				SAssignNew(RankListWidget, SListView< TSharedPtr<FScoreRankEntry> >)
				.ItemHeight(50)
				.ListItemsSource(&RankDataSource)
				.SelectionMode(ESelectionMode::Single)
				.OnGenerateRow(this, &SScoreRank::MakeListViewWidget)
				.HeaderRow(
					SNew(SHeaderRow)
					+ SHeaderRow::Column("Rank").FixedWidth(BoxWidth * 2).DefaultLabel(NSLOCTEXT("SScoreRank", "RankNameColumn", "Rank"))
					+ SHeaderRow::Column("Name").DefaultLabel(NSLOCTEXT("SScoreRank", "RankNameColumn", "Name"))
					+ SHeaderRow::Column("Kill").FixedWidth(BoxWidth * 2).DefaultLabel(NSLOCTEXT("SScoreRank", "RankNameColumn", "Kill"))
					+ SHeaderRow::Column("Death").FixedWidth(BoxWidth * 2).DefaultLabel(NSLOCTEXT("SScoreRank", "RankNameColumn", "Death"))
				)
			]
		]
	];
}

TSharedRef<ITableRow> SScoreRank::MakeListViewWidget(TSharedPtr<FScoreRankEntry> Item, const TSharedRef<STableViewBase>& OwnerTable)
{
	class SScoreRankEntryWidget :public SMultiColumnTableRow<TSharedPtr<FScoreRankEntry>>
	{
	public:
		void Construct(const FArguments& InArgs, const TSharedRef<STableViewBase>& InOwnerTable, TSharedPtr<FScoreRankEntry> InItem)
		{
			Item = InItem;
			SMultiColumnTableRow<TSharedPtr<FScoreRankEntry>>::Construct(FSuperRowType::FArguments(), InOwnerTable);
		}
		TSharedRef<SWidget> GenerateWidgetForColumn(const FName& ColumnName)
		{
			FText ItemText = FText::GetEmpty();
			if (ColumnName == "Rank")
			{
				ItemText = FText::FromString(FString::FromInt(Item->Rank));
			}
			else if (ColumnName == "Name")
			{
				ItemText = FText::FromString(Item->Name);
			}
			else if (ColumnName == "Kill")
			{
				ItemText = FText::FromString(FString::FromInt(Item->Kill));
			}
			else if (ColumnName == "Death")
			{
				ItemText = FText::FromString(FString::FromInt(Item->Death));
			}
			return	 SNew(STextBlock)
					.Text(ItemText)
					.TextStyle(FBSNStyle::Get(), "BSNGame.ScoreboardListTextStyle");
		}
	protected:
		TSharedPtr<FScoreRankEntry> Item;
	};

	return SNew(SScoreRankEntryWidget, OwnerTable, Item);
}

void SScoreRank::UpdateRankList()
{
	RankDataSource.Empty();

	if (Viewport.IsValid())
	{
		UWorld *MyWorld = Viewport->GetWorld();
		for (FConstPlayerControllerIterator It(MyWorld->GetPlayerControllerIterator()); It; ++It)
		{
			APlayerController *PC = *It;
			ABSNPlayerState *PlayerState = Cast<ABSNPlayerState>(PC->PlayerState);
			if (PlayerState != NULL)
			{
				FScoreRankEntry *Entry = new FScoreRankEntry;
				Entry->Name = PlayerState->PlayerName;
				Entry->Kill = PlayerState->GetKillCount();
				Entry->Death = PlayerState->GetDeathCount();
				Entry->Rank = RankDataSource.Num() + 1;
				RankDataSource.Add(MakeShareable(Entry));
			}
		}
	}
}

#undef LOCTEXT_NAMESPACE

