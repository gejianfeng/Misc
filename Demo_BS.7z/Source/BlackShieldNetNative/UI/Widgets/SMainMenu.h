#pragma once

#include "BlackShieldCommons.h"
#include "SlateBasics.h"
#include "SMenuWidget.h"
#include "BlackShieldGameInstance.h"

class FBSNMainMenu :public TSharedFromThis<FBSNMainMenu>
{
public:
	enum class EMap
	{
		ESancturary,
		EHighRise,
		EMax,
	};
	
	enum class EMatchType
	{
		Custom,
		Quick,
	};

	virtual ~FBSNMainMenu();
	void Construct(TWeakObjectPtr<class UBlackShieldGameInstance> _GameInstance, TWeakObjectPtr<ULocalPlayer> _PlayerOwner);
	void AddMenuToGameViewport(EFocusCause FocusCause = EFocusCause::SetDirectly);
	void RemoveMenuFromGameViewport();

	ULocalPlayer *GetPlayerOwner() const;
	int32 GetPlayerOwnerControllerId() const;
protected:
	void OnMenuHidden();

	void OnUIHostFreeForAll();
	void OnUIHostTeamDeathMatch();
	void ShowServerList(EMatchType InType);

	FReply OnConfirm();
	void OnUIQuit();
	void Quit();

	void LockAndHideMenu();
	FReply OnConfirmGeneric();
protected:
	TWeakObjectPtr<UBlackShieldGameInstance> GameInstance;
	TWeakObjectPtr<ULocalPlayer> PlayerOwner;

	TSharedPtr<class SMenuWidget> MenuWidget;
	TSharedPtr<class SWeakWidget> MenuWidgetContainer;

	TSharedPtr<class SBSNServerList> ServerListWidget;
	EMatchType MatchType;

	FDelegateHandle OnMatchmakingCompleteDelegateHandle;
	FDelegateHandle OnCancelMatchmakingCompleteDelegateHandle;
};

