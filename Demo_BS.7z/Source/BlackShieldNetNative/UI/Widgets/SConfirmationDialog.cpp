
#include "BlackShieldNetNative.h"
#include "SConfirmationDialog.h"
#include "BlackShieldGameInstance.h"
#include "UI/Styles/BSNMenuItemWidgetStyle.h"
#include "UI/Styles/BSNStyle.h"

void SConfirmationDialog::Construct(const FArguments &InArgs)
{
	PlayerOwner = InArgs._PlayerOwner;
	DialogType = InArgs._DialogType;

	OnConfirm = InArgs._OnConfirmClicked;
	OnCancel = InArgs._OnCancelClicked;

	const FBSNMenuItemStyle *ItemStyle = &FBSNStyle::Get().GetWidgetStyle<FBSNMenuItemStyle>("DefaultMenuItemStyle");
	const FButtonStyle *ButtonStyle = &FBSNStyle::Get().GetWidgetStyle<FButtonStyle>("DefaultButtonStyle");
	
	FLinearColor MenuTitleTextColor = FLinearColor(FColor(155, 164, 182));
	ChildSlot
	.VAlign(VAlign_Center)
	.HAlign(HAlign_Center)
	[
		SNew(SVerticalBox)
		+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(20.0f)
		.VAlign(VAlign_Center)
		.HAlign(HAlign_Center)
		[
			SNew(SBorder)
			.Padding(50.0f)
			.VAlign(VAlign_Center)
			.HAlign(HAlign_Center)
			.BorderImage(&ItemStyle->BackgroundBrush)
			.BorderBackgroundColor(FLinearColor(1.0f, 1.0f, 1.0f, 1.0f))
			[
				SNew(STextBlock)
				.TextStyle(FBSNStyle::Get(), "BSNGame.MenuHeaderTextStyle")
				.ColorAndOpacity(MenuTitleTextColor)
				.Text(InArgs._MessageText)
				.WrapTextAt(500.0f)
			]
		]

		+ SVerticalBox::Slot()
		.AutoHeight()
		.VAlign(VAlign_Center)
		.HAlign(HAlign_Center)
		.Padding(20.0f)
		[
			SNew(SHorizontalBox)
			+ SHorizontalBox::Slot()
			.AutoWidth()
			.Padding(20.0f)
			.VAlign(VAlign_Center)
			.HAlign(HAlign_Center)
			[
				SNew(SButton)
				.ContentPadding(100)
				.OnClicked(this, &SConfirmationDialog::OnConfirmHandler)
				.Text(InArgs._ConfirmText)
				.TextStyle(FBSNStyle::Get(), "BSNGame.MenuHeaderTextStyle")
				.ButtonStyle(ButtonStyle)
				.IsFocusable(false)
			]

			+ SHorizontalBox::Slot()
			.AutoWidth()
			.Padding(20.0f)
			.VAlign(VAlign_Center)
			.HAlign(HAlign_Center)
			[
				SNew(SButton)
				.ContentPadding(100)
				.OnClicked(InArgs._OnCancelClicked)
				.Text(InArgs._CancelText)
				.TextStyle(FBSNStyle::Get(), "BSNGame.MenuHeaderTextStyle")
				.ButtonStyle(ButtonStyle)
				.Visibility(InArgs._CancelText.IsEmpty() == false ? EVisibility::Visible : EVisibility::Collapsed)
				.IsFocusable(false)
			]
		]
	];
}

bool SConfirmationDialog::SupportsKeyboardFocus() const
{
	return true;
}

FReply SConfirmationDialog::OnFocusReceived(const FGeometry& MyGeometry, const FFocusEvent& InFocusEvent)
{
	return FReply::Handled().ReleaseMouseCapture().SetUserFocus(SharedThis(this), EFocusCause::SetDirectly, true);
}

FReply SConfirmationDialog::OnKeyDown(const FGeometry& MyGeometry, const FKeyEvent& KeyEvent)
{
	const FKey Key = KeyEvent.GetKey();
	const int32 UserIndex = KeyEvent.GetUserIndex();

	switch (DialogType)
	{
	case EDialogType::Generic:
	{
		if (PlayerOwner != nullptr && PlayerOwner->GetControllerId() != UserIndex)
		{
			return FReply::Unhandled();
		}
		break;
	}
	case EDialogType::ControllerDisconnected:
	{
		UGameInstance *GI = PlayerOwner!=nullptr ? PlayerOwner->GetGameInstance() : nullptr;
		if (GI != nullptr)
		{
			if (GI->FindLocalPlayerFromControllerId(UserIndex))
			{
				return FReply::Handled();
			}
		}
		break;
	}
	default: break;
	}

	if (Key == EKeys::Enter && !KeyEvent.IsRepeat())
	{
		return ExecuteConfirm(UserIndex);
	}
	else if (Key == EKeys::Escape)
	{
		if (OnCancel.IsBound())
		{
			return OnCancel.Execute();
		}
	}

	return FReply::Unhandled();
}

FReply SConfirmationDialog::OnConfirmHandler()
{
	return ExecuteConfirm(FSlateApplication::Get().GetUserIndexForKeyboard());
}

FReply SConfirmationDialog::ExecuteConfirm(const int32 UserIndex)
{
	if (OnConfirm.IsBound())
	{
		if (DialogType == EDialogType::ControllerDisconnected && PlayerOwner != nullptr)
		{
			PlayerOwner->SetControllerId(UserIndex);
		}
		return OnConfirm.Execute();
	}
	return FReply::Unhandled();
}
