
#include "BlackShieldNetNative.h"
#include "SMainMenu.h"
#include "SlateBasics.h"
#include "SlateExtras.h"
#include "GenericPlatformChunkInstall.h"
#include "SServerList.h"

#define LOCTEXT_NAMESPACE "BSNGame.HUD.Menu"

FBSNMainMenu::~FBSNMainMenu()
{
}

void FBSNMainMenu::Construct(TWeakObjectPtr<UBlackShieldGameInstance> _GameInstance, TWeakObjectPtr<ULocalPlayer> _PlayerOwner)
{
	PlayerOwner = _PlayerOwner;
	MatchType = EMatchType::Custom;

	check(_GameInstance.IsValid());
	GameInstance = _GameInstance;
	PlayerOwner = _PlayerOwner;

	//Now that we are here, build our menu 
	MenuWidget.Reset();
	MenuWidgetContainer.Reset();

	if (GEngine && GEngine->GameViewport)
	{
		SAssignNew(MenuWidget, SMenuWidget)
			.Cursor(EMouseCursor::Default)
			.PlayerOwner(GetPlayerOwner())
			.IsGameMenu(false);

		SAssignNew(MenuWidgetContainer, SWeakWidget)
			.PossiblyNullContent(MenuWidget);

		TSharedPtr<FMenuItem> RootMenuItem;

		SAssignNew(ServerListWidget, SBSNServerList)
			.PlayerOwner(GetPlayerOwner())
			.MainMenu(this);

		MenuHelper::AddMenuItemSP(RootMenuItem, LOCTEXT("FFALong", "FREE FOR ALL"), this, &FBSNMainMenu::OnUIHostFreeForAll);
		MenuHelper::AddMenuItemSP(RootMenuItem, LOCTEXT("TDMLong", "TEAM DEATHMATCH"), this, &FBSNMainMenu::OnUIHostTeamDeathMatch);
		MenuHelper::AddMenuItemSP(RootMenuItem, LOCTEXT("Quit", "QUIT"), this, &FBSNMainMenu::OnUIQuit);

		MenuWidget->CurrentMenuTitle = LOCTEXT("MainMenu", "MAIN MENU");
		MenuWidget->MainMenu = MenuWidget->CurrentMenu = RootMenuItem->SubMenu;
		MenuWidget->OnMenuHidden.BindSP(this, &FBSNMainMenu::OnMenuHidden);

		MenuWidget->BuildAndShowMenu();
	}
}

void FBSNMainMenu::AddMenuToGameViewport(EFocusCause FocusCause/* = EFocusCause::SetDirectly*/)
{
	if (GEngine && GEngine->GameViewport)
	{
		UGameViewportClient* const GVC = GEngine->GameViewport;
		GVC->AddViewportWidgetContent(MenuWidgetContainer.ToSharedRef());
		FSlateApplication::Get().SetKeyboardFocus(MenuWidgetContainer, FocusCause);
		MenuWidget->LockControls(false);
	}
}

void FBSNMainMenu::RemoveMenuFromGameViewport()
{
	if (GEngine && GEngine->GameViewport)
	{
		GEngine->GameViewport->RemoveViewportWidgetContent(MenuWidgetContainer.ToSharedRef());
	}
}

void FBSNMainMenu::OnMenuHidden()
{
	RemoveMenuFromGameViewport();
}

FReply FBSNMainMenu::OnConfirmGeneric()
{
	return FReply::Handled();
}

void FBSNMainMenu::OnUIHostFreeForAll()
{
	ShowServerList(EMatchType::Quick);
}

void FBSNMainMenu::OnUIHostTeamDeathMatch()
{
	ShowServerList(EMatchType::Custom);
}

void FBSNMainMenu::ShowServerList(EMatchType InType)
{
	MenuWidget->LockControls(true);
	MenuWidget->HideMenu();

	if (GEngine && GEngine->GameViewport)
	{
		UGameViewportClient* const GVC = GEngine->GameViewport;
		GVC->AddViewportWidgetContent(ServerListWidget.ToSharedRef());
		FSlateApplication::Get().SetKeyboardFocus(ServerListWidget, EFocusCause::SetDirectly);
	}
}

FReply FBSNMainMenu::OnConfirm()
{
	if (GEngine && GEngine->GameViewport)
	{
	}

	return FReply::Handled();
}

void FBSNMainMenu::OnUIQuit()
{
}

void FBSNMainMenu::Quit()
{
	if (ensure(GameInstance.IsValid()))
	{
		UGameViewportClient* const Viewport = GameInstance->GetGameViewportClient();
		if (ensure(Viewport))
		{
			Viewport->ConsoleCommand("quit");
		}
	}
}

void FBSNMainMenu::LockAndHideMenu()
{
	MenuWidget->LockControls(true);
	MenuWidget->HideMenu();
}

ULocalPlayer* FBSNMainMenu::GetPlayerOwner() const
{
	return PlayerOwner.Get();
}

int32 FBSNMainMenu::GetPlayerOwnerControllerId() const
{
	return (PlayerOwner.IsValid()) ? PlayerOwner->GetControllerId() : -1;
}

#undef LOCTEXT_NAMESPACE

