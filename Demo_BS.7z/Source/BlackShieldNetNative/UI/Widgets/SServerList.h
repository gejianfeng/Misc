#pragma once

#include "BlackShieldCommons.h"
#include "SlateBasics.h"
#include "SMenuWidget.h"

struct FServerEntry
{
	FString ServerName;
	FString CurrentPlayers;
	FString MaxPlayers;
	FString GameType;
	FString MapName;
	FString Ping;
	int32 SearchResultsIndex;
};

class SBSNServerList : public SMenuWidget
{
public:
	SBSNServerList();
	~SBSNServerList();
	SLATE_BEGIN_ARGS(SBSNServerList)
	{}

	SLATE_ARGUMENT(TWeakObjectPtr<ULocalPlayer>, PlayerOwner)
	SLATE_ARGUMENT(class FBSNMainMenu*, MainMenu)
	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs);

	virtual bool SupportsKeyboardFocus() const override { return true; }

	virtual FReply OnFocusReceived(const FGeometry& MyGeometry, const FFocusEvent& InFocusEvent) override;
	virtual void OnFocusLost(const FFocusEvent& InFocusEvent) override;
	virtual FReply OnKeyDown(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent) override;

	void OnListItemDoubleClicked(TSharedPtr<FServerEntry> InItem);
	TSharedRef<ITableRow> MakeListViewWidget(TSharedPtr<FServerEntry> Item, const TSharedRef<STableViewBase>& OwnerTable);

	void EntrySelectionChanged(TSharedPtr<FServerEntry> InItem, ESelectInfo::Type SelectInfo);

	void UpdateSearchStatus();
	void BeginServerSearch(const FString& InMapFilterName);
	void OnServerSearchFinished();
	void UpdateServerList();

	void ConnectToServer();
	void MoveSelection(int32 MoveBy);
	void Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime);
protected:
	bool bSearchingForServers;
	TArray< TSharedPtr<FServerEntry> > ServerList;	
	TSharedPtr< SListView< TSharedPtr<FServerEntry> > > ServerListWidget;
	TSharedPtr<FServerEntry> SelectedItem;
	FText GetBottomText() const;
	FText StatusText;
	FString MapFilterName;
	int32 BoxWidth;
	TWeakObjectPtr<class ULocalPlayer> PlayerOwner;
	class FBSNMainMenu *MainMenu;
};


