// Copyright 1998-2016 Epic Games, Inc. All Rights Reserved.

#pragma once

#include "RespawnEffect.generated.h"

UCLASS(BlueprintType)
class ARespawnEffect :public AActor
{
	GENERATED_UCLASS_BODY()
public:
	void Start(class ABSNPlayerController *InOwner, const FString &InKiller, float InWaitTime);
	void DefaultTimer();
	void UpdateWait();
protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	USceneComponent *TextRoot;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	UTextRenderComponent *TextKiller;
	
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	UTextRenderComponent *TextWait;
	
	UPROPERTY(Transient)
	class ABSNPlayerController *MyPC;

	FTimerHandle TimerHandle_Count;
	int32		 WaitTime;
};

