#pragma once

#include "GameFramework/CheatManager.h"
#include "BSNHUD.generated.h"

class ABSNGameState;

UCLASS()
class ABSNHUD : public AHUD
{
	GENERATED_UCLASS_BODY()
public:
	UPROPERTY()
	UFont *BigFont;
	UPROPERTY()
	UFont *NormalFont;
	UPROPERTY()
	UFont *TinyFont;
public:
	virtual void DrawHUD() override;
protected:
	void DrawWaitPlayerJoin(ABSNGameState *MyGameState);
	void DrawWaitPVPPlay(ABSNGameState *MyGameState);
	void DrawLoading();
};

