// Copyright 1998-2016 Epic Games, Inc. All Rights Reserved.

#pragma once

#include "Weapon/BSNGun.h"
#include "ScoreBoard.generated.h"

UCLASS(BlueprintType)
class AScoreBoard :public AActor
{
	GENERATED_UCLASS_BODY()
public:
	AGameState *GetGameState();

	void TickActor(float DeltaTime, enum ELevelTick TickType, FActorTickFunction& ThisTickFunction) override;

	UFUNCTION(BlueprintImplementableEvent)
	void UpdateBoradTransform();

	UFUNCTION(BlueprintImplementableEvent)
	void UpdateScoreBoard();

	UFUNCTION(BlueprintImplementableEvent)
	void UpdateTimer();

	UFUNCTION(BlueprintImplementableEvent)
	void AddKillMessage(const FString &KillerName, const FString &DeathName, EGunType WeaponType);

	UFUNCTION(BlueprintImplementableEvent)
	void ShowBoard(bool  IsShow);
	
	void BeginPlay() override;
	void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	void OnUpdateScore();
protected:
	FTimerHandle  TimerHandle_UpdateScore;
};

