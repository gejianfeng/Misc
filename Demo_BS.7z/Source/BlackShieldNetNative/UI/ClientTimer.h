// Copyright 1998-2016 Epic Games, Inc. All Rights Reserved.

#pragma once

#include "ClientTimer.generated.h"

UCLASS(BlueprintType)
class AClientTimer :public AActor
{
	GENERATED_UCLASS_BODY()
public:
	void Start(bool bNeedSound, float InTime);
protected:
	void DefaultTimer();

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	int32 TimerInt;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	bool bNeedSound;
	
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	FString PrefixText;
	
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	USoundCue *Sound;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	UTextRenderComponent *TextRender;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	USceneComponent *TextRoot;

	UPROPERTY(Transient)
	UAudioComponent  *AudioComponent;

	FTimerHandle TimerHandle_Cooldown;
};

