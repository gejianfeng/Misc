
#include "BlackShieldNetNative.h"
#include "ScoreBoard.h"
#include "Game/BSNGameState.h"

AScoreBoard::AScoreBoard(const FObjectInitializer &ObjectInitializer)
	:Super(ObjectInitializer)
{
	PrimaryActorTick.bCanEverTick = true;
}

AGameState *AScoreBoard::GetGameState()
{
	UWorld *MyWorld = GetWorld();
	if (MyWorld != NULL)
	{
		return MyWorld->GetGameState();
	}
	return NULL;
}

void AScoreBoard::BeginPlay()
{
	Super::BeginPlay();
	GetWorldTimerManager().SetTimer(TimerHandle_UpdateScore, this, &AScoreBoard::OnUpdateScore, 0.5f, true);
}

void AScoreBoard::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	GetWorldTimerManager().ClearTimer(TimerHandle_UpdateScore);
	Super::EndPlay(EndPlayReason);
}

void AScoreBoard::OnUpdateScore()
{
	ABSNGameState *MyGameState = Cast<ABSNGameState>(GetGameState());
	if (MyGameState != NULL)
	{
		MyGameState->UpdateScoreBoard();
		UpdateScoreBoard();
	}
	UpdateTimer();
}

void AScoreBoard::TickActor(float DeltaTime, enum ELevelTick TickType, FActorTickFunction& ThisTickFunction)
{
	UpdateBoradTransform();
}


