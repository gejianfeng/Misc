
#include "BlackShieldNetNative.h"
#include "ClientTimer.h"
#include "Player/BSNPlayerController.h"
#include "Game/BSNGameState.h"

AClientTimer::AClientTimer(const FObjectInitializer &ObjectIntializer)
	:Super(ObjectIntializer)
{
	RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));

	TextRoot = CreateDefaultSubobject<USceneComponent>(TEXT("TextRoot"));
	TextRoot->SetupAttachment(RootComponent);
	TextRoot->SetMobility(EComponentMobility::Movable);

	TextRender = CreateDefaultSubobject<UTextRenderComponent>(TEXT("TextRender"));
	TextRender->SetupAttachment(TextRoot);
}

void AClientTimer::Start(bool bNeedSound, float InTime)
{
	if (bNeedSound && Sound != NULL)
	{
		AudioComponent = NewObject<UAudioComponent>(this, TEXT("Sound"));
		AudioComponent->SetupAttachment(RootComponent);

		AudioComponent->SetSound(Sound);
		AudioComponent->Activate();
	}
	
	if (TextRender != NULL)
	{
		FString Text = FString::Printf(TEXT("%s %d s..."), *PrefixText, InTime);
		TextRender->SetText(FText::FromString(Text));
	}

	TimerInt = InTime;
	if (InTime > 0)
	{
		GetWorldTimerManager().SetTimer(TimerHandle_Cooldown, this, &AClientTimer::DefaultTimer, 0.2f, true);
	}
	else
	{
		SetLifeSpan(0.2f);
	}
}

void AClientTimer::DefaultTimer()
{
	ABSNGameState *GameState = Cast<ABSNGameState>(GetWorld()->GetGameState());
	
	int32 NewTime = TimerInt;
	if (GameState != NULL)
	{
		int32 WaitTime = GameState->GetWaitTimeInt();
		NewTime = FMath::Min<int32>(WaitTime, TimerInt);
	}

	if (NewTime != TimerInt)
	{
		if (AudioComponent != NULL)
		{
			AudioComponent->Play();
		}

		if (TextRender != NULL)
		{
			FString Text = FString::Printf(TEXT("%s %d s..."), *PrefixText, NewTime);
			TextRender->SetText(FText::FromString(Text));
		}

		if (NewTime <= 0)
		{
			GetWorldTimerManager().ClearTimer(TimerHandle_Cooldown);
			SetLifeSpan(0.2f);
		}

		TimerInt = NewTime;
	}
}

