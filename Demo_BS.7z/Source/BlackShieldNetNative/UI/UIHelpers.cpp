
#include "BlackShieldNetNative.h"
#include "UIHelpers.h"

FText BSNUIHelpers::GetProfileOpenText() const
{
#if PLATFORM_XBOXONE
	return NSLOCTEXT("Network", "XB1OpenProfile", "Press A for GamerCard");
#elif PLATFORM_PS4
	return NSLOCTEXT("Network", "PS4OpenProfile", "Press cross button for GamerCard");
#else
	return NSLOCTEXT("Network", "PCOpenProfile", "Press Enter for GamerCard");
#endif
}

bool BSNUIHelpers::ProfileOpenedUI(const FUniqueNetId& Requestor, const FUniqueNetId& Requestee, const FOnProfileUIClosedDelegate* Delegate) const
{
	const auto OnlineSub = IOnlineSubsystem::Get();
	if (OnlineSub)
	{
		// Show the profile UI.
		const auto ExternalUI = OnlineSub->GetExternalUIInterface();
		if (ExternalUI.IsValid())
		{
			// Create a dummy delegate, if one wasn't specified
			struct Local
			{
				static void DummyOnProfileOpenedUIClosedDelegate()
				{
					// do nothing
				}
			};
			return ExternalUI->ShowProfileUI(Requestor, Requestee, Delegate ? *Delegate : FOnProfileUIClosedDelegate::CreateStatic(&Local::DummyOnProfileOpenedUIClosedDelegate));
		}
	}
	return false;
}

FText BSNUIHelpers::GetProfileSwapText() const
{
	return NSLOCTEXT("Network", "XB1SwapProfile", "Y Switch User");
}

bool BSNUIHelpers::ProfileSwapUI(const int ControllerIndex, bool bShowOnlineOnly, const FOnLoginUIClosedDelegate* Delegate) const
{
	const auto OnlineSub = IOnlineSubsystem::Get();
	if (OnlineSub)
	{
		const auto ExternalUI = OnlineSub->GetExternalUIInterface();
		if (ExternalUI.IsValid())
		{
			struct Local
			{
				static void DummyOnProfileSwapUIClosedDelegate(TSharedPtr<const FUniqueNetId> UniqueId, const int InControllerIndex)
				{
					// do nothing
				}
			};
			return ExternalUI->ShowLoginUI(ControllerIndex, bShowOnlineOnly, Delegate ? *Delegate : FOnLoginUIClosedDelegate::CreateStatic(&Local::DummyOnProfileSwapUIClosedDelegate));
		}
	}
	return false;
}

