
#include "BlackShieldNetNative.h"
#include "BlackShieldNetNativeModule.h"
#include "Weapon/BSNITem.h"
#include "UI/Styles/BSNStyle.h"

FBlackShieldNetNativeModule* g_BlackShieldNetNativeModule = nullptr;

FBlackShieldNetNativeModule::FBlackShieldNetNativeModule()
{

}

void FBlackShieldNetNativeModule::StartupModule()
{
	BlackShieldConfig.LoadGameConfig();
	g_BlackShieldNetNativeModule = this;

	//Hot reload hack
	FSlateStyleRegistry::UnRegisterSlateStyle(FBSNStyle::GetStyleSetName());
	FBSNStyle::Initialize();
}

void FBlackShieldNetNativeModule::ShutdownModule()
{
	g_BlackShieldNetNativeModule = nullptr;
}

IMPLEMENT_PRIMARY_GAME_MODULE(FBlackShieldNetNativeModule, BlackShieldNetNative, "BlackShieldNetNative");
