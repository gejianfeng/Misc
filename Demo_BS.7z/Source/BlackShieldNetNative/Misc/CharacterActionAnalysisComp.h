#pragma once

#include "BlackShieldCommons.h"
#include "CharacterActionAnalysisComp.generated.h"

UCLASS(BlueprintType)
class UCharacterActionAnalysisComp : public UActorComponent
{
	GENERATED_BODY()

public:
	UCharacterActionAnalysisComp(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());

	virtual void TickComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction *ThisTickFunction) override;

	void GetHandLocationAndRotation(EControllerHand Hand, FVector& Location, FRotator& Rotation);

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = Action)
	FVector GetHandVelocity(EControllerHand Hand) const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = Action)
	float GetHandSpeed(EControllerHand Hand) const;

protected:
	UPROPERTY()
	TArray<float> TimeArray;

	UPROPERTY()
	TArray<FBSNLocationRotation> HandLeftInfos;

	UPROPERTY()
	TArray<FBSNLocationRotation> HandRightInfos;

	UPROPERTY()
	TArray<FBSNLocationRotation> HeadInfos;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = Action)
	int32 MaxFrame;
};
