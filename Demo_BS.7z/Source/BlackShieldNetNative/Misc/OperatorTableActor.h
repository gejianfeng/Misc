#pragma once

#include "GameFramework/Actor.h"
#include "OperatorTableActor.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnOperatatorTableActivate);

UCLASS(Blueprintable)
class AOperatorTableActor : public AActor
{
	GENERATED_BODY()

public:
	AOperatorTableActor(const FObjectInitializer& ObjectIntializer = FObjectInitializer::Get());

	virtual void PostInitializeComponents() override;

	void UseObject();

	UFUNCTION(BlueprintCallable, Category = Handler)
	void HandleCollisionBeginOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult & SweepResult);

	UFUNCTION(BlueprintCallable, Category = Handler)
	void HandleCollisionEndOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);

	FOnOperatatorTableActivate& GetOperatorTableActivateDelegate() { return OperatorTableActivateDelegate; }

protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Mesh)
	UStaticMeshComponent* TableMesh;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Collision)
	UCapsuleComponent* Collision;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Mesh)
	UStaticMeshComponent* AdditionalMesh1;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Mesh)
	UStaticMeshComponent* AdditionalMesh2;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Mesh)
	UStaticMeshComponent* AdditionalMesh3;

	UPROPERTY(VisibleAnywhere, BlueprintAssignable, BlueprintReadWrite, Category = Game)
	FOnOperatatorTableActivate OperatorTableActivateDelegate;

protected:
	UPROPERTY(EditInstanceOnly, BlueprintReadWrite, Category = Target)
	AActor* TargetActor;
};
