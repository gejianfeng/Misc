#include "BlackShieldNetNative.h"
#include "OperatorTableActor.h"
#include "Player/BSNCharacter.h"
#include "Interface/OperatorTableActivateInterface.h"

AOperatorTableActor::AOperatorTableActor(const FObjectInitializer& ObjectIntializer /*= FObjectInitializer::Get()*/)
	: Super(ObjectIntializer)
{
	TableMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("TableMesh"));
	RootComponent = TableMesh;

	Collision = CreateDefaultSubobject<UCapsuleComponent>(TEXT("Collision"));
	Collision->SetCapsuleSize(20, 20);
	Collision->SetupAttachment(RootComponent);

	AdditionalMesh1 = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("AdditionalMesh1"));
	AdditionalMesh1->SetupAttachment(RootComponent);

	AdditionalMesh2 = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("AdditionalMesh2"));
	AdditionalMesh2->SetupAttachment(RootComponent);

	AdditionalMesh3 = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("AdditionalMesh3"));
	AdditionalMesh3->SetupAttachment(RootComponent);

	Collision->OnComponentBeginOverlap.AddDynamic(this, &AOperatorTableActor::HandleCollisionBeginOverlap);
	Collision->OnComponentEndOverlap.AddDynamic(this, &AOperatorTableActor::HandleCollisionEndOverlap);

	TargetActor = nullptr;
}

void AOperatorTableActor::PostInitializeComponents()
{
	Super::PostInitializeComponents();
}

void AOperatorTableActor::UseObject()
{
	OperatorTableActivateDelegate.Broadcast();

	if (TargetActor)
	{
		if (TargetActor->Implements<UOperatorTableActivateInterface>())
		{
			IOperatorTableActivateInterface::Execute_TableActivate(TargetActor);
		}
	}
}

void AOperatorTableActor::HandleCollisionBeginOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult & SweepResult)
{
	if (OtherActor && OtherActor->IsA<ABSNCharacter>())
	{
		UseObject();
	}
}

void AOperatorTableActor::HandleCollisionEndOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex)
{

}
