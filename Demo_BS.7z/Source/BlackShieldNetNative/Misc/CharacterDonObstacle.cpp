#include "BlackShieldNetNative.h"
#include "CharacterDonObstacle.h"
#include "DonNavigationHelper.h"

ACharacterDonObstacle::ACharacterDonObstacle(const FObjectInitializer& ObjectInitializer /*= FObjectInitializer::Get()*/)
	: Super(ObjectInitializer)
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickGroup = TG_PrePhysics;

	StaticMeshComponent = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("StaticMeshComponent"));
	SetRootComponent(StaticMeshComponent);

	StaticMeshComponent->bGenerateOverlapEvents = true;
	StaticMeshComponent->BodyInstance.bSimulatePhysics = true;
	StaticMeshComponent->BodyInstance.bNotifyRigidBodyCollision = true;
	StaticMeshComponent->SetCollisionObjectType(ECC_WorldDynamic);
	StaticMeshComponent->SetCollisionResponseToAllChannels(ECR_Ignore);
	StaticMeshComponent->bHiddenInGame = true;

	DynamicCollisionPulseInterval = 0.01f;
	IsObstacle = true;
}

void ACharacterDonObstacle::SetStaticMesh(class UStaticMesh* InMesh)
{
	StaticMeshComponent->SetStaticMesh(InMesh);
}

void ACharacterDonObstacle::SetSocketName(const FName& InSocketName)
{
	SocketName = InSocketName;
}

void ACharacterDonObstacle::SetIsObstacle(bool bInIsObstacle)
{
	IsObstacle = bInIsObstacle;
}

void ACharacterDonObstacle::BeginPlay()
{
	Super::BeginPlay();
	
	DonNavigationManager = UDonNavigationHelper::DonNavigationManager(this);

	GetWorld()->GetTimerManager().SetTimer(DynamicCollisionPulseTimeHandle, FTimerDelegate::CreateUObject(this, &ACharacterDonObstacle::DynamicCollisionPulse), DynamicCollisionPulseInterval, true, 1.5f);
}

void ACharacterDonObstacle::DynamicCollisionPulse()
{
	if (DonNavigationManager)
	{
		FDonCollisionSamplerCallback DonCollisionDelegate;
		DonCollisionDelegate.BindDynamic(this, &ACharacterDonObstacle::HandleDynamicCollisionResult);
		DonNavigationManager->ScheduleDynamicCollisionUpdate(StaticMeshComponent, DonCollisionDelegate, CustomCollisionCacheIdentifier, true, false, AlwaysReloadCollisionCache, false, 1.0f, false, DrawDebug);
	}
}

void ACharacterDonObstacle::HandleDynamicCollisionResult(bool bSuccess)
{

}

