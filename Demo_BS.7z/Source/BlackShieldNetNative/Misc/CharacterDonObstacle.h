#pragma once

#include "CharacterDonObstacle.generated.h"

UCLASS(BlueprintType, Abstract)
class ACharacterDonObstacle : public AActor
{
	GENERATED_BODY()

public:
	ACharacterDonObstacle(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());

	void SetStaticMesh(class UStaticMesh* InMesh);

	void SetSocketName(const FName& InSocketName);

	FName GetSocketName() const { return SocketName; }

	void SetIsObstacle(bool bInIsObstacle);

	bool GetIsObstacle() const { return IsObstacle; }

	virtual void BeginPlay() override;

	void DynamicCollisionPulse();

	UFUNCTION(BlueprintCallable, Category = Handler)
	void HandleDynamicCollisionResult(bool bSuccess);

protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	FTimerHandle DynamicCollisionPulseTimeHandle;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Obstacle)
	class UStaticMeshComponent* StaticMeshComponent;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = Obstacle)
	float DynamicCollisionPulseInterval;

	UPROPERTY(VisibleAnywhere, Transient, BlueprintReadOnly, Category = Obstacle)
	class ADonNavigationManager* DonNavigationManager;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Obstacle)
	FName SocketName;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Obstacle)
	FName CustomCollisionCacheIdentifier;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Obstacle)
	uint32 IsObstacle : 1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Obstacle)
	uint32 AlwaysReloadCollisionCache : 1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Obstacle)
	uint32 DrawDebug : 1;
};
