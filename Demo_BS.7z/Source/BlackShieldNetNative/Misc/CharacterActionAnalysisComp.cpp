#include "BlackShieldNetNative.h"
#include "CharacterActionAnalysisComp.h"
#include "Player/BSNCharacter.h"
#include "BlackShieldNetNativeConfig.h"

UCharacterActionAnalysisComp::UCharacterActionAnalysisComp(const FObjectInitializer& ObjectInitializer /*= FObjectInitializer::Get()*/)
	: Super(ObjectInitializer)
{
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.TickGroup = TG_PrePhysics;

	MaxFrame = 3;
}

void UCharacterActionAnalysisComp::TickComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction *ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	TimeArray.Add(GetWorld()->GetTimeSeconds());

	FVector HandLocatoin;
	FRotator HandRotation;
	GetHandLocationAndRotation(EControllerHand::Left, HandLocatoin, HandRotation);
	HandLeftInfos.Add(FBSNLocationRotation{ HandLocatoin, HandRotation });

	GetHandLocationAndRotation(EControllerHand::Right, HandLocatoin, HandRotation);
	HandRightInfos.Add(FBSNLocationRotation{ HandLocatoin, HandRotation });

	HeadInfos.Add(FBSNLocationRotation{ FVector::ZeroVector, FRotator::ZeroRotator });

	if (TimeArray.Num() > MaxFrame)
	{
		TimeArray.RemoveAt(0);
		HandLeftInfos.RemoveAt(0);
		HandRightInfos.RemoveAt(0);
		HeadInfos.RemoveAt(0);
	}
}

void UCharacterActionAnalysisComp::GetHandLocationAndRotation(EControllerHand Hand, FVector& Location, FRotator& Rotation)
{
	ABSNCharacter* BSNCharacter = GetTypedOuter<ABSNCharacter>();
	if (BSNCharacter)
	{
		if (GetBlackShieldConfig().InputType == EBSInputType::HTCVive)
		{
			BSNCharacter->GetHandLocationAndRotation(Hand, Location, Rotation);
		}
		else if (GetBlackShieldConfig().InputType == EBSInputType::Keyboard)
		{
			FTransform HandTransform;

			if (Hand == EControllerHand::Left)
			{
				HandTransform = BSNCharacter->GetSkeletalMesh()->GetSocketTransform(TEXT("HandCollitionBox_L"));
			}
			else if (Hand == EControllerHand::Right)
			{
				HandTransform = BSNCharacter->GetSkeletalMesh()->GetSocketTransform(TEXT("HandCollitionBox_R"));
			}

			Location = HandTransform.GetLocation();
			Rotation = FRotator(HandTransform.GetRotation());
		}
	}
}

FVector UCharacterActionAnalysisComp::GetHandVelocity(EControllerHand Hand) const
{
	FVector HandVelocity(FVector::ZeroVector);

	if (TimeArray.Num() > 0)
	{
		float DeltaTime = 0;
		DeltaTime = TimeArray.Last() - TimeArray[0];

		FVector HandDeltaLocation(FVector::ZeroVector);

		if (Hand == EControllerHand::Left)
		{
			HandDeltaLocation = HandLeftInfos.Last().Location - HandLeftInfos[0].Location;
		}
		else
		{
			HandDeltaLocation = HandRightInfos.Last().Location - HandRightInfos[0].Location;
		}

		HandVelocity = HandDeltaLocation / DeltaTime;
	}

	return HandVelocity;
}

float UCharacterActionAnalysisComp::GetHandSpeed(EControllerHand Hand) const
{
	FVector HandVelocity = GetHandVelocity(Hand);
	return HandVelocity.Size();
}
