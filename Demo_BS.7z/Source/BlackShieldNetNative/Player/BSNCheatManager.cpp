
#include "BlackShieldNetNative.h"
#include "BSNCheatManager.h"
#include "Online/BSNGameSession.h"

UBSNCheatManager::UBSNCheatManager(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{
}

void UBSNCheatManager::CreateSession(const FName &Name)
{
	AGameMode *GameMode = GetWorld()->GetAuthGameMode();
	ABSNGameSession *GameSession = Cast<ABSNGameSession>(GameMode->GameSession);
	if (GameSession != NULL)
	{
		GameSession->CreateSession(Name);
	}
}

void UBSNCheatManager::DestorySession(const FName &Name)
{
	AGameMode *GameMode = GetWorld()->GetAuthGameMode();
	ABSNGameSession *GameSession = Cast<ABSNGameSession>(GameMode->GameSession);
	if (GameSession != NULL)
	{
		GameSession->DestorySession(Name);
	}
}

void UBSNCheatManager::DumpSession(const FName &Name)
{
	AGameMode *GameMode = GetWorld()->GetAuthGameMode();
	ABSNGameSession *GameSession = Cast<ABSNGameSession>(GameMode->GameSession);
	if (GameSession != NULL)
	{
		GameSession->DumpSession(Name);
	}
}

void UBSNCheatManager::JoinSession(const FName &Name)
{
	AGameMode *GameMode = GetWorld()->GetAuthGameMode();
	ABSNGameSession *GameSession = Cast<ABSNGameSession>(GameMode->GameSession);
	if (GameSession != NULL)
	{
		APlayerController *PC = GEngine->GetFirstLocalPlayerController(GetWorld());
		ULocalPlayer *Player = PC?  PC->GetLocalPlayer() : NULL;
		if (Player != NULL)
		{
			uint32 PlayerNum = Player->GetControllerId();
			GameSession->JoinSession(PlayerNum, Name);
		}
	}
}


