#include "BlackShieldNetNative.h"
#include "AI/BSNBotAIController.h"
#include "BSNCharacterBot.h"
#include "Weapon/BSNITem.h"
#include "Component/BSNMovementController.h"

#define Z_AXIS_ADJUST_FIRE_ANGLE			4.7

ABSNCharacterBot::ABSNCharacterBot(const FObjectInitializer& ObjectInitializer /*= FObjectInitializer::Get()*/)
	: Super(ObjectInitializer)
{
	AutoPossessAI = EAutoPossessAI::Disabled;
}

void ABSNCharacterBot::PostInitializeComponents()
{
	Super::PostInitializeComponents();

	// Initialize Left & Right Hand Location
	LeftHandLocation = FVector::ZeroVector;
	RightHandLocation = FVector::ZeroVector;

	// Disable MovementController Tick
	MovementController->SetTickStatus(false);

	// Disable bUseControllerRotationPitch
	bUseControllerRotationPitch = false;
}

void ABSNCharacterBot::HandleHealthDamaged(float Damage, struct FDamageEvent const& DamageEvent, class AController* EventInstigator, class AActor* DamageCauser)
{
	// Update Damage Causer Array
	if ((Damage < Health) && !DamageCausersArray.Contains(DamageCauser))
	{
		bool bProcessed = false;
		
		// Check if damage causer is item (weapon, etc.)
		if (!bProcessed)
		{
			auto DamageItem = Cast<ABSNItem>(DamageCauser);
			if (DamageItem) {
				auto DamageCauserCharacter = DamageItem->BSNOwner;
				if (DamageCauserCharacter)
				{
					if (!DamageCausersArray.Contains(DamageCauserCharacter))
					{
						DamageCausersArray.Add(DamageCauserCharacter);
					}
					
					bProcessed = true;
				}
			}
		}

		// Check if damage causer is character (player, bot, monster, etc.)
		if (!bProcessed)
		{
			auto DamageCauserCharacter = Cast<ABSNCharacterBase>(DamageCauser);
			if (DamageCauserCharacter)
			{
				if (!DamageCausersArray.Contains(DamageCauserCharacter))
				{
					DamageCausersArray.Add(DamageCauserCharacter);
				}

				bProcessed = true;
			}
		}
	}

	Super::HandleHealthDamaged(Damage, DamageEvent, EventInstigator, DamageCauser);
}

void ABSNCharacterBot::Die(float Damage, struct FDamageEvent const& DamageEvent, class AController* EventInstigator, class AActor* DamageCauser)
{
	// Clear Damage Causer Array
	if (!CanDie(Damage, DamageEvent, EventInstigator, DamageCauser))
		return;

	DamageCausersArray.Empty();

	Super::Die(Damage, DamageEvent, EventInstigator, DamageCauser);
}

void ABSNCharacterBot::ClearDamageCausersArray()
{
	DamageCausersArray.Empty();
}

void ABSNCharacterBot::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	SimulatorZAxisMovement(DeltaSeconds);

	if (Role == ROLE_Authority)
	{
		UpdateHandLocation(DeltaSeconds);
		AdjustHandLocationByAIDifficulty(DeltaSeconds);
	}
}

void ABSNCharacterBot::UpdateHandLocation(float DeltaSeconds)
{
	FMinimalViewInfo DesiredView;
	PlayerCamera->GetCameraView(DeltaSeconds, DesiredView);
	FVector DesiredViewLocation = DesiredView.Location;
	FRotator DesiredViewRotator = DesiredView.Rotation;
	FVector DesiredViewRotatorForwardVector1 = FRotationMatrix(DesiredViewRotator).GetScaledAxis(EAxis::X);
	FVector DesiredViewRotatorForwardVector2 = DesiredViewRotatorForwardVector1 * 2000.0f;
	FVector TempVector = DesiredViewLocation + DesiredViewRotatorForwardVector2;

	FTransform SkeletalMeshTransform = SkeletalMesh->K2_GetComponentToWorld();
	FVector HandSpotLocation = SkeletalMeshTransform.InverseTransformPosition(TempVector);

	LeftHandLocation = HandSpotLocation;
	RightHandLocation = HandSpotLocation;
}

void ABSNCharacterBot::SimulatorZAxisMovement(float DeltaSeconds)
{
	UWorld* World = GetWorld();
	float GameTime = World ? World->GetTimeSeconds() : 0.0f;
	float ZAxis = FMath::Sin(GameTime * 3) * 2 + 2;

	FVector NewLocation;
	NewLocation.X = SkeletalMesh->RelativeLocation.X;
	NewLocation.Y = SkeletalMesh->RelativeLocation.Y;
	NewLocation.Z = ZAxis;

	SkeletalMesh->SetRelativeLocation(NewLocation);
}

void ABSNCharacterBot::AdjustHandLocationByAIDifficulty(float DeltaSeconds)
{
	AController* Controller = GetController();
	if (Controller)
	{
		AAIController* AIController = Cast<AAIController>(Controller);
		
		if (AIController)
		{
			AActor* FocusActor = AIController->GetFocusActor();

			if (FocusActor && AIController->LineOfSightTo(FocusActor))
			{
				ABSNCharacter* FocusCharacter = Cast<ABSNCharacter>(FocusActor);
				
				if (FocusCharacter && FocusCharacter->GetSkeletalMesh())
				{
					FVector SocketLocation = FocusCharacter->GetSkeletalMesh()->GetSocketLocation("RocketFireSocket");
					FTransform SelfTransform = SkeletalMesh->K2_GetComponentToWorld();
					FVector ReferenceVector = SelfTransform.InverseTransformPosition(SocketLocation);

					FRotator OffsetFireAngle;

					ABSNBotAIController* BotAIController = Cast<ABSNBotAIController>(AIController);
					if (BotAIController)
					{
						float RandVal = FMath::FRandRange(0.0f, 100.0f);

						if (BotAIController->GetFireMissRate() < RandVal)
						{
							OffsetFireAngle = FRotator(0, 0, Z_AXIS_ADJUST_FIRE_ANGLE);
						}
						else
						{
							float RandVal = FMath::FRandRange(-10.0f, 10.0f);
							OffsetFireAngle = FRotator(0, 0, RandVal);
						}
					}
					else
					{
						OffsetFireAngle = FRotator(0, 0, Z_AXIS_ADJUST_FIRE_ANGLE);
					}

					FVector NewLocation = OffsetFireAngle.RotateVector(ReferenceVector);
					RightHandLocation = NewLocation;

					// For Debug
					//UWorld* World = GetWorld();
					//FVector DebugVector = SelfTransform.TransformPosition(NewLocation);
					//DrawDebugSphere(World, DebugVector, 20, 12, FColor(255, 255, 255, 255));
				}
			}
		}
	}
	
}

void ABSNCharacterBot::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(ABSNCharacterBot, LeftHandLocation);
	DOREPLIFETIME(ABSNCharacterBot, RightHandLocation);
}