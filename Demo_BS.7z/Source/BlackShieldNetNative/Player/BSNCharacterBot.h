#pragma once

#include "AI/Navigation/RecastNavMesh.h"
#include "BSNCharacterFloat.h"
#include "BSNCharacterBot.generated.h"

UCLASS(BlueprintType)
class ABSNCharacterBot : public ABSNCharacterFloat
{
	GENERATED_BODY()

public:
	ABSNCharacterBot(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());

	virtual void HandleHealthDamaged(float Damage, struct FDamageEvent const& DamageEvent, class AController* EventInstigator, class AActor* DamageCauser) override;
	virtual void Die(float Damage, struct FDamageEvent const& DamageEvent, class AController* EventInstigator, class AActor* DamageCauser) override;
	virtual void PostInitializeComponents() override;

	UFUNCTION(BlueprintCallable, Category = Default)
	void ClearDamageCausersArray();

	virtual void Tick(float DeltaSeconds) override;

	void UpdateHandLocation(float DeltaSeconds);
	void SimulatorZAxisMovement(float DeltaSeconds);
	void AdjustHandLocationByAIDifficulty(float DeltaSeconds);

	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;
	
protected:

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Default)
	TArray<AActor*> DamageCausersArray;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Replicated, Category = Default)
	FVector LeftHandLocation;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Replicated, Category = Default)
	FVector RightHandLocation;
};
