#include "BlackShieldNetNative.h"
#include "BSNPlayerControllerLobby.h"

ABSNPlayerControllerLobby::ABSNPlayerControllerLobby(const FObjectInitializer& ObjectInitializer /*= FObjectInitializer::Get()*/)
	: Super(ObjectInitializer)
{

}

void ABSNPlayerControllerLobby::BeginInactiveState()
{
	APlayerController::BeginInactiveState();
}
