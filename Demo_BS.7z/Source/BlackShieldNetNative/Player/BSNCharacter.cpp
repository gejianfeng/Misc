
// Fill out your copyright notice in the Description page of Project Settings.

#include "BlackShieldNetNative.h"
#include "BSNCharacter.h"
#include "Component/BSNMovementController.h"
#include "BSNPlayerController.h"
#include "Game/BSNGameModeBase.h"
#include "Skill/SkillBase.h"
#include "Gears/HelmetActor.h"
#include "BlackShieldUtilityFunctions.h"
#include "DataTables/HeroSelectionData.h"
#include "Component/BSNSkillManager.h"
#include "Component/BSNCharacterMovementComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Component/VRMotionControllerComponent.h"
#include "BlackShieldNetNativeConfig.h"
#include "Weapon/BSNGun.h"
#include "Weapon/WeaponBag.h"
#include "Weapon/BSNGrenade.h"
#include "Weapon/BSNHandGun.h"
#include "Skill/SkillTeleport.h"
#include "UI/ClientTimer.h"
#include "Game/BSNPlayerState.h"
#include "UI/BSNHUD.h"
#include "Game/BSNGameViewportClient.h"

// Sets default values
ABSNCharacter::ABSNCharacter(const FObjectInitializer& ObjectInitializer /*= FObjectInitializer::Get()*/)
	: Super(ObjectInitializer.SetDefaultSubobjectClass<UBSNCharacterMovementComponent>(CharacterMovementComponentName))
	, LeftHandWeapon(NULL)
	, RightHandWeapon(NULL)
	, Grenade(NULL)
	, AutoHandGun(NULL)
	, FireGrenadeCount(0)
{
	bInOnConstruction = false;
	bOnConstructionProcessed = false;

	bInPossingHMD = false;

	bWantsToFire = false;
	bShowWeaponBag = false;
	MaxCombineTime = 1.0f;
	MaxCombineLengthSquared = 200.f;

 	// Set this character to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickGroup = TG_PrePhysics;

	PlayerCamera = CreateDefaultSubobject<UCameraComponent>(TEXT("PlayerCamera"));
	PlayerCamera->bUsePawnControlRotation = false;
	PlayerCamera->RelativeLocation = FVector(-49.0f, 0, 223.54f);
	PlayerCamera->RelativeRotation = FRotator(-30.0f, 0, 0);
	PlayerCamera->SetupAttachment(GetCapsuleComponent());

	RadialBlurComponent = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("RadialBlurEffect"));
	RadialBlurComponent->SetupAttachment(PlayerCamera);
	
	UIScene = CreateDefaultSubobject<USceneComponent>(TEXT("UIScene"));
	UIScene->SetupAttachment(PlayerCamera);

	SkeletalMesh = CreateDefaultSubobject<USkeletalMeshComponent>(TEXT("SkeletalMesh"));
	SkeletalMesh->PrimaryComponentTick.TickGroup = TG_PrePhysics;
	SkeletalMesh->MeshComponentUpdateFlag = EMeshComponentUpdateFlag::AlwaysTickPose;
	SkeletalMesh->PrimaryComponentTick.bCanEverTick = true;
	SkeletalMesh->SetCollisionProfileName(TEXT("VRCharacter"));
	SkeletalMesh->bGenerateOverlapEvents = true;
	SkeletalMesh->BodyInstance.bNotifyRigidBodyCollision = true;
	SkeletalMesh->SetupAttachment(GetCapsuleComponent());
	SkeletalMesh->bReceivesDecals = false;

	TeleportTrailEffect = CreateDefaultSubobject<UParticleSystemComponent>(TEXT("TeleportTrailEffect"));
	TeleportTrailEffect->SetupAttachment(SkeletalMesh);
	ConstructorHelpers::FObjectFinder<UParticleSystem> ObjFinder(TEXT("ParticleSystem'/Game/BlackShield/Effects/PVP/P_MoveTrail_01.P_MoveTrail_01'"));
	if (ObjFinder.Object)
	{
		UParticleSystem *TrailPS = Cast<UParticleSystem>(ObjFinder.Object);
		TeleportTrailEffect->SetTemplate(TrailPS);
	}

	LeftHandTriggerBox = CreateDefaultSubobject<USphereComponent>("LeftHandBox");
	RightHandTriggerBox = CreateDefaultSubobject<USphereComponent>("RightHandBox");

	LeftHandTriggerBox->SetSphereRadius(15.f);
	RightHandTriggerBox->SetSphereRadius(15.f);

//	LeftHandTriggerBox->IsOverlappingActor()
	if (SkeletalMesh)
	{
		LeftHandTriggerBox->SetupAttachment(SkeletalMesh, TEXT("Bip001-L-Hand"));
		RightHandTriggerBox->SetupAttachment(SkeletalMesh, TEXT("Bip001-R-Hand"));

		//LeftHandTriggerBox->AttachToComponent(SkeletalMesh, FAttachmentTransformRules(EAttachmentRule::SnapToTarget, false), TEXT("Bip001-L-Hand"));
		//RightHandTriggerBox->AttachToComponent(SkeletalMesh, FAttachmentTransformRules(EAttachmentRule::SnapToTarget, false), TEXT("Bip001-R-Hand"));
	}

	ParticleBloodReturn = CreateDefaultSubobject<UParticleSystemComponent>(TEXT("ParticleBloodReturn"));
	ParticleBloodReturn->SetupAttachment(SkeletalMesh);
	ParticleBloodReturn->bVisible = false;
	ParticleBloodReturn->bAutoActivate = false;

	// MovementController should be created by sub class. (UBSNMovementController => ABSNCharacterFloat / UBSNAircraftMovementController => ABSNCharacterAircraft)
	//MovementController = CreateDefaultSubobject<UBSNMovementController>(TEXT("MovementController"));

	//BSNCharMovementComp = Cast<UBSNCharacterMovementComponent>(GetCharacterMovement());

	SkillManager = CreateDefaultSubobject<UBSNSkillManager>(TEXT("SkillManager"));

	Scene1P = CreateDefaultSubobject<USceneComponent>(TEXT("Scene1P"));
	Scene1P->SetupAttachment(GetCapsuleComponent());

	MotionControllerLeft = CreateDefaultSubobject<UVRMotionControllerComponent>(TEXT("MotionControllerLeft"));
	MotionControllerLeft->Hand = EControllerHand::Left;
	MotionControllerLeft->PlayerIndex = INDEX_NONE;
	MotionControllerLeft->SetCollisionProfileName(TEXT("NoCollision"));
	MotionControllerLeft->SetupAttachment(Scene1P);

	MotionControllerRight = CreateDefaultSubobject<UVRMotionControllerComponent>(TEXT("MotionControllerRight"));
	MotionControllerRight->Hand = EControllerHand::Right;
	MotionControllerRight->PlayerIndex = INDEX_NONE;
	MotionControllerRight->SetCollisionProfileName(TEXT("NoCollision"));
	MotionControllerRight->SetupAttachment(Scene1P);

	HeroName = TEXT("Hero0");
	WeaponBagComponent = CreateDefaultSubobject<UWeaponBag>(TEXT("UWeponBag"));
}

void ABSNCharacter::OnConstruction(const FTransform& Transform)
{
	Super::OnConstruction(Transform);

	bInOnConstruction = true;
	DoOnConstruction(Transform);
	bInOnConstruction = false;

	bOnConstructionProcessed = true;
}

void ABSNCharacter::DoOnConstruction(const FTransform& Transform)
{
	ChangeHeroMesh(HeroName);
}

void ABSNCharacter::FixesHMDOrientation()
{
	if (GEngine->HMDDevice.IsValid())
	{
		GEngine->HMDDevice->ResetOrientation(0);
	}
}

void ABSNCharacter::GetHandLocationAndRotation(EControllerHand Hand, FVector& Location, FRotator& Rotation) const
{
	UVRMotionControllerComponent* SelectedMotionController = nullptr;
	switch (Hand)
	{
	case EControllerHand::Left:
		SelectedMotionController = MotionControllerLeft;
		break;

	case EControllerHand::Right:
		SelectedMotionController = MotionControllerRight;
		break;
	}

	if (SelectedMotionController)
	{
		Location = SelectedMotionController->RelativeLocation;
		Rotation = SelectedMotionController->RelativeRotation;
	}
}

// Called when the game starts or when spawned
void ABSNCharacter::BeginPlay()
{
	Super::BeginPlay();

	UpdateTelportEffectMaterialIndex();
}

void ABSNCharacter::UpdateTelportEffectMaterialIndex()
{
	ABSNPlayerState *MyState = Cast<ABSNPlayerState>(PlayerState);

	if (TeleportTrailEffect &&  ColorsInstance.Num() > 0)
	{
		if (MyState && MyState->GetPlayerIndex() >= 0)
		{
			int32 MaterialIndex = MyState->GetPlayerIndex() % ColorsInstance.Num();
			UMaterialInterface *Material = ColorsInstance[MaterialIndex];
			TeleportTrailEffect->SetMaterial(0, Material);
			TeleportTrailEffect->SetVisibility(false);
		}
		else
		{
			FTimerHandle UnusedTimerHanle;
			GetWorldTimerManager().SetTimer(UnusedTimerHanle, this, &ABSNCharacter::UpdateTelportEffectMaterialIndex, 3.0f, false);
		}
	}
}

void ABSNCharacter::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	if (LeftHandWeapon != NULL)
	{
		GetWorld()->DestroyActor(LeftHandWeapon);
		LeftHandWeapon = NULL;
	}

	if (RightHandWeapon != NULL)
	{
		GetWorld()->DestroyActor(RightHandWeapon);
		RightHandWeapon = NULL;
	}

	if (Grenade != NULL)
	{
		GetWorld()->DestroyActor(Grenade);
		Grenade = NULL;
	}

	if (AutoHandGun!=NULL)
	{
		GetWorld()->DestroyActor(AutoHandGun);
		AutoHandGun = NULL;
	}

	if (TimerHandler_FinishTeleportEffect.IsValid())
	{
		GetWorldTimerManager().ClearTimer(TimerHandler_FinishTeleportEffect);
		TimerHandler_FinishTeleportEffect.Invalidate();
	}
}

void ABSNCharacter::Destroyed()
{
	DestroyHelmet();

	Super::Destroyed();
}

void ABSNCharacter::Blink(const FVector& Destination)
{
	UBSNCharacterMovementComponent* BSNCharMovementComp = Cast<UBSNCharacterMovementComponent>(GetCharacterMovement());
	if (BSNCharMovementComp)
	{
		BSNCharMovementComp->Blink(Destination);
	}
}

// Called every frame
void ABSNCharacter::Tick( float DeltaTime )
{
	Super::Tick( DeltaTime );
	UpdateCombineTime(DeltaTime);
}

// Called to bind functionality to input
void ABSNCharacter::SetupPlayerInputComponent(class UInputComponent* InputComponent)
{
	Super::SetupPlayerInputComponent(InputComponent);

	InputComponent->BindAxis(TEXT("MoveForward"), this, &ABSNCharacter::HandleMoveForward);
	InputComponent->BindAxis(TEXT("MoveRight"), this, &ABSNCharacter::HandleMoveRight);
	InputComponent->BindAxis(TEXT("Turn"), this, &ABSNCharacter::HandleTurn);
	InputComponent->BindAxis(TEXT("LookUp"), this, &ABSNCharacter::HandleLookUp);

	InputComponent->BindAction("Fire", IE_Pressed, this, &ABSNCharacter::OnStartFire);
	InputComponent->BindAction("Fire", IE_Released, this, &ABSNCharacter::OnStopFire);

	InputComponent->BindAction(TEXT("CastSkill"), IE_Pressed, this, &ABSNCharacter::HandleStartCastSkill);
	InputComponent->BindAction(TEXT("CastSkill"), IE_Released, this, &ABSNCharacter::HandleStopCastSkill);

	InputComponent->BindAction(TEXT("LeftGrab"), IE_Pressed, this, &ABSNCharacter::LeftGrapItem);
	InputComponent->BindAction(TEXT("RightGrab"), IE_Pressed, this, &ABSNCharacter::RightGrapItem);

	InputComponent->BindAction(TEXT("LeftMenu"), IE_Pressed, this, &ABSNCharacter::ShowWeaponBag);
	InputComponent->BindAction(TEXT("ShowGameInfo"), IE_Pressed, this, &ABSNCharacter::HandleShowGameInfo);
	InputComponent->BindAction(TEXT("ShowGameInfo"), IE_Released, this, &ABSNCharacter::HandleHideGameInfo);
}

void ABSNCharacter::HandleMoveForward(float AxisValue)
{
	if (!CanProcessInputEvent())
		return;

	if (HasAuthority())
	{
		FRotator Rotation = GetControlRotation();

		FVector MoveDirection = FRotationMatrix(Rotation).GetUnitAxis(EAxis::X);

		AddMovementInput(MoveDirection, AxisValue);
	}
}

void ABSNCharacter::HandleMoveRight(float AxisValue)
{
	if (!CanProcessInputEvent())
		return;

	if (HasAuthority())
	{
		FRotator Rotation = GetControlRotation();

		FVector MoveDirection = FRotationMatrix(Rotation).GetUnitAxis(EAxis::Y);

		AddMovementInput(MoveDirection, AxisValue);
	}
}

void ABSNCharacter::HandleTurn(float AxisValue)
{
	if (!CanProcessInputEvent())
		return;

	if (AxisValue)
	{
		AddControllerYawInput(AxisValue);
	}
}

void ABSNCharacter::HandleLookUp(float AxisValue)
{
	if (!CanProcessInputEvent())
		return;

	if (AxisValue)
	{
		AddControllerPitchInput(AxisValue);
	}
}

bool ABSNCharacter::CanProcessInputEvent()
{
	if (GetBlackShieldConfig().InputType == EBSInputType::Keyboard)
	{
		return true;
	}

	if (GetBlackShieldConfig().InputType == EBSInputType::OculusCV1 || GetBlackShieldConfig().InputType == EBSInputType::Gamepad)
	{
		return true;
	}

	if (GetBlackShieldConfig().InputType == EBSInputType::ArcadeBoard && GetBlackShieldConfig().MoveType == EBSMoveType::Aircraft)
	{
		return true;
	}

	if (GetBlackShieldConfig().InputType == EBSInputType::HTCVive && GetBlackShieldConfig().MoveType == EBSMoveType::Aircraft)
	{
		return true;
	}

	return false;
}

void ABSNCharacter::HandleStartCastSkill()
{
	if (ASkillBase* Skill = SkillManager->GetFirstSkillObject())
	{
		Skill->StartUse();
	}
}

void ABSNCharacter::HandleStopCastSkill()
{
	if (ASkillBase* Skill = SkillManager->GetFirstSkillObject())
	{
		Skill->StopUse();
	}
}

void ABSNCharacter::HandleStartLeftGrab()
{
	if (ASkillBase* Skill = SkillManager->GetSecondSkillObject())
	{
		Skill->ActivateSkill();
	}
}

void ABSNCharacter::HandleStopLeftGrab()
{
	if (ASkillBase* Skill = SkillManager->GetSecondSkillObject())
	{
		Skill->DeactivateSkill();
	}
}
void ABSNCharacter::ShowWeaponBag()
{
	bShowWeaponBag = !bShowWeaponBag;
	if (bShowWeaponBag)
	{
		if (WeaponBagComponent)
		{
			WeaponBagComponent->ShowWeaponItems();
		}
	}
	else {

		if (WeaponBagComponent)
		{
			WeaponBagComponent->HidenWeaponItems();
		}
	
	}

}

void ABSNCharacter::SetVehicleRelativeRotation(FRotator RelativeRotator)
{

}

void ABSNCharacter::PostInitializeComponents()
{
	Super::PostInitializeComponents();

	if (!IsPendingKill())
	{
		MovementController->OwningCharacter = this;
		MovementController->UpdatedMeshComponent = SkeletalMesh;
		// force animation tick after movement component updates
		if (SkeletalMesh->PrimaryComponentTick.bCanEverTick && MovementController)
		{
			SkeletalMesh->PrimaryComponentTick.AddPrerequisite(MovementController, MovementController->PrimaryComponentTick);
		}

		if (MovementController->PrimaryComponentTick.bCanEverTick && MotionControllerLeft && MotionControllerRight)
		{
			MovementController->PrimaryComponentTick.AddPrerequisite(MotionControllerLeft, MotionControllerLeft->PrimaryComponentTick);
			MovementController->PrimaryComponentTick.AddPrerequisite(MotionControllerRight, MotionControllerRight->PrimaryComponentTick);
		}

		SkillManager->OwningCharacter = this;
		SkeletalMesh->MeshComponentUpdateFlag = IsLocallyControlled() ? EMeshComponentUpdateFlag::AlwaysTickPoseAndRefreshBones:EMeshComponentUpdateFlag::OnlyTickPoseWhenRendered;
		LeftHandTriggerBox->OnComponentBeginOverlap.AddDynamic(this, &ABSNCharacter::LeftHandEnter);
		RightHandTriggerBox->OnComponentBeginOverlap.AddDynamic(this, &ABSNCharacter::RightHandEnter);
		LeftHandTriggerBox->OnComponentEndOverlap.AddDynamic(this, &ABSNCharacter::LeftHandExit);
		RightHandTriggerBox->OnComponentEndOverlap.AddDynamic(this, &ABSNCharacter::RightHandExit);
	}
	
	APlayerController* PC = GEngine->GetFirstLocalPlayerController(GetWorld());	
	if (GetNetMode()!=NM_DedicatedServer && PC != NULL && PC->MyHUD!=NULL)
	{
		PC->MyHUD->AddPostRenderedActor(this);
	}

	if (RadialBlurComponent != NULL)
	{
		RadialBlurComponent->SetVisibility(false);
	}
}

void ABSNCharacter::HandleClientSetBodyTranslucent_Implementation()
{
	if (auto GameInstance = BSNUtils::GetBSNGameInstance(this))
	{
		FHeroSelectionDataRow* HeroData = GameInstance->GetHeroSelectoinDataManager()->FindHeroData(*HeroName);
		if (HeroData)
		{
			for (auto i : HeroData->MeshElementHideIndices)
			{
				//SkeletalMesh->SetMaterial(i, TranparentMaterail);
				if (i < SkeletalDynamicMaterials.Num())
				{
					UMaterialInstanceDynamic* MaterialInstance = SkeletalDynamicMaterials[i];
					if (MaterialInstance)
					{
						MaterialInstance->SetScalarParameterValue(TEXT("Visible"), 0);
					}
				}
			}
		}
	}
}

void ABSNCharacter::PossessedBy(AController* NewController)
{
	Super::PossessedBy(NewController);

	if (IsLocallyControlled() && IsPlayerControlled())
	{
		PossessedInLocallyControlled();
	}
}

void ABSNCharacter::OnRep_Controller()
{
	Super::OnRep_Controller();

	APlayerController* PlayerController = Cast<APlayerController>(GetController());
	if (PlayerController)
	{
		PossessedInLocallyControlled();
	}
}

void ABSNCharacter::PossessedInLocallyControlled()
{
	HandleClientSetBodyTranslucent();

	EnableMotionControllers();

	bInPossingHMD = false;

	if (GetBlackShieldConfig().InputType == EBSInputType::Keyboard)
	{
		bUseControllerRotationPitch = true;
	}

	if (GetBlackShieldConfig().InputType == EBSInputType::HTCVive)
	{
		if (GEngine->HMDDevice.IsValid())
		{
			//if (GEngine->HMDDevice->HasValidTrackingPosition())
			{
				FixesHMDOrientation();
			}
			//else
			//{
			//	bInPossingHMD = true;
			//}
		}
	}

	if (SkillManager)
	{
		SkillManager->LocalPlayerInit();
	}
}

void ABSNCharacter::EnableMotionControllers()
{
	if (MotionControllerLeft)
	{
		MotionControllerLeft->PlayerIndex = 0;
		MotionControllerRight->PlayerIndex = 0;
	}
}

void ABSNCharacter::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(ABSNCharacter, HeroName);

	DOREPLIFETIME(ABSNCharacter, CharacterHitInfo);

	//Bag
	DOREPLIFETIME(ABSNCharacter, InventoryItems);

	//Body
	DOREPLIFETIME(ABSNCharacter, RightHandWeapon);
	DOREPLIFETIME(ABSNCharacter, LeftHandWeapon);

	//Grenade
	DOREPLIFETIME(ABSNCharacter, Grenade);
	DOREPLIFETIME(ABSNCharacter, FireGrenadeCount);
	DOREPLIFETIME(ABSNCharacter, AutoHandGun);
}

UBSNAnimInstance *ABSNCharacter::GetAnimInstance()
{
	if (SkeletalMesh)
	{
		return Cast<UBSNAnimInstance>(SkeletalMesh->GetAnimInstance());
	}

	return nullptr;
}

void ABSNCharacter::SetupHelmet()
{
	if (Helmet)
		return;

	if (HelmetClass)
	{
		Helmet = GetWorld()->SpawnActor<AHelmetActor>(HelmetClass);
		Helmet->SetOwningCharacter(this);
		Helmet->AttachToComponent(PlayerCamera, FAttachmentTransformRules::KeepRelativeTransform);
		Helmet->PutOn();
	}
}

void ABSNCharacter::DestroyHelmet()
{
	if (Helmet)
	{
		Helmet->Destroy();
		Helmet = nullptr;
	}
}

void ABSNCharacter::ClientInitInGame_Implementation()
{
	SetupHelmet();
}

void ABSNCharacter::OnStartFire()
{
	if (!bWantsToFire)
	{
		if (Grenade != NULL)
		{
			FireGrenade();
		}
		else
		{
			if (ABSNGun *pGun = Cast<ABSNGun>(RightHandWeapon))
			{
				pGun->StartFire();
			}
			else if (AutoHandGun)
			{
				AutoHandGun->StartFire();
			}
		}
		bWantsToFire = true;
	}
}

void ABSNCharacter::FireGrenade(bool bReplicated /*= false*/)
{
	if (!bReplicated && Role < ROLE_Authority)
	{
		ServerFireGrenade();
	}
	else
	{
		FireGrenadeCount++;
		Grenade->Fire();
		GetWorld()->GetTimerManager().SetTimer(TimeHandle_AutoWeaponAfterGrenade, this, &ABSNCharacter::FinishFireGrenade, 1.0f, false);
	}
}

void ABSNCharacter::FinishFireGrenade()
{
	ShowWeapon();
	Grenade = NULL;
}

void ABSNCharacter::TeleportToTarget(const FVector& TargetLocation)
{
	if (ASkillTeleport* Skill = Cast<ASkillTeleport>(SkillManager->GetFirstSkillObject()))
	{
		if (!Skill->IsInCoolDown())
		{
			Skill->TeleportToTarget(TargetLocation);
		}
	}
}

void ABSNCharacter::StartTelportEffect()
{
	APlayerController *MyController = GEngine->GetFirstLocalPlayerController(GetWorld());
	if (MyController==GetController())
	{
		if (RadialBlurComponent != NULL)
		{
			RadialBlurComponent->SetVisibility(true);

			GetWorldTimerManager().SetTimer(TimerHandler_FinishTeleportEffect,
											FTimerDelegate::CreateLambda([this]()
											{
												RadialBlurComponent->SetVisibility(false);
												GetWorldTimerManager().ClearTimer(TimerHandler_FinishTeleportEffect);
												TimerHandler_FinishTeleportEffect.Invalidate();
											}),
											0.45f, false);
		}
	}
	else
	{
		if (TeleportTrailEffect != NULL)
		{
			TeleportTrailEffect->SetActive(true, true);
			TeleportTrailEffect->SetVisibility(true, true);
			TeleportTrailEffect->BeginTrails(TEXT("Top"), TEXT("Down"), ETrailWidthMode_FromCentre, 1);

			GetWorldTimerManager().SetTimer(TimerHandler_FinishTeleportEffect,
											FTimerDelegate::CreateLambda([this]()
											{
												TeleportTrailEffect->SetActive(false, true);
												TeleportTrailEffect->SetVisibility(false);
												GetWorldTimerManager().ClearTimer(TimerHandler_FinishTeleportEffect);
												TimerHandler_FinishTeleportEffect.Invalidate();
											}), 
											1.0f, false);
		}
	}
}

void ABSNCharacter::MulticastTeleportEffect_Implementation()
{
	if (!HasAuthority())
	{
		StartTelportEffect();
	}
}

void ABSNCharacter::SimulateTelportEffect()
{
	if (HasAuthority())
	{
		if (!IsRunningDedicatedServer())
		{
			StartTelportEffect();
		}
		MulticastTeleportEffect();
	}
	else
	{
		StartTelportEffect();
	}
}

void ABSNCharacter::OnRep_FireGrenade()
{
	FireGrenade(true);
}

bool ABSNCharacter::ServerFireGrenade_Validate()
{
	return true;
}

void ABSNCharacter::ServerFireGrenade_Implementation()
{
	FireGrenade();
}

void ABSNCharacter::OnStopFire()
{
	if (bWantsToFire)
	{
		bWantsToFire = false;
		if (ABSNGun *pWeapon = Cast<ABSNGun>(RightHandWeapon))
		{
			pWeapon->StopFire();
		}
		else if(AutoHandGun)
		{
			AutoHandGun->StopFire();
		}
	}
}

void ABSNCharacter::GiveHealth(int32 InHealth)
{
	uint32 NewHealth = InHealth + Health;
	SetHealth(NewHealth);
}

void ABSNCharacter::SetIsDying(bool bInIsDying)
{
	if (Role == ROLE_Authority)
	{
		bool bOldIsDying = bIsDying;
		bIsDying = bInIsDying;
		OnRep_IsDying(bOldIsDying);
	}
}

void ABSNCharacter::OnRep_IsDying(bool bOldIsDying)
{
	if (bIsDying)
	{
		UAnimInstance* AnimInstance = GetAnimInstance();
		if (AnimInstance && AnimInstance->Implements<UCharacterAnimInterface>())
		{
			ICharacterAnimInterface::Execute_SetDoFKAnim(AnimInstance, EFKAnimState::Dead);
		}

		DestroyHelmet();

		if (SkillManager)
		{
			SkillManager->DestroySkills();
		}
	}
}

void ABSNCharacter::SetInvincible(bool bInInvincible)
{
	if (Role == ROLE_Authority)
	{
		bool bOldInvincible = bInvincible;
		bInvincible = bInInvincible;

		OnRep_Invincible(bOldInvincible);
	}
}

void ABSNCharacter::OnRep_Invincible(bool bOldInvincible)
{
	if (bInvincible)
	{
		StartGodEffect();
	}
	else
	{
		StopGodEffect();
	}
}

void ABSNCharacter::StartGodEffect()
{
	ParticleBloodReturn->SetVisibility(true, true);
	ParticleBloodReturn->SetActive(true);
}

void ABSNCharacter::StopGodEffect()
{
	ParticleBloodReturn->SetVisibility(false, true);
	ParticleBloodReturn->SetActive(false);
}

float ABSNCharacter::TakeDamage(float Damage, struct FDamageEvent const& DamageEvent, AController* EventInstigator, AActor* DamageCauser)
{
	bool bCanDamage = false;

	if (ABSNGameModeBase* GameMode = GetWorld()->GetAuthGameMode<ABSNGameModeBase>())
	{
		bCanDamage = GameMode->CanDamage(EventInstigator, GetController(), DamageCauser);
	}
	if (!bCanDamage)
		return 0;

	float AutalDamage = ACharacter::TakeDamage(Damage, DamageEvent, EventInstigator, DamageCauser);
	
	int32 NewHealth = Health - FMath::RoundToInt(AutalDamage);
	NewHealth = FMath::Clamp<int32>(NewHealth, 0, MaxHealth);
	AutalDamage = Health - NewHealth;
	SetHealth(NewHealth);

	HandleHealthDamaged(AutalDamage, DamageEvent, EventInstigator, DamageCauser);

	return AutalDamage;
}

void ABSNCharacter::HandleHealthDamaged(float Damage, struct FDamageEvent const& DamageEvent, class AController* EventInstigator, class AActor* DamageCauser)
{
	OnHealthDamaged(Damage, EventInstigator, DamageCauser);

	if (Health <= 0)
	{
		Die(Damage, DamageEvent, EventInstigator, DamageCauser);
	}
	else
	{
		CharacterHit(Damage, DamageEvent, EventInstigator, DamageCauser);
	}
}

void ABSNCharacter::Die(float Damage, struct FDamageEvent const& DamageEvent, class AController* EventInstigator, class AActor* DamageCauser)
{
	if (!CanDie(Damage, DamageEvent, EventInstigator, DamageCauser))
		return;

	OnDead(Damage, EventInstigator, DamageCauser);

	UDamageType const* const DamageTypeCDO = DamageEvent.DamageTypeClass ? DamageEvent.DamageTypeClass->GetDefaultObject<UDamageType>() : GetDefault<UDamageType>();

	DestroyItems();

	if (ABSNGameModeBase* GameMode = GetWorld()->GetAuthGameMode<ABSNGameModeBase>())
	{
		GameMode->Killed(EventInstigator, GetController(), this, DamageTypeCDO);
		GameMode->StartPlayerRespawnProcess(GetController());
		SetLifeSpan(GameMode->MinRespawnDelay - 0.1);
	}

	ABSNPlayerState* BSNPlayerState = Cast<ABSNPlayerState>(PlayerState);
	if (BSNPlayerState)
	{
		BSNPlayerState->SetPlayerDead(true);
	}

	ABSNPlayerController* PlayerController = Cast<ABSNPlayerController>(GetController());
	if (PlayerController)
	{
		PlayerController->EnterDeathSpectatorState();
	}

	SetIsDying(true);
}

bool ABSNCharacter::CanDie(float Damage, struct FDamageEvent const& DamageEvent, class AController* EventInstigator, class AActor* DamageCauser)
{
	if (bIsDying										// already dying
		|| IsPendingKill()								// already destroyed
		|| Role != ROLE_Authority						// not authority
		|| GetWorld()->GetAuthGameMode() == NULL
		|| GetWorld()->GetAuthGameMode()->GetMatchState() == MatchState::LeavingMap)	// level transition occurring
	{
		return false;
	}

	return true;
}

void ABSNCharacter::CharacterHit(float Damage, struct FDamageEvent const& DamageEvent, class AController* EventInstigator, class AActor* DamageCauser)
{
	if (EventInstigator)
	{
		ABSNCharacter* InstigatorChar = Cast<ABSNCharacter>(EventInstigator->GetPawn());
		if (InstigatorChar)
		{
			CharacterHitInfo.AttackerLocation = InstigatorChar->GetSkeletalMesh()->GetComponentLocation();
			CharacterHitInfo.Damage = Damage;
			CharacterHitInfo.Count++;

			OnRep_CharacterHitInfo();
		}
	}
}

void ABSNCharacter::OnHealthModified(int32 OldHealth)
{
	if (GetController() && GetController()->IsLocalPlayerController())
	{
		if (Helmet)
		{
			int32 DeltaHealth = Health - OldHealth;
			bool bHit = false;
			if (DeltaHealth < 0)
			{
				bHit = true;
			}
			else if (DeltaHealth > 0)
			{
				bHit = false;
			}
			Helmet->GetHurt(bHit);
			Helmet->SetHp(Health, MaxHealth);
		}
	}
}

void ABSNCharacter::OnRep_CharacterHitInfo()
{
	if (IsLocalPlayerControlled())
	{
		if (Helmet)
		{
			Helmet->ShowHurtIndicator(CharacterHitInfo.AttackerLocation);
		}
	}
}

void ABSNCharacter::OnRep_HeroName(const FString& OldHeroName)
{
	if (HeroName != OldHeroName)
	{
		ChangeHeroMesh(HeroName);
	}
}

void ABSNCharacter::ChangeHero(const FString& InHeroName)
{
	if (!bOnConstructionProcessed)
	{
		HeroName = InHeroName;
		return;
	}

	if (InHeroName != HeroName)
	{
		if (HasAuthority())
		{
			FString OldHeroName = HeroName;
			HeroName = InHeroName;
			OnRep_HeroName(OldHeroName);
		}
		else
		{
			ServerChangeHero(InHeroName);
		}
	}
}

bool ABSNCharacter::ServerChangeHero_Validate(const FString& InHeroName)
{
	return true;
}

void ABSNCharacter::ServerChangeHero_Implementation(const FString& InHeroName)
{
	ChangeHero(InHeroName);
}

void ABSNCharacter::ChangeHeroMesh(const FString& InHeroName)
{
	if (auto GameInstance = BSNUtils::GetBSNGameInstance(this))
	{
		FHeroSelectionDataRow* HeroData = GameInstance->GetHeroSelectoinDataManager()->FindHeroData(*InHeroName);
		if (HeroData)
		{
			ClearSkeletalMeshMaterials();

			SkeletalMesh->SetSkeletalMesh(HeroData->Asset.LoadSynchronous());

			USkeletalMesh* MeshAsset = SkeletalMesh->SkeletalMesh;
			if (MeshAsset)
			{
				for (int32 i = 0; i < SkeletalMesh->GetNumMaterials(); ++i)
				{
					SkeletalDynamicMaterials.Add(SkeletalMesh->CreateDynamicMaterialInstance(i));
				}

				APlayerController* PlayerController = Cast<APlayerController>(GetController());
				if (PlayerController)
				{
					HandleClientSetBodyTranslucent();
				}
			}
		}
	}
}

void ABSNCharacter::ClearSkeletalMeshMaterials()
{
	SkeletalDynamicMaterials.Empty();

	for (int32 i = 0; i < SkeletalMesh->GetNumMaterials(); ++i)
	{
		SkeletalMesh->SetMaterial(i, nullptr);
	}
}

void ABSNCharacter::GetCameraLocationAndRotation(FVector &Location, FRotator &Rotation)
{
	Location = PlayerCamera->GetComponentLocation();
	Rotation = PlayerCamera->GetComponentRotation();

}

void ABSNCharacter::LeftHandEnter(UPrimitiveComponent* OverlapedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult & SweepResult)
{
	if (OtherActor)
	{
		if (OtherActor->GetClass()->ImplementsInterface(UPickupInterface::StaticClass()))
		{
			LeftHandOverlapActor = OtherActor;
		}
		//OtherActor
	}
	
}
void ABSNCharacter::RightHandEnter(UPrimitiveComponent* OverlapedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult & SweepResult)
{
	if (OtherActor)
	{
		if (OtherActor->GetClass()->ImplementsInterface(UPickupInterface::StaticClass()))
		{
			RightHandOverlapActor = OtherActor;
		}
		//OtherActor
	}
}
void ABSNCharacter::LeftHandExit(UPrimitiveComponent* OverlapedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex)
{
	if (OtherActor)
	{
		if (OtherActor->GetClass()->ImplementsInterface(UPickupInterface::StaticClass()))
		{
			LeftHandOverlapActor = nullptr;
		}
		//OtherActor
	}
}
void ABSNCharacter::RightHandExit(UPrimitiveComponent* OverlapedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex)
{
	if (OtherActor)
	{
		if (OtherActor->GetClass()->ImplementsInterface(UPickupInterface::StaticClass()))
		{
			RightHandOverlapActor = nullptr;
		}
		//OtherActor
	}
}

void ABSNCharacter::LeftGrapItem()
{
	if (LeftHandOverlapActor)
	{
		IPickupInterface::Execute_OnLeftHandPickup(LeftHandOverlapActor);
	}
}
void ABSNCharacter::RightGrapItem()
{
	if (RightHandOverlapActor)
	{
		IPickupInterface::Execute_OnRightHandPickup(RightHandOverlapActor);
	}

}

void ABSNCharacter::ClientStartWait_Implementation(float WaitTime)
{
	ABSNPlayerController *MyPC = Cast<ABSNPlayerController>(Controller);
	if (MyPC && MyPC->WaitEffect)
	{
		AClientTimer *WaitEffectActor = (AClientTimer *)GetWorld()->SpawnActor(MyPC->WaitEffect, &FTransform::Identity);
		if (WaitEffectActor != NULL)
		{
			WaitEffectActor->AttachToComponent(GetUIScene(), FAttachmentTransformRules::KeepRelativeTransform);
			WaitEffectActor->Start(true, WaitTime);
		}
	}
}

void ABSNCharacter::PostRenderFor(APlayerController *PC, UCanvas *Canvas, FVector CameraPosition, FVector CameraDir)
{
	ABSNPlayerState *MyState = Cast<ABSNPlayerState>(PlayerState);
	UFont* TinyFont = ABSNHUD::StaticClass()->GetDefaultObject<ABSNHUD>()->TinyFont;

	bool bLocalPlayer = Controller && Controller->IsLocalController();
	if (bLocalPlayer || !MyState || !TinyFont)
	{
		return;
	}

	static const FName NAME_FreeCam = FName(TEXT("FreeCam"));
	FCollisionQueryParams BoxParams(NAME_FreeCam, false, this);
	FHitResult OutHit(1.0f);
	GetWorld()->SweepSingleByChannel(OutHit, CameraPosition, GetActorLocation() + GetCapsuleComponent()->GetUnscaledCapsuleHalfHeight(), FQuat::Identity, ECC_Camera, FCollisionShape::MakeBox(FVector(12.f)), BoxParams);

	FColor HeadColor = FColor::Yellow;
	if (OutHit.bBlockingHit)
	{
// 		HeadColor.A = 100;
		return;
	}

	if (FVector::DotProduct((GetActorLocation() - CameraPosition), CameraDir) > 0)
	{
		float XL, YL;
		float Scale = 1.0f;
		Canvas->TextSize(TinyFont, MyState->PlayerName, XL, YL, Scale, Scale);

		FVector WorldPostition = SkeletalMesh->GetComponentLocation();
		FVector ScreenPosition = Canvas->Project(WorldPostition + FVector(0, 0, GetCapsuleComponent()->GetUnscaledCapsuleHalfHeight()*2.25f));
		float XPos = ScreenPosition.X - 0.5f*XL;
		float YPos = ScreenPosition.Y - YL;

		FCanvasTextItem TipText(FVector2D(Canvas->OrgX+XPos, Canvas->OrgY + YPos), FText::FromString(MyState->PlayerName), TinyFont, HeadColor);
		Canvas->DrawItem(TipText);
	}
}

void ABSNCharacter::HandleShowGameInfo()
{
	UBSNGameViewportClient *MyViewPort = Cast<UBSNGameViewportClient>(GetWorld()->GetGameViewport());
	if (MyViewPort != NULL)
	{
		MyViewPort->ShowScoreRank();
	}
}

void ABSNCharacter::HandleHideGameInfo()
{
	UBSNGameViewportClient *MyViewPort = Cast<UBSNGameViewportClient>(GetWorld()->GetGameViewport());
	if (MyViewPort != NULL)
	{
		MyViewPort->HideScoreRank();
	}
}

FTransform ABSNCharacter::GetHeadTransform()
{
	FTransform HeadTransform(GetActorRotation(), GetActorLocation() + FVector(0, 0, GetCapsuleComponent()->GetScaledCapsuleHalfHeight()*2.0f), FVector(1.0f));
	return HeadTransform;
}

