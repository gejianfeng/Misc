#pragma once

#include "BSNCharacter.h"
#include "BSNCharacterFloat.generated.h"

UCLASS(BlueprintType)
class ABSNCharacterFloat : public ABSNCharacter
{
	GENERATED_BODY()

public:
	ABSNCharacterFloat(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());
};
