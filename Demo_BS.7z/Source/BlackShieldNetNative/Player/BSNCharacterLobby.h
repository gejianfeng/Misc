#pragma once

#include "BSNCharacterFloat.h"
#include "BSNCharacterLobby.generated.h"

USTRUCT(BlueprintType)
struct FDonObstacleCreationInfo
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FName SocketName;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	class UStaticMesh* StaticMesh;
};

UCLASS(BlueprintType)
class ABSNCharacterLobby : public ABSNCharacterFloat
{
	GENERATED_BODY()

public:
	ABSNCharacterLobby(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());

	void CreateObstacles();

	void UpdateObstacles();

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = Action)
	FVector GetHandVelocity(EControllerHand Hand) const;

	UFUNCTION(BlueprintCallable, BlueprintPure, Category = Action)
	float GetHandSpeed(EControllerHand Hand) const;

	virtual void BeginPlay() override;

	virtual void Tick(float DeltaSeconds) override;

protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Lobby")
	class UCharacterActionAnalysisComp* ChrActionAnalysis;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Lobby")
	TSubclassOf<class ACharacterDonObstacle> DonObstacleClass;

	UPROPERTY(VisibleAnywhere, Transient, BlueprintReadOnly, Category = "Lobby")
	TArray<class ACharacterDonObstacle*> Obstacles;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Lobby")
	TArray<FDonObstacleCreationInfo> DonObstacleCreationInfos;
};
