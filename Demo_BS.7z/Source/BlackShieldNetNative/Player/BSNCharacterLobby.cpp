#include "BlackShieldNetNative.h"
#include "BSNCharacterLobby.h"
#include "Misc/CharacterActionAnalysisComp.h"
#include "Misc/CharacterDonObstacle.h"

ABSNCharacterLobby::ABSNCharacterLobby(const FObjectInitializer& ObjectInitializer /*= FObjectInitializer::Get()*/)
	: Super(ObjectInitializer)
{
	ChrActionAnalysis = CreateDefaultSubobject<UCharacterActionAnalysisComp>(TEXT("ChrActionAnalysis"));
}

void ABSNCharacterLobby::CreateObstacles()
{
	if (DonObstacleClass)
	{
		for (int32 i = 0; i < DonObstacleCreationInfos.Num(); ++i)
		{
			FDonObstacleCreationInfo& ObstacleInfo = DonObstacleCreationInfos[i];

			ACharacterDonObstacle* Obstacle = GetWorld()->SpawnActor<ACharacterDonObstacle>(DonObstacleClass, SkeletalMesh->GetSocketTransform(ObstacleInfo.SocketName));
			Obstacle->SetStaticMesh(ObstacleInfo.StaticMesh);
			Obstacle->SetSocketName(ObstacleInfo.SocketName);

			Obstacles.Add(Obstacle);
		}
	}
}

void ABSNCharacterLobby::UpdateObstacles()
{
	for (int32 i = 0; i < Obstacles.Num(); ++i)
	{
		ACharacterDonObstacle* Obstacle = Obstacles[i];

		FTransform MeshSocketTransform = SkeletalMesh->GetSocketTransform(DonObstacleCreationInfos[i].SocketName);
		Obstacle->SetActorTransform(MeshSocketTransform, true);
	}
}

FVector ABSNCharacterLobby::GetHandVelocity(EControllerHand Hand) const
{
	return ChrActionAnalysis->GetHandVelocity(Hand);
}

float ABSNCharacterLobby::GetHandSpeed(EControllerHand Hand) const
{
	return ChrActionAnalysis->GetHandSpeed(Hand);
}

void ABSNCharacterLobby::BeginPlay()
{
	Super::BeginPlay();

	CreateObstacles();

	if (Obstacles.Num() >= 3)
	{
		Obstacles[1]->SetIsObstacle(false);
		Obstacles[2]->SetIsObstacle(false);
	}
}

void ABSNCharacterLobby::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	UpdateObstacles();
}
