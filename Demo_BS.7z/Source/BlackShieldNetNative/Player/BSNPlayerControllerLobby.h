#pragma once

#include "BSNPlayerController.h"
#include "BSNPlayerControllerLobby.generated.h"

UCLASS(Blueprintable)
class ABSNPlayerControllerLobby : public ABSNPlayerController
{
	GENERATED_BODY()

public:
	ABSNPlayerControllerLobby(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());

	virtual void BeginInactiveState() override;
};
