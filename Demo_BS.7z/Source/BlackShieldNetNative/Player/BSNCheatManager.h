#pragma once

#include "GameFramework/CheatManager.h"
#include "BSNCheatManager.generated.h"

UCLASS(Within = BSNPlayerController)
class UBSNCheatManager : public UCheatManager
{
	GENERATED_UCLASS_BODY()
public:
	UFUNCTION(exec)
	void CreateSession(const FName &Name);
	UFUNCTION(exec)
	void DestorySession(const FName &Name);
	UFUNCTION(exec)
	void DumpSession(const FName &Name);
	UFUNCTION(exec)
	void JoinSession(const FName &Name);
};

