#pragma once

#include "GameFramework/PlayerController.h"
#include "BSNPlayerController.generated.h"

UCLASS(config = Game, BlueprintType, Blueprintable)
class ABSNPlayerController : public APlayerController
{
	GENERATED_BODY()

public:
	ABSNPlayerController(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());
	~ABSNPlayerController();

	void EnterDeathSpectatorState();

	void LeaveDeathSpectatorState();

	UFUNCTION(Client, Reliable)
	void ClientEnterDeathSpectatorState();

	virtual void ClientEnterDeathSpectatorState_Implementation();

	UFUNCTION(Client, Reliable)
	void ClientLeaveDeathSpectatorState();

	virtual void ClientLeaveDeathSpectatorState_Implementation();

	virtual void BeginInactiveState() override;

	virtual void ClientReturnToMainMenu_Implementation(const FString& ReturnReason) override;
	UFUNCTION(BlueprintCallable, Category = Game)
	void SetHeroName(const FString& InHeroName);

	UFUNCTION(BlueprintCallable, Category = Game)
	FString GetHeroName() const;

	UFUNCTION(BlueprintCallable, Reliable, Server, WithValidation, Category = Game)
	void ServerSetHeroName(const FString& InHeroName);
	virtual bool ServerSetHeroName_Validate(const FString& InHeroName);
	virtual void ServerSetHeroName_Implementation(const FString& InHeroName);
	UFUNCTION(Reliable, Client)
	void ClientSetSpectatorCamera(FVector CameraLocation, FRotator CameraRotation);
	UFUNCTION(Reliable, Client)
	void ClientGameStarted();
	virtual void PostInitializeComponents() override;
	virtual void OnRep_PlayerState();

	UFUNCTION(Exec)
	void FinishGame();

	UFUNCTION(Reliable, Server, WithValidation)
	void ServerFinishGame();
	///
	UFUNCTION(Reliable, Client)
	void ClientGameover();

	//PVP
	UFUNCTION(Exec)
	void ExecPVP(const FString &InMapName);
	
	UFUNCTION(Reliable, Server, WithValidation)
	void ServerExecPVP(const FString &InMapName, uint32 NumPlayerNeed);
	
	UFUNCTION(Reliable, Client)
	void ClientRequestPVPMode();
	
	FReply OnAgreePVP();
	FReply OnRefusePVP();
	
	UFUNCTION(Reliable,Server,WithValidation)
	void ServerJoinPVP(bool bJoin);

	//wait to start
	UPROPERTY(EditDefaultsOnly)
	TSubclassOf<class AClientTimer>  WaitEffect;

	//dead effect
	UPROPERTY(EditDefaultsOnly)
	TSubclassOf<class ARespawnEffect> RespawnEffect;

	UFUNCTION(Reliable,Client)
	void ClientStartRespawnEffect(const FString &Killer, float WaitTime);

	//
	UFUNCTION(Exec)
	void ExecSwitchMap(const FString &InMapName);

	UFUNCTION(Reliable, Server, WithValidation)
	void ServerExecSwitchMap(const FString &InMapName);
protected:
	FTimerHandle TimerHandle_Respawn;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Effect)
	class UPostProcessComponent* PostProcessComponent;
};