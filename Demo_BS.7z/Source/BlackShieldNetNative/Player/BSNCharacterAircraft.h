#pragma once

#include "BSNCharacter.h"
#include "BSNCharacterAircraft.generated.h"

UCLASS(BlueprintType)
class ABSNCharacterAircraft : public ABSNCharacter
{
	GENERATED_BODY()

public:
	ABSNCharacterAircraft (const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());

	virtual void BeginPlay() override;
	virtual void Destroyed() override;

	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

	virtual void FixesHMDOrientation() override;

	virtual void HandleMoveForward(float AxisValue) override;
	virtual void HandleMoveRight(float AxisValue) override;

	virtual void SetVehicleRelativeRotation(FRotator RelativeRotator) override;

	virtual void ClientInitInGame_Implementation() override;

	void DestroyAircraft();

	USceneComponent* GetOriginalPoint() const { return OriginalPoint; }

protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Aircraft)
	AActor* Aircraft;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = Aircraft)
	TSubclassOf<class AActor> DefaultAircraftActorClass;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Aircraft)
	USceneComponent* AircraftAttachComponent;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Aircraft)
	USceneComponent* OriginalPoint;
};