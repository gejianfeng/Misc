#include "BlackShieldNetNative.h"
#include "Component/BSNAircraftMovementController.h"
#include "Interface/AircraftAnimInterface.h"

ABSNCharacterAircraft::ABSNCharacterAircraft(const FObjectInitializer& ObjectInitializer /*= FObjectInitializer::Get()*/)
	: Super(ObjectInitializer)
	, Aircraft(NULL)
{
	GetCapsuleComponent()->SetCollisionProfileName(TEXT("PlayerFly"));

	AircraftAttachComponent = CreateDefaultSubobject<USceneComponent>(TEXT("AircraftAttachPoint"));
	AircraftAttachComponent->SetupAttachment(GetCapsuleComponent());

	OriginalPoint = CreateDefaultSubobject<USceneComponent>(TEXT("OriginalPoint"));
	OriginalPoint->SetupAttachment(AircraftAttachComponent);

	MovementController = CreateDefaultSubobject<UBSNAircraftMovementController>(TEXT("MovementController"));
	MovementController->SetUpdateMeshTransform(false);
}

void ABSNCharacterAircraft::BeginPlay()
{
	Super::BeginPlay();

	if (Aircraft == NULL && DefaultAircraftActorClass)
	{
		Aircraft = GetWorld()->SpawnActor<AActor>(DefaultAircraftActorClass, FVector(0, 0, 0), FRotator(0, 0, 0));
		if (Aircraft)
		{
			Aircraft->AttachToComponent(AircraftAttachComponent, FAttachmentTransformRules::KeepRelativeTransform);
		}
	}
}

void ABSNCharacterAircraft::Destroyed()
{
	Super::Destroyed();
	DestroyAircraft();
}

void ABSNCharacterAircraft::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);
	DestroyAircraft();

	if (MovementController)
	{
		UBSNAircraftMovementController* AircraftMovementController = Cast<UBSNAircraftMovementController>(MovementController);
		if (AircraftMovementController)
		{
			AircraftMovementController->StopSimulate();
		}
	}
}

void ABSNCharacterAircraft::FixesHMDOrientation()
{
	Super::FixesHMDOrientation();

	if (MovementController)
	{
		UBSNAircraftMovementController* AircraftMovementController = Cast<UBSNAircraftMovementController>(MovementController);
		if (AircraftMovementController)
		{
			AircraftMovementController->CanInitSimulate();
		}
	}
}

void ABSNCharacterAircraft::HandleMoveForward(float AxisValue)
{
	Super::HandleMoveForward(AxisValue);

	if (Aircraft && Aircraft->Implements<UAircraftAnimInterface>())
	{
		IAircraftAnimInterface::Execute_SetAccelerateForward(Aircraft, AxisValue);
	}
}

void ABSNCharacterAircraft::HandleMoveRight(float AxisValue)
{
	Super::HandleMoveRight(AxisValue);

	if (Aircraft && Aircraft->Implements<UAircraftAnimInterface>())
	{
		IAircraftAnimInterface::Execute_SetAccelerateRight(Aircraft, AxisValue);
	}
}

void ABSNCharacterAircraft::SetVehicleRelativeRotation(FRotator RelativeRotator)
{
	Super::SetVehicleRelativeRotation(RelativeRotator);

	if (Aircraft)
	{
		Aircraft->SetActorRelativeRotation(RelativeRotator);
	}
}

void ABSNCharacterAircraft::ClientInitInGame_Implementation()
{
	Super::ClientInitInGame_Implementation();
	
	if (MovementController)
	{
		UBSNAircraftMovementController* AircraftMovementController = Cast<UBSNAircraftMovementController>(MovementController);
		if (AircraftMovementController)
		{
			AircraftMovementController->StartSimulate();
		}
	}
}

void ABSNCharacterAircraft::DestroyAircraft()
{
	if (Aircraft)
	{
		GetWorld()->DestroyActor(Aircraft);
		Aircraft = NULL;
	}
}