#include "BlackShieldNetNative.h"
#include "BSNPlayerController.h"
#include "BlackShieldUtilityFunctions.h"
#include "BlackShieldGameInstance.h"
#include "BSNCheatManager.h"
#include "Game/BSNPlayerState.h"
#include "BSNPlayerController.h"
#include "Game/BSNGameViewportClient.h"
#include "UI/ClientTimer.h"
#include "UI/RespawnEffect.h"
#include "Player/BSNCharacter.h"
#include "UI/Widgets/SScoreRank.h"
#include "Net/UnrealNetwork.h"
#include "Game/BSNGameModeBase.h"

ABSNPlayerController::ABSNPlayerController(const FObjectInitializer& ObjectInitializer /*= FObjectInitializer::Get()*/) 
	: Super(ObjectInitializer)
{
	PrimaryActorTick.bCanEverTick = true;
	CheatClass = UBSNCheatManager::StaticClass();

	PostProcessComponent = CreateDefaultSubobject<UPostProcessComponent>(TEXT("PostProcessComponent"));
	PostProcessComponent->SetupAttachment(RootComponent);
	PostProcessComponent->bUnbound = true;
}

ABSNPlayerController::~ABSNPlayerController()
{
}

void ABSNPlayerController::EnterDeathSpectatorState()
{
	if (!IsLocalPlayerController())
	{
		ChangeState(NAME_Default);
		ChangeState(NAME_Spectating);
	}

	ClientEnterDeathSpectatorState();
}

void ABSNPlayerController::LeaveDeathSpectatorState()
{
	ClientLeaveDeathSpectatorState();
}

void ABSNPlayerController::ClientEnterDeathSpectatorState_Implementation()
{
	ChangeState(NAME_Default);
	ChangeState(NAME_Spectating);

	PostProcessComponent->Settings.bOverride_ColorSaturation = true;
	PostProcessComponent->Settings.ColorSaturation = FVector::ZeroVector;
}

void ABSNPlayerController::ClientLeaveDeathSpectatorState_Implementation()
{
	PostProcessComponent->Settings.bOverride_ColorSaturation = false;
	PostProcessComponent->Settings.ColorSaturation = FVector(1.0f, 1.0f, 1.0f);
}

void ABSNPlayerController::BeginInactiveState()
{
	Super::BeginInactiveState();
}

void ABSNPlayerController::ClientReturnToMainMenu_Implementation(const FString& ReturnReason)
{
	Super::ClientReturnToMainMenu_Implementation(ReturnReason);

	if (auto GameInstance = BSNUtils::GetBSNGameInstance(this))
	{
		GameInstance->DestroySession();
	}
}

void ABSNPlayerController::ClientSetSpectatorCamera_Implementation(FVector CameraLocation, FRotator CameraRotation)
{
	SetInitialLocationAndRotation(CameraLocation, CameraRotation);
	SetViewTarget(this);
}

void ABSNPlayerController::ClientGameStarted_Implementation()
{
	SetIgnoreMoveInput(false);

	if (UWorld* World = GetWorld())
	{
		ALevelScriptActor* LevelScriptActor = World->GetLevelScriptActor();
		if (LevelScriptActor)
		{
			ILevelScriptGameInterface::Execute_GameModeStarted(LevelScriptActor);
		}
	}
//  	SetViewTarget(GetPawn());
}

void ABSNPlayerController::SetHeroName(const FString& InHeroName)
{
	if (HasAuthority())
	{
		ABSNPlayerState* BSNPlayerState = Cast<ABSNPlayerState>(PlayerState);
		if (BSNPlayerState)
		{
			BSNPlayerState->SetHeroName(InHeroName);
		}

		if (ABSNCharacter* BSNCharacter = Cast<ABSNCharacter>(GetPawn()))
		{
			BSNCharacter->ChangeHero(InHeroName);
		}
	}
	else
	{
		ServerSetHeroName(InHeroName);
	}

	if (IsLocalPlayerController())
	{
		if (auto GameInstance = BSNUtils::GetBSNGameInstance(this))
		{
			GameInstance->HeroName = InHeroName;
		}
	}
}

FString ABSNPlayerController::GetHeroName() const
{
	ABSNPlayerState* BSNPlayerState = Cast<ABSNPlayerState>(PlayerState);
	if (BSNPlayerState)
	{
		return BSNPlayerState->GetHeroName();
	}

	return FString();
}

bool ABSNPlayerController::ServerSetHeroName_Validate(const FString& InHeroName)
{
	return true;
}

void ABSNPlayerController::ServerSetHeroName_Implementation(const FString& InHeroName)
{
	SetHeroName(InHeroName);
}

void ABSNPlayerController::PostInitializeComponents()
{
	Super::PostInitializeComponents();
}

void ABSNPlayerController::OnRep_PlayerState()
{
	Super::OnRep_PlayerState();
}

void ABSNPlayerController::FinishGame()
{
	if (Role < ROLE_Authority)
	{
		ServerFinishGame();
	}
	else
	{
		ABSNGameModeBase *GameMode = Cast<ABSNGameModeBase>(GetWorld()->GetAuthGameMode());
		if (GameMode != NULL)
		{
			GameMode->FinishGame();
		}
	}
}

bool ABSNPlayerController::ServerFinishGame_Validate()
{
	return true;
}

void ABSNPlayerController::ServerFinishGame_Implementation()
{
	FinishGame();
}

void ABSNPlayerController::ClientRequestPVPMode_Implementation()
{
	UBSNGameViewportClient *MyGameViewport = Cast<UBSNGameViewportClient>(GetWorld()->GetGameViewport());
	if (MyGameViewport != NULL)
	{
		const FText Message = NSLOCTEXT("ProfileMessages", "", "If you want to join pvp game ?");
		const FText OnOk = NSLOCTEXT("DialogButtons", "AOK", "OK");
		const FText OnCancel = NSLOCTEXT("DialogButtons", "ACancel", "Cancel");
		MyGameViewport->ShowDialog(nullptr,
			EDialogType::Generic,
			Message,
			OnOk,
			OnCancel,
			FOnClicked::CreateUObject(this, &ABSNPlayerController::OnAgreePVP),
			FOnClicked::CreateUObject(this, &ABSNPlayerController::OnRefusePVP)
		);
	}
}

void ABSNPlayerController::ExecPVP(const FString &InMapName)
{
	uint32 NumPlayerNeed = 2;

	if (Role < ROLE_Authority)
	{
		ServerExecPVP(InMapName, NumPlayerNeed);
	}
	else
	{
		UBlackShieldGameInstance *GI = Cast<UBlackShieldGameInstance>(GetGameInstance());
		if (GI != NULL)
		{
			GI->BeginRequestPVPMode(InMapName, NumPlayerNeed);
		}
	}
}

bool ABSNPlayerController::ServerExecPVP_Validate(const FString &InMapName, uint32 NumPlayerNeed)
{
	return NumPlayerNeed>1;
}

void ABSNPlayerController::ServerExecPVP_Implementation(const FString &InMapName, uint32 NumPlayerNeed)
{
	ExecPVP(InMapName);
}

bool ABSNPlayerController::ServerJoinPVP_Validate(bool bJoin)
{
	return true;
}

void ABSNPlayerController::ServerJoinPVP_Implementation(bool bJoin)
{
	UBlackShieldGameInstance *GI = Cast<UBlackShieldGameInstance>(GetGameInstance());
	if (GI != NULL)
	{
		GI->JoinPVP(this, bJoin);
	}
}

FReply ABSNPlayerController::OnAgreePVP()
{
	ServerJoinPVP(true);
	
	UBSNGameViewportClient *MyGameViewport = Cast<UBSNGameViewportClient>(GetWorld()->GetGameViewport());
	if (MyGameViewport != NULL)
	{
		MyGameViewport->HideDialog();
	}
	
	return FReply::Handled();
}

FReply ABSNPlayerController::OnRefusePVP()
{
	ServerJoinPVP(false);

	UBSNGameViewportClient *MyGameViewport = Cast<UBSNGameViewportClient>(GetWorld()->GetGameViewport());
	if (MyGameViewport != NULL)
	{
		MyGameViewport->HideDialog();
	}

	return FReply::Handled();
}

void ABSNPlayerController::ClientGameover_Implementation()
{
	if (!HasAuthority())
	{
		UNetDriver *NetDriver = GEngine->FindNamedNetDriver(GetWorld(), TEXT("GameNetDriver"));
		if (NetDriver != NULL)
		{
			GEngine->DestroyNamedNetDriver(GetWorld(), NetDriver->NetDriverName);
			ABSNGameModeBase *GameMode = ABSNGameModeBase::StaticClass()->GetDefaultObject<ABSNGameModeBase>();
			if (GameMode != NULL)
			{
				GEngine->SetClientTravel(GetWorld(), TEXT("L_MainMenuLevel"), TRAVEL_Absolute);
			}
		}
	}
}

void ABSNPlayerController::ExecSwitchMap(const FString &InMapName)
{
	if (Role < ROLE_Authority)
	{
		ServerExecSwitchMap(InMapName);
	}
	else
	{
		GetWorld()->ServerTravel(*InMapName, false);
	}
}

bool ABSNPlayerController::ServerExecSwitchMap_Validate(const FString &InMapName)
{
	return true;
}

void ABSNPlayerController::ServerExecSwitchMap_Implementation(const FString &InMapName)
{
	ExecSwitchMap(InMapName);
}

void ABSNPlayerController::ClientStartRespawnEffect_Implementation(const FString &Killer, float WaitTime)
{
	ABSNCharacter *Pawn = Cast<ABSNCharacter>(GetPawn());
	if (Pawn != NULL && RespawnEffect)
	{
		FVector CamLoc; 
		FRotator CamRotator;
		PlayerCameraManager->GetCameraViewPoint(CamLoc, CamRotator);
		FVector ViewDir = CamRotator.Vector();
		
		FVector Loc = Pawn->GetUIScene()->GetComponentLocation();
		FTransform ViewBillboard(CamRotator, Loc);

		ARespawnEffect *RespawnEffectActor = (ARespawnEffect *)GetWorld()->SpawnActor(RespawnEffect, &ViewBillboard);
		if (RespawnEffectActor != NULL)
		{
			RespawnEffectActor->AttachToComponent(Pawn->GetUIScene(), FAttachmentTransformRules::KeepWorldTransform);
			RespawnEffectActor->Start(this, Killer, WaitTime);
		}
	}
}

