#include "BlackShieldNetNative.h"
#include "BSNCharacterFloat.h"

ABSNCharacterFloat::ABSNCharacterFloat(const FObjectInitializer& ObjectInitializer /*= FObjectInitializer::Get()*/)
	: Super(ObjectInitializer)
{
	GetCapsuleComponent()->SetCollisionProfileName(TEXT("PlayerFly"));

	MovementController = CreateDefaultSubobject<UBSNMovementController>(TEXT("MovementController"));
}