// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "Character/BSNCharacterBase.h"
#include "Animation/BSNAnimInstance.h"
#include "Weapon/WeaponBag.h"
#include "BSNCharacter.generated.h"

USTRUCT(BlueprintType)
struct FBagUnit
{
	GENERATED_BODY()
	FBagUnit() { Count = 0; RowName = NAME_None; }
	FBagUnit(const FName &InInventoryName) { Count = 1; RowName = InInventoryName; }
	UPROPERTY()
	uint32	Count;
	UPROPERTY()
	FName	RowName;
};
USTRUCT(BlueprintType)
struct FWeaponCombine :public FTableRowBase
{
	GENERATED_USTRUCT_BODY()
public:
	//FWeaponCombine();

	UPROPERTY(EditDefaultsOnly, Category = WeaponStat)
	TSubclassOf<ABSNGun> FirstWeaponType;
	
	UPROPERTY(EditDefaultsOnly, Category = WeaponStat)
	TSubclassOf<ABSNGun> SecondWeaponType;
	
	UPROPERTY(EditDefaultsOnly, Category = WeaponStat)
	TSubclassOf<ABSNGun> CombineWeaponType;
};

USTRUCT(BlueprintType)
struct FCharacterHitInfo
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FVector AttackerLocation;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float Damage;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	int32 Count;
};

class ABSNGrenade;
class ABSNGun;
class ABSNHandGun;

UCLASS(config = Player, BlueprintType)
class ABSNCharacter : public ABSNCharacterBase
{
	GENERATED_BODY()

public:
	// Sets default values for this character's properties
	ABSNCharacter(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());
	virtual void OnConstruction(const FTransform& Transform) override;

	virtual void DoOnConstruction(const FTransform& Transform);

	virtual void FixesHMDOrientation();

	class USkeletalMeshComponent* GetSkeletalMesh() const { return SkeletalMesh; }

	UFUNCTION(BlueprintCallable, Category = "MotionController")
	void GetHandLocationAndRotation(EControllerHand Hand, FVector& Location, FRotator& Rotation) const;

	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

	virtual void Destroyed() override;

	virtual void Blink(const FVector& Destination);

	// Called every frame
	virtual void Tick( float DeltaSeconds ) override;

	// Called to bind functionality to input
	virtual void SetupPlayerInputComponent(class UInputComponent* InputComponent) override;

	virtual void HandleMoveForward(float AxisValue);
	virtual void HandleMoveRight(float AxisValue);
	void HandleTurn(float AxisValue);
	void HandleLookUp(float AxisValue);

	bool CanProcessInputEvent();

	void HandleStartCastSkill();
	void HandleStopCastSkill();

	void HandleStartLeftGrab();
	void HandleStopLeftGrab();
	void ShowWeaponBag();

	void HandleShowGameInfo();
	void HandleHideGameInfo();

	virtual void SetVehicleRelativeRotation(FRotator RelativeRotator);

	virtual void PostInitializeComponents() override;
	void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "HandleEvent")
	void HandleClientSetBodyTranslucent();

	virtual void HandleClientSetBodyTranslucent_Implementation();
	virtual void PossessedBy(AController* NewController) override;

	virtual void OnRep_Controller();
	virtual void PossessedInLocallyControlled();
	void EnableMotionControllers();

	UBSNAnimInstance *GetAnimInstance();
	class UBSNSkillManager* GetSkillManager() const { return SkillManager; }

	//class UBSNCharacterMovementComponent* GetBSNCharMovementComp() const { return BSNCharMovementComp; }

	// Gears
	void SetupHelmet();

	void DestroyHelmet();

	UFUNCTION(BlueprintCallable, Client, Reliable, Category = RPC)
	void ClientInitInGame();

	virtual void ClientInitInGame_Implementation();
	
	//Body
	UFUNCTION(BlueprintCallable, Category = "WeaponController")
	void OnStartFire();
	UFUNCTION(BlueprintCallable, Category = "WeaponController")
	void OnStopFire();

	//Weapon
	void EquipWeapon(ABSAttachableItem *pWeapon, bool bReplicated = false);

	void EquipWeapon(ABSAttachableItem *pWeapon, uint8 InSlot,bool bReplicated = false);

	void UnEquipWeapon(uint8 InSlot, bool bReplicated = false);
	UFUNCTION(Server, Reliable, WithValidation)
	void ServerSetupWeapon(ABSAttachableItem *pWeapon);
	UFUNCTION(Server, Reliable, WithValidation)
	void ServerUnEquipWeapon(uint8 InSlot);
	UFUNCTION()
	void OnRep_RightHandWeapon();
	UFUNCTION()
	void OnRep_LeftHandWeapon();
	void AttachWeapon(ABSAttachableItem *pWeapon);
	void DetachWeapon(ABSAttachableItem *pWeapon);
	
	//hand gun
	void CreateHandGun();
	UFUNCTION()
	void OnRep_HandGun();

	//Grenade
	void UseGrenade(ABSNGrenade *pGrenade, bool bReplicated = false);
	UFUNCTION(Server, Reliable, WithValidation)
	void ServerUseGrenade(ABSNGrenade *pGrenade);
	UFUNCTION()
	void OnRep_Grenade();
	void FireGrenade(bool bReplicated = false);
	UFUNCTION(Server, Reliable, WithValidation)
	void ServerFireGrenade();
	UFUNCTION()
	void OnRep_FireGrenade();
	void HideWeapon();
	void ShowWeapon();
	void FinishFireGrenade();

	UFUNCTION()
	void LeftHandEnter(UPrimitiveComponent* OverlapedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult & SweepResult);
	UFUNCTION()
	void LeftHandExit(UPrimitiveComponent* OverlapedComponent, AActor* OtherActor,  UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);
	UFUNCTION()
	void RightHandEnter(UPrimitiveComponent* OverlapedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult & SweepResult);
	UFUNCTION()
	void RightHandExit(UPrimitiveComponent* OverlapedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);
	UFUNCTION(BlueprintCallable, Category = Skill)
	virtual void TeleportToTarget(const FVector& TargetLocation);
	void StartTelportEffect();
	UFUNCTION(Unreliable, NetMulticast)
	void MulticastTeleportEffect();
	void SimulateTelportEffect();
	void UpdateTelportEffectMaterialIndex();
	
	//Bag
	void SaveItem(const FName &InName);
	void Drop(const FName &InName);
	uint32 GetItemCount(const FName &InName);
	FBagUnit *GetItem(const FName &InName);
	void DestroyItems();

	UFUNCTION()
	void LeftGrapItem();
	UFUNCTION()
	void RightGrapItem();
	//Health
	void GiveHealth(int32 Health);

	virtual void SetIsDying(bool bInIsDying) override;

	virtual void OnRep_IsDying(bool bOldIsDying) override;

	virtual void SetInvincible(bool bInInvincible) override;

	virtual void OnRep_Invincible(bool bOldInvincible) override;

	UFUNCTION(BlueprintCallable, Category = Pawn)
	virtual void StartGodEffect();

	UFUNCTION(BlueprintCallable, Category = Pawn)
	virtual void StopGodEffect();

	//Start wait
	UFUNCTION(Reliable, Client)
	void ClientStartWait(float WaitTime);

	//Weapon Combine
	UFUNCTION(BlueprintCallable, Category = "WeaponCombine")
	ABSNGun *WeaponCombine(ABSNGun *FirstWeapon, ABSNGun *SecondWeapon);
	UFUNCTION(BlueprintCallable,Category = "WeaponCombine")
	static bool GetWeaponCombineType(ABSNGun *FirstWeapon, ABSNGun *SecondWeapon, TSubclassOf<ABSNGun>& CombinedWeaponType);
	static TArray<TSubclassOf<ABSNGun>> GetWeaponCombineDataTableArray();
	static bool FindElementFromWeaponCombineArray(TSubclassOf<ABSNGun> WeaponType,FName &RowName);

	void UpdateCombineTime(float DeltaTime);
	bool GetWeaponsCanCombine(ABSAttachableItem* RightWeapon, ABSAttachableItem* LeftWeapon);
	UFUNCTION(BlueprintCallable, Category = "WeaponCombine")
	TArray<FName> GetWeaponRowNameArray();

	virtual float TakeDamage(float Damage, struct FDamageEvent const& DamageEvent, AController* EventInstigator, AActor* DamageCauser) override;
	virtual void HandleHealthDamaged(float Damage, struct FDamageEvent const& DamageEvent, class AController* EventInstigator, class AActor* DamageCauser) override;
	virtual void Die(float Damage, struct FDamageEvent const& DamageEvent, class AController* EventInstigator, class AActor* DamageCauser) override;
	virtual bool CanDie(float Damage, struct FDamageEvent const& DamageEvent, class AController* EventInstigator, class AActor* DamageCauser) override;
	virtual void CharacterHit(float Damage, struct FDamageEvent const& DamageEvent, class AController* EventInstigator, class AActor* DamageCauser) override;
	virtual void OnHealthModified(int32 OldHealth) override;

	UFUNCTION()
	virtual void OnRep_CharacterHitInfo();

	UFUNCTION()
	virtual void OnRep_HeroName(const FString& OldHeroName);

	void ChangeHero(const FString& InHeroName);

	UFUNCTION(Server, Reliable, WithValidation, Category = "Hero")
	void ServerChangeHero(const FString& InHeroName);

	virtual bool ServerChangeHero_Validate(const FString& InHeroName);
	virtual void ServerChangeHero_Implementation(const FString& InHeroName);
	void ChangeHeroMesh(const FString& InHeroName);
	void ClearSkeletalMeshMaterials();

	USceneComponent *GetUIScene() { return UIScene; }
	void GetCameraLocationAndRotation(FVector &Location,FRotator &Rotation);

	UFUNCTION(BlueprintCallable, Category = "Pawn")
	FTransform GetHeadTransform();

	virtual void PostRenderFor(APlayerController *PC, UCanvas *Canvas, FVector CameraPosition, FVector CameraDir) override;
protected:
	uint32 bInOnConstruction;
	uint32 bOnConstructionProcessed;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, ReplicatedUsing = OnRep_CharacterHitInfo)
	FCharacterHitInfo CharacterHitInfo;

protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Pawn)
	uint32 bWantsToFire:1;

	bool bInPossingHMD;

	float CombineTime;

	uint8 bShowWeaponBag:1;
protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Camera)
	class UCameraComponent* PlayerCamera;

	UPROPERTY(VisibleDefaultsOnly, BlueprintReadOnly, Category = Mesh)
	class USkeletalMeshComponent* SkeletalMesh;

	//UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Character)
	//class UBSNCharacterMovementComponent* BSNCharMovementComp;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Movement")
	class UBSNMovementController* MovementController;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	class UBSNSkillManager* SkillManager;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "FirstPersonView")
	class USceneComponent* Scene1P;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "FirstPersonView")
	class UVRMotionControllerComponent* MotionControllerLeft;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "FirstPersonView")
	class UVRMotionControllerComponent* MotionControllerRight;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "UI")
	class USceneComponent *UIScene;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Effect")
	class UParticleSystemComponent* ParticleBloodReturn;


	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Gear")
	TSubclassOf<class AHelmetActor> HelmetClass;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Gear")
	class AHelmetActor* Helmet;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, ReplicatedUsing=OnRep_HeroName, Category = "Hero")
	FString HeroName;

	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	TSubclassOf<class ABSNHandGun> HandGunClass;

	UPROPERTY(Transient, VisibleAnywhere, BlueprintReadOnly, Category = Mesh)
	TArray<class UMaterialInstanceDynamic*> SkeletalDynamicMaterials;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "UI")
	AActor *LeftHandOverlapActor;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "UI")
	AActor *RightHandOverlapActor;

	FTimerHandle	TimerHandler_FinishTeleportEffect;
public:
	UPROPERTY(Transient, BlueprintReadOnly, ReplicatedUsing = OnRep_LeftHandWeapon)
	ABSAttachableItem		*LeftHandWeapon;
	UPROPERTY(Transient, BlueprintReadOnly, ReplicatedUsing = OnRep_RightHandWeapon)
	ABSAttachableItem		*RightHandWeapon;
	UPROPERTY(Transient, ReplicatedUsing = OnRep_Grenade)
	ABSNGrenade				*Grenade;
	UPROPERTY(Transient, ReplicatedUsing = OnRep_HandGun)
	ABSNHandGun				*AutoHandGun;
	UPROPERTY(Transient, ReplicatedUsing = OnRep_FireGrenade)
	uint32					FireGrenadeCount;
	FTimerHandle			TimeHandle_AutoWeaponAfterGrenade;
	UPROPERTY(Transient, Replicated)
	TArray<FBagUnit>		InventoryItems;
	UPROPERTY(EditAnywhere, Category = WeaponCombine)
	float					MaxCombineTime;
	UPROPERTY(EditAnywhere, Category = WeaponCombine)
	float					MaxCombineLengthSquared;
	UPROPERTY(EditAnywhere)
	UStaticMeshComponent *RadialBlurComponent;
	UPROPERTY()
	class UWeaponBag*		WeaponBagComponent;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly,Category = WeaponCombine)
	USphereComponent* LeftHandTriggerBox;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = WeaponCombine)
	USphereComponent* RightHandTriggerBox;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Effect")
	UParticleSystemComponent *TeleportTrailEffect;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Effect")
	TArray<UMaterialInterface *> ColorsInstance;
};

