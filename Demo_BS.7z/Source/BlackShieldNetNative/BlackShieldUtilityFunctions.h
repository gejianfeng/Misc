#pragma once

#include "BSNLevelStreamingHelperDefinitions.h"

namespace BSNUtils
{
	template<typename T>
	T* GetTypedGameInstance(UObject* WorldContextObject)
	{
		UWorld* World = GEngine->GetWorldFromContextObject(WorldContextObject);
		T* ResultGameInstance = Cast<T>(World->GetGameInstance());

		return ResultGameInstance;
	}

	class UBlackShieldGameInstance* GetBSNGameInstance(UObject* WorldContextObject);
	
	void LoadStreamLevel(UObject* WorldContextObject, FName LevelName, bool bMakeVisibleAfterLoad, bool bShouldBlockOnLoad, const FBSNLevelStreamingActionComplete& InDelegate = nullptr);
	
	void UnloadStreamLevel(UObject* WorldContextObject, FName LevelName, const FBSNLevelStreamingActionComplete& InDelegate = nullptr);
}
