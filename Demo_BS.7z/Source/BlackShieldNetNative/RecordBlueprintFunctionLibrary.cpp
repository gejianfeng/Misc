// Fill out your copyright notice in the Description page of Project Settings.

#include "BlackShieldNetNative.h"
#include "RecordBlueprintFunctionLibrary.h"

bool LoadStringArrayfromFile(TArray<FString>& StringArray, int32& ArraySize, FString FullFilePath, bool ExcludeEmptyLines) {


	ArraySize = 0;

	if (FullFilePath == "" || FullFilePath == " ") return false;

	//Empty any previous contents!
	StringArray.Empty();

	TArray<FString> FileArray;

	if (!FFileHelper::LoadANSITextFileToStrings(*FullFilePath, NULL, FileArray))
	{
		return false;
	}

	if (ExcludeEmptyLines)
	{
		for (const FString& Each : FileArray)
		{
			if (Each == "") continue;
			//~~~~~~~~~~~~~

			//check for any non whitespace
			bool FoundNonWhiteSpace = false;
			for (int32 v = 0; v < Each.Len(); v++)
			{
				if (Each[v] != ' ' && Each[v] != '\n')
				{
					FoundNonWhiteSpace = true;
					break;
				}
				//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
			}

			if (FoundNonWhiteSpace)
			{
				StringArray.Add(Each);
			}
		}
	}
	else
	{
		StringArray.Append(FileArray);
	}

	ArraySize = StringArray.Num();
	return true;
}

void String__ExplodeString(TArray<FString>& OutputStrings, FString InputString, FString Separator, int32 limit, bool bTrimElements)
{
	OutputStrings.Empty();
	//~~~~~~~~~~~

	if (InputString.Len() > 0 && Separator.Len() > 0) {
		int32 StringIndex = 0;
		int32 SeparatorIndex = 0;

		FString Section = "";
		FString Extra = "";

		int32 PartialMatchStart = -1;

		while (StringIndex < InputString.Len()) {

			if (InputString[StringIndex] == Separator[SeparatorIndex]) {
				if (SeparatorIndex == 0) {
					//A new partial match has started.
					PartialMatchStart = StringIndex;
				}
				Extra.AppendChar(InputString[StringIndex]);
				if (SeparatorIndex == (Separator.Len() - 1)) {
					//We have matched the entire separator.
					SeparatorIndex = 0;
					PartialMatchStart = -1;
					if (bTrimElements == true) {
						OutputStrings.Add(FString(Section).Trim().TrimTrailing());
					}
					else {
						OutputStrings.Add(FString(Section));
					}

					//if we have reached the limit, stop.
					if (limit > 0 && OutputStrings.Num() >= limit)
					{
						return;
						//~~~~
					}

					Extra.Empty();
					Section.Empty();
				}
				else {
					++SeparatorIndex;
				}
			}
			else {
				//Not matched.
				//We should revert back to PartialMatchStart+1 (if there was a partial match) and clear away extra.
				if (PartialMatchStart >= 0) {
					StringIndex = PartialMatchStart;
					PartialMatchStart = -1;
					Extra.Empty();
					SeparatorIndex = 0;
				}
				Section.AppendChar(InputString[StringIndex]);
			}

			++StringIndex;
		}

		//If there is anything left in Section or Extra. They should be added as a new entry.
		if (bTrimElements == true) {
			OutputStrings.Add(FString(Section + Extra).Trim().TrimTrailing());
		}
		else {
			OutputStrings.Add(FString(Section + Extra));
		}

		Section.Empty();
		Extra.Empty();
	}
}



void URecordBlueprintFunctionLibrary::LoadRecored(FString FileName, TArray<float>& Atime, TArray<FVector>& AHeadLoc, TArray<FRotator>& AHeadRot,
	TArray<FVector>& AHandLoc_L, TArray<FRotator>& AHandRot_L,
	TArray<FVector>& AHandLoc_R, TArray<FRotator>& AHandRot_R)
{
	TArray<FString> stringArray;
	int32 size = 0;
	FString path("Recored.txt");
	path = FPaths::ConvertRelativePathToFull(FPaths::GameDir()) + FileName;
	LoadStringArrayfromFile(stringArray, size, path, true);

	int count = stringArray.Num();
	//UE_LOG(TestSpeed, Verbose, TEXT("Array Count(%d)."), count);
	for (int i = 0; i < count; i++)
	{
		FString elment = stringArray[i];
		TArray<FString> s, ss;
		String__ExplodeString(s, elment, "|", 0, false);

		if (s.Num() > 1)
		{
			Atime.Add(FCString::Atof(*s[0]));
			String__ExplodeString(ss, s[1], ";", 0, false);

			if (ss.Num() < 6) {
				continue;
			}
			FVector HeadLoc;
			HeadLoc.InitFromString(ss[0]);
			AHeadLoc.Add(HeadLoc);
			FRotator HeadRot;
			HeadRot.InitFromString(ss[1]);
			AHeadRot.Add(HeadRot);
			FVector HandLoc_L;
			HandLoc_L.InitFromString(ss[2]);
			AHandLoc_L.Add(HandLoc_L);
			FRotator HandRot_L;
			HandRot_L.InitFromString(ss[3]);
			AHandRot_L.Add(HandRot_L);
			FVector HandLoc_R;
			HandLoc_R.InitFromString(ss[4]);
			AHandLoc_R.Add(HandLoc_R);
			FRotator HandRot_R;
			HandRot_R.InitFromString(ss[5]);
			AHandRot_R.Add(HandRot_R);
		}
	}
}

bool FileIO__SaveStringArrayToFile(FString SaveDirectory, FString JoyfulFileName, TArray<FString> SaveText, bool AllowOverWriting)
{
	//Dir Exists?
	if (!FPlatformFileManager::Get().GetPlatformFile().DirectoryExists(*SaveDirectory))
	{
		//create directory if it not exist
		FPlatformFileManager::Get().GetPlatformFile().CreateDirectory(*SaveDirectory);

		//still could not make directory?
		if (!FPlatformFileManager::Get().GetPlatformFile().DirectoryExists(*SaveDirectory))
		{
			//Could not make the specified directory
			return false;
			//~~~~~~~~~~~~~~~~~~~~~~
		}
	}

	//get complete file path
	SaveDirectory += "\\";
	SaveDirectory += JoyfulFileName;

	//No over-writing?
	if (!AllowOverWriting)
	{
		//Check if file exists already
		if (FPlatformFileManager::Get().GetPlatformFile().FileExists(*SaveDirectory))
		{
			//no overwriting
			return false;
		}
	}

	FString FinalStr = "";
	for (FString& Each : SaveText)
	{
		FinalStr += Each;
		FinalStr += LINE_TERMINATOR;
	}



	return FFileHelper::SaveStringToFile(FinalStr, *SaveDirectory);

}

void URecordBlueprintFunctionLibrary::SaveRecored(FString FileName, TArray<float> ATime, TArray<FVector> AHeadLoc, TArray<FRotator> AHeadRot,
	TArray<FVector> AHandLoc_L, TArray<FRotator> AHandRot_L,
	TArray<FVector> AHandLoc_R, TArray<FRotator> AHandRot_R)
{
	int count = ATime.Num();
	TArray<FString> SaveTextArray;
	for (int i = 0; i < count; i++) {
		FString s;
		s.Append(FString::SanitizeFloat(ATime[i])).Append("|")
			.Append(AHeadLoc[i].ToString()).Append(";")
			.Append(AHeadRot[i].ToString()).Append(";")
			.Append(AHandLoc_L[i].ToString()).Append(";")
			.Append(AHandRot_L[i].ToString()).Append(";")
			.Append(AHandLoc_R[i].ToString()).Append(";")
			.Append(AHandRot_R[i].ToString());
		SaveTextArray.Add(s);
	}
	FileIO__SaveStringArrayToFile(FPaths::ConvertRelativePathToFull(FPaths::GameDir()), FileName, SaveTextArray, true);
}