#pragma once

#include "BSNEngine.generated.h"

UCLASS()
class BLACKSHIELDNETNATIVE_API UBSNEngine :public UGameEngine
{
	GENERATED_UCLASS_BODY()
	virtual void Init(IEngineLoop* InEngineLoop) override;
	virtual void PreExit() override;
public:
	virtual void HandleNetworkFailure(UWorld *World, UNetDriver *NetDriver, ENetworkFailure::Type FailureType, const FString& ErrorString) override;
};

