// Fill out your copyright notice in the Description page of Project Settings.

#include "BlackShieldNetNative.h"
#include "BSNCharacterZerg.h"

ABSNCharacterZerg::ABSNCharacterZerg(const FObjectInitializer& ObjectInitializer /*= FObjectInitializer::Get()*/)
	: Super(ObjectInitializer)
{
	
}

void ABSNCharacterZerg::StartSingleFire()
{
	if (Role == ROLE_Authority)
	{
		FVector FireTrace, FireEnd, FireDir;
		GetFireLocationAndDirection(FireTrace, FireDir);
		FireEnd = FireTrace + FireDir * Config.AttackRange;

		const FHitResult Impact = FireLineTrace(FireTrace, FireEnd);
		ProcessHit(Impact, FireTrace, FireDir);
	}
}