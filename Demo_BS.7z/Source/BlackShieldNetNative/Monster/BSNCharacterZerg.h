// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "BSNCharacterMonster.h"
#include "BSNCharacterZerg.generated.h"

/**
 * 
 */
UCLASS()
class ABSNCharacterZerg : public ABSNCharacterMonster
{
	GENERATED_BODY()
	
public:
	ABSNCharacterZerg(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());

	virtual void StartSingleFire() override;
};
