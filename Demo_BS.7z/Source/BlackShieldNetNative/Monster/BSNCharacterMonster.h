// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "Character/BSNCharacterBase.h"
#include "BSNCharacterMonster.generated.h"

//////////////////////////////////////////////////////////////////////////

USTRUCT(BlueprintType)
struct FMonsterDataRow :public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

public:
	FMonsterDataRow();

	UPROPERTY(EditAnywhere, Category = Pawn)
	int32		MaxHealth;
	
	UPROPERTY(EditAnywhere, Category = Pawn)
	int32		HitDamage;
	
	UPROPERTY(EditAnywhere, Category = Pawn)
	float		AttackRange;
};

//////////////////////////////////////////////////////////////////////////

/**
 * 
 */
UCLASS()
class ABSNCharacterMonster : public ABSNCharacterBase
{
	GENERATED_BODY()
	
public:
	ABSNCharacterMonster(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());
	
	virtual void PostInitializeComponents() override;
	virtual void InitCharAttributes() override;
	FMonsterDataRow* GetRow(FName& name);

	virtual void GetFireLocationAndDirection(FVector &OutLocation, FVector &OutDirection);
	FHitResult FireLineTrace(const FVector &StartTrace, const FVector &EndTrace);

	void ProcessHit(const FHitResult &Impact, const FVector &StartTrace, const FVector &ShootDir);
	void DealDamage(const FHitResult &Impact, const FVector &ShootDir);

	// Single Attack
	UFUNCTION(BlueprintCallable, Category = "Attack")
	void OnStartSingleFire();
	
	virtual void StartSingleFire();

protected:
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = Config)
	FName	ConfigName;

	UPROPERTY(EditDefaultsOnly, Category = Config)
	FMonsterDataRow Config;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = Config)
	float	CloseAttackRange;
};
