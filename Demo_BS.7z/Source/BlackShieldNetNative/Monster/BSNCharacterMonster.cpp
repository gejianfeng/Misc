// Fill out your copyright notice in the Description page of Project Settings.

#include "BlackShieldNetNative.h"
#include "BSNCharacterMonster.h"

#define ECC_MonsterFireChannel  ECC_GameTraceChannel6
//////////////////////////////////////////////////////////////////////////

FMonsterDataRow::FMonsterDataRow()
{
	MaxHealth = 100;
	HitDamage = 10;
	AttackRange = 10.0f;
}

//////////////////////////////////////////////////////////////////////////

ABSNCharacterMonster::ABSNCharacterMonster(const FObjectInitializer& ObjectInitializer /*= FObjectInitializer::Get()*/)
	: Super(ObjectInitializer)
{
	CloseAttackRange = 100.0f;
}

void ABSNCharacterMonster::PostInitializeComponents()
{
	Super::PostInitializeComponents();

	InitCharAttributes();
}

void ABSNCharacterMonster::InitCharAttributes()
{
	Super::InitCharAttributes();

	Config = *GetRow(ConfigName);

	if (Role == ROLE_Authority)
	{
		MaxHealth = Config.MaxHealth;
		CloseAttackRange = Config.AttackRange;
		Health = MaxHealth;
		bIsDying = false;
	}
}

void ABSNCharacterMonster::OnStartSingleFire()
{
	StartSingleFire();
}

void ABSNCharacterMonster::StartSingleFire()
{
	
}

void ABSNCharacterMonster::GetFireLocationAndDirection(FVector &OutLocation, FVector &OutDirection)
{
	OutLocation = this->GetActorLocation();
	OutDirection = this->GetActorForwardVector();
}

void ABSNCharacterMonster::ProcessHit(const FHitResult &Impact, const FVector &StartTrace, const FVector &ShootDir)
{
	AActor *TestActor = Impact.GetActor();

	if (TestActor)
	{
		DealDamage(Impact, ShootDir);
	}
}

void ABSNCharacterMonster::DealDamage(const FHitResult &Impact, const FVector &ShootDir)
{
	FPointDamageEvent PointDamage;
	PointDamage.DamageTypeClass = NULL;
	PointDamage.HitInfo = Impact;
	PointDamage.ShotDirection = ShootDir;
	PointDamage.Damage = Config.HitDamage;
	Impact.GetActor()->TakeDamage(PointDamage.Damage, PointDamage, this->GetController(), this);
}

FHitResult ABSNCharacterMonster::FireLineTrace(const FVector &StartTrace, const FVector &EndTrace)
{
	static FName FireTraceTag = FName(TEXT("FireTrace"));

	FCollisionQueryParams TraceParams(FireTraceTag, true, this);
	TraceParams.bTraceAsyncScene = true;
	TraceParams.bReturnPhysicalMaterial = true;
	TraceParams.AddIgnoredActor(this);

	FHitResult Hit(ForceInit);
	GetWorld()->LineTraceSingleByChannel(Hit, StartTrace, EndTrace, ECC_MonsterFireChannel, TraceParams);

	return Hit;
}

FMonsterDataRow* ABSNCharacterMonster::GetRow(FName& name)
{
	UDataTable *pConfigTable = (UDataTable *)StaticLoadObject(UDataTable::StaticClass(), NULL, TEXT("DataTable'/Game/BlackShieldNew/Table/DT_Monster.DT_Monster'"));
	if (pConfigTable != NULL)
	{
		FMonsterDataRow *pConfigData = pConfigTable->FindRow<FMonsterDataRow>(name, TEXT(""));
		return pConfigData;
	}
	return NULL;
}