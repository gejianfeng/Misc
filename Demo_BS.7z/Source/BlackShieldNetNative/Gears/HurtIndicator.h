#pragma once

#include "HurtIndicator.generated.h"

UCLASS(Blueprintable)
class AHurtIndicator : public AActor
{
	GENERATED_BODY()
public:
	AHurtIndicator();

	void SetOwningCharater(class ABSNCharacter* Character);

	virtual void Tick(float DeltaSeconds) override;

	bool IsIndicatorShown() const { return bIndicatorShown; }

	void ShowIndicator(const FVector& AttackerLocation);

	void UpdateIndicator();

protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	class ABSNCharacter* OwningCharacter;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	FVector LastAttackerLocation;

protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Components)
	class USceneComponent* SceneRoot;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Components)
	class USceneComponent* MeshMount;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Components)
	class UStaticMeshComponent* Mesh;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = HurtIndicator)
	float Radius;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = HurtIndicator)
	float IndicatorKeepTime;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = HurtIndicator)
	float IndicatorRemainingTime;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = HurtIndicator)
	bool bIndicatorShown;
};
