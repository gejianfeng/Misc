#include "BlackShieldNetNative.h"
#include "HurtIndicator.h"
#include "Player/BSNCharacter.h"

AHurtIndicator::AHurtIndicator()
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickGroup = TG_PostPhysics;

	SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
	SetRootComponent(SceneRoot);

	MeshMount = CreateDefaultSubobject<USceneComponent>(TEXT("MeshMount"));
	MeshMount->SetupAttachment(SceneRoot);
	MeshMount->RelativeRotation = FRotator(90, 0, 0);

	Mesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Mesh"));
	Mesh->SetupAttachment(MeshMount);
	Mesh->bHiddenInGame = true;

	Radius = 6;
	IndicatorKeepTime = 1.5f;

	IndicatorRemainingTime = 0;

	bIndicatorShown = false;
}

void AHurtIndicator::SetOwningCharater(class ABSNCharacter* Character)
{
	SetOwner(Character);

	OwningCharacter = Character;
}

void AHurtIndicator::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	if (bIndicatorShown)
	{
		IndicatorRemainingTime -= DeltaSeconds;
		if (IndicatorRemainingTime <= 0.0f)
		{
			IndicatorRemainingTime = 0;
			bIndicatorShown = false;
			Mesh->SetHiddenInGame(true, true);
		}
		else
		{
			UpdateIndicator();
		}
	}
}

void AHurtIndicator::ShowIndicator(const FVector& AttackerLocation)
{
	if (!OwningCharacter)
		return;

	LastAttackerLocation = AttackerLocation;

	bIndicatorShown = true;
	IndicatorRemainingTime = IndicatorKeepTime;

	Mesh->SetHiddenInGame(false, true);
	UpdateIndicator();
}

void AHurtIndicator::UpdateIndicator()
{
	FVector PlayerCharLocation = OwningCharacter->GetSkeletalMesh()->GetComponentLocation();
	FRotator PlayerViewRotator;
	{
		FVector UnusedParam;
		OwningCharacter->GetCameraLocationAndRotation(UnusedParam, PlayerViewRotator);
	}

	FVector PlayerToAttackerDir = (LastAttackerLocation - PlayerCharLocation).GetSafeNormal();
	PlayerToAttackerDir.Z = 0;
	FRotator Rotation(0, PlayerViewRotator.Yaw, 0);
	PlayerToAttackerDir = Rotation.UnrotateVector(PlayerToAttackerDir);
	PlayerToAttackerDir.Normalize();

	FVector IndicatorLocation = PlayerToAttackerDir * Radius;
	IndicatorLocation.Z = 0;

	FRotator IndicatorRotation = (-PlayerToAttackerDir).ToOrientationRotator();

	Mesh->SetRelativeLocation(IndicatorLocation);
	Mesh->SetRelativeRotation(IndicatorRotation);
}
