#include "BlackShieldNetNative.h"
#include "HelmetActor.h"
#include "HurtIndicator.h"

AHelmetActor::AHelmetActor()
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickGroup = TG_PostPhysics;

	SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
	SetRootComponent(SceneRoot);

	Helmet = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Helmet"));
	Helmet->SetCollisionProfileName(TEXT("NoCollision"));
	Helmet->SetupAttachment(SceneRoot);

	FaceMask = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("FaceMask"));
	FaceMask->SetCollisionProfileName(TEXT("NoCollision"));
	FaceMask->SetupAttachment(Helmet);

	BP_3DHUDLife = CreateDefaultSubobject<UChildActorComponent>(TEXT("BP_3DHUDLife"));
	BP_3DHUDLife->SetupAttachment(Helmet);

	DeathEffect = CreateDefaultSubobject<UParticleSystemComponent>(TEXT("DeathEffect"));
	DeathEffect->SetupAttachment(Helmet);

	BP_HurtArrowMgr = CreateDefaultSubobject<UChildActorComponent>(TEXT("BP_HurtArrowMgr"));
	BP_HurtArrowMgr->SetupAttachment(Helmet);
}

void AHelmetActor::SetOwningCharacter(class ABSNCharacter* OwningChar)
{
	SetOwner(OwningChar);

	OwningCharacter = OwningChar;

	if (HurtIndicator)
	{
		HurtIndicator->SetOwningCharater(OwningChar);
	}
}

void AHelmetActor::OnConstruction(const FTransform& Transform)
{
	Super::OnConstruction(Transform);

	Mask_DMI_Hurt = FaceMask->CreateDynamicMaterialInstance(0);

	if (Mask_DMI_Hurt)
	{
		Mask_DMI_Hurt->SetScalarParameterValue(TEXT("DisplayValue"), 0);
	}
}

void AHelmetActor::PostInitializeComponents()
{
	Super::PostInitializeComponents();

	HurtIndicator = Cast<AHurtIndicator>(BP_HurtArrowMgr->GetChildActor());
}

void AHelmetActor::ShowHurtIndicator(const FVector& AttackerLocation)
{
	if (HurtIndicator)
	{
		HurtIndicator->ShowIndicator(AttackerLocation);
	}
}
