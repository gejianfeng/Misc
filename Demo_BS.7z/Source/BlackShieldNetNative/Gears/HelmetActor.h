#pragma once

#include "HelmetActor.generated.h"

UCLASS(Blueprintable, Abstract)
class AHelmetActor : public AActor
{
	GENERATED_BODY()

public:
	AHelmetActor();

	void SetOwningCharacter(class ABSNCharacter* OwningChar);

	virtual void OnConstruction(const FTransform& Transform) override;

	virtual void PostInitializeComponents() override;

	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = Health)
	void SetHp(float CurrentHealth, float MaxHealth);

	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = Health)
	void FatalToDying();

	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = Health)
	void PutOn();

	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = Health)
	void GetHurt(bool bIsHurt);

	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = Health)
	void DisplayAttackArrow(const FVector& HitVector, const FVector& ForwardVector);

	UFUNCTION(BlueprintCallable, Category = Health)
	void ShowHurtIndicator(const FVector& AttackerLocation);

protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Owner)
	class ABSNCharacter* OwningCharacter;

protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Components)
	USceneComponent* SceneRoot;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Components)
	UStaticMeshComponent* Helmet;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Components)
	UStaticMeshComponent* FaceMask;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Components)
	UChildActorComponent* BP_3DHUDLife;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Components)
	UParticleSystemComponent* DeathEffect;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Components)
	UChildActorComponent* BP_HurtArrowMgr;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Helmet)
	class AHurtIndicator* HurtIndicator;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Helmet)
	class UMaterialInstanceDynamic* Mask_DMI_Hurt;
};
