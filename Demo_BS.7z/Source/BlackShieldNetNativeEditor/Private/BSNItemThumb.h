// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "Weapon/BSNITem.h"
#include "ThumbnailRendering/DefaultSizedThumbnailRenderer.h"
#include "ThumbnailHelpers.h"
#include "BSNItemThumb.generated.h"

class FBNSBlueprintThumbnailScene : public FClassActorThumbnailScene
{
public:
	FBNSBlueprintThumbnailScene();
	void SetBlueprint(class UBlueprint* Blueprint);
	void BlueprintChanged(class UBlueprint* Blueprint);
protected:
	void UpdateSpawnActor();
	virtual USceneThumbnailInfo* GetSceneThumbnailInfo(const float TargetDistance) const override;
private:
	UBlueprint* CurrentBlueprint;
	void *PreviewItemActorWeakObjPtrMadness;
};

UCLASS(config = Editor)
class UBSNBlueprintThumbnailRenderer : public UDefaultSizedThumbnailRenderer
{
	GENERATED_UCLASS_BODY()
	virtual bool CanVisualizeAsset(UObject* Object) override;
	virtual void Draw(UObject* Object, int32 X, int32 Y, uint32 Width, uint32 Height, FRenderTarget*, FCanvas* Canvas) override;
	virtual void BeginDestroy() override;
	void BlueprintChanged(class UBlueprint* Blueprint);
protected:
	bool CanVisualizeAssetNormal(UBlueprint* Blueprint);
	void DrawNormal(UBlueprint* Blueprint, int32 X, int32 Y, uint32 Width, uint32 Height, FRenderTarget*, FCanvas* Canvas);
private:
	class FBNSBlueprintThumbnailScene* ThumbnailScene;
};


