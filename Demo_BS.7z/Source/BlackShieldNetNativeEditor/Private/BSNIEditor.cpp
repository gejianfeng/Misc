
#include "BlackShieldNetNativeEditorPrivatePCH.h"
#include "IBSNEditorModule.h"
#include "Weapon/BSNITem.h"
#include "BSNItemThumb.h"

class FBSNEditorModule : public IBNSEditorModuleInterface
{
public:
	virtual void StartupModule() override
	{
		UThumbnailManager::Get().RegisterCustomRenderer(UBlueprint::StaticClass(), UBSNBlueprintThumbnailRenderer::StaticClass());
	}

	virtual void ShutdownModule() override
	{
	}
};

IMPLEMENT_MODULE(FBSNEditorModule, BlackShieldNetNativeEditor);

