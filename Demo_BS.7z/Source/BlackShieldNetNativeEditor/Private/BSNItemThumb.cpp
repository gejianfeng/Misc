
#include "BlackShieldNetNativeEditorPrivatePCH.h"
#include "BSNItemThumb.h"
#include "Weapon/BSNITem.h"
#include "EngineModule.h"

FBNSBlueprintThumbnailScene::FBNSBlueprintThumbnailScene()
	: FClassActorThumbnailScene()
	, CurrentBlueprint(nullptr)
{
}

void FBNSBlueprintThumbnailScene::SetBlueprint(UBlueprint* Blueprint)
{
	CurrentBlueprint = Blueprint;
	UpdateSpawnActor();
}

void FBNSBlueprintThumbnailScene::BlueprintChanged(class UBlueprint* Blueprint)
{
	UpdateSpawnActor();
}

void FBNSBlueprintThumbnailScene::UpdateSpawnActor()
{
	ABSNItem *pItem = Cast<ABSNItem>(CurrentBlueprint->GeneratedClass->GetDefaultObject());
	if (pItem != NULL)
	{
		TWeakObjectPtr<ABSNItem>& PreviewActor = *((TWeakObjectPtr<ABSNItem>*)&PreviewItemActorWeakObjPtrMadness);
		if (PreviewActor.IsValid())
		{
			PreviewActor->Destroy();
			PreviewActor = nullptr;
		}

		// Create preview actor
		FActorSpawnParameters SpawnInfo;
		SpawnInfo.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
		SpawnInfo.bNoFail = true;
		SpawnInfo.ObjectFlags = RF_Transient;
		PreviewActor = GetWorld()->SpawnActor<ABSNItem>(CurrentBlueprint->GeneratedClass, SpawnInfo);
		
		if (PreviewActor.IsValid())
		{
			UStaticMeshComponent *MeshComponent = PreviewActor->WeaponMeshComponent;
			MeshComponent->SetStaticMesh(pItem->Mesh);
			
			FBoxSphereBounds Bounds(ForceInitToZero);
			TArray<USceneComponent*> PreviewComponents;
			PreviewActor->GetRootComponent()->GetChildrenComponents(true, PreviewComponents);
			PreviewComponents.Add(PreviewActor->GetRootComponent());
			for (USceneComponent* PreviewComponent : PreviewComponents)
			{
				if (IsValidComponentForVisualization(PreviewComponent))
				{
					Bounds = Bounds + PreviewComponent->Bounds;
				}
			}

			const float BoundsZOffset = GetBoundsZOffset(Bounds);
			if (Bounds.BoxExtent.Z > 0)
			{
				float Scale = 4.0f / Bounds.BoxExtent.Z;
				FTransform Transform(FQuat::Identity, FVector(0), FVector(Scale));
				PreviewActor->SetActorTransform(Transform);
			}
		}
	}
	else
	{
		UClass* BPClass = (CurrentBlueprint ? CurrentBlueprint->GeneratedClass : nullptr);
		SpawnPreviewActor(BPClass);
	}
}

USceneThumbnailInfo* FBNSBlueprintThumbnailScene::GetSceneThumbnailInfo(const float TargetDistance) const
{
	check(CurrentBlueprint);
	USceneThumbnailInfo* ThumbnailInfo = Cast<USceneThumbnailInfo>(CurrentBlueprint->ThumbnailInfo);
	if (ThumbnailInfo)
	{
		if (TargetDistance + ThumbnailInfo->OrbitZoom < 0)
		{
			ThumbnailInfo->OrbitZoom = -TargetDistance;
		}
	}
	else
	{
		ThumbnailInfo = USceneThumbnailInfo::StaticClass()->GetDefaultObject<USceneThumbnailInfo>();
	}

	return ThumbnailInfo;
}

//////////////////////////////////////////////////////////////////////////
UBSNBlueprintThumbnailRenderer::UBSNBlueprintThumbnailRenderer(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	ThumbnailScene = nullptr;
}

bool UBSNBlueprintThumbnailRenderer::CanVisualizeAsset(UObject* Object)
{
	if (ThumbnailScene == nullptr)
	{
		ThumbnailScene = new FBNSBlueprintThumbnailScene();
	}

	bool bCanVisualize = false;
	UBlueprint* Blueprint = Cast<UBlueprint>(Object);

	if (Blueprint != NULL && Blueprint->GeneratedClass)
	{
		ABSNItem *pDefItem = Cast<ABSNItem>(Blueprint->GeneratedClass->GetDefaultObject());
		if (pDefItem != NULL)
		{
			bCanVisualize = true;
		}
		else
		{
			bCanVisualize = CanVisualizeAssetNormal(Blueprint);
		}
	}

	return bCanVisualize;
}

void UBSNBlueprintThumbnailRenderer::Draw(UObject* Object, int32 X, int32 Y, uint32 Width, uint32 Height, FRenderTarget* RenderTarget, FCanvas* Canvas)
{
	UBlueprint* Blueprint = Cast<UBlueprint>(Object);
	if (Blueprint != NULL)
	{
		DrawNormal(Blueprint, X, Y, Width, Height, RenderTarget, Canvas);
	}
}

void UBSNBlueprintThumbnailRenderer::BeginDestroy()
{
	if (ThumbnailScene != nullptr)
	{
		delete ThumbnailScene;
		ThumbnailScene = nullptr;
	}

	Super::BeginDestroy();
}

void UBSNBlueprintThumbnailRenderer::BlueprintChanged(class UBlueprint* Blueprint)
{
	if (ThumbnailScene != nullptr)
	{
		ThumbnailScene->BlueprintChanged(Blueprint);
	}
}

bool UBSNBlueprintThumbnailRenderer::CanVisualizeAssetNormal(UBlueprint* Blueprint)
{
	// Only visualize actor based blueprints
	if (Blueprint && Blueprint->GeneratedClass && Blueprint->GeneratedClass->IsChildOf(AActor::StaticClass()))
	{
		// Try to find any visible primitive components in the native class' CDO
		AActor* CDO = Blueprint->GeneratedClass->GetDefaultObject<AActor>();

		TInlineComponentArray<UActorComponent*> Components;
		CDO->GetComponents(Components);

		for (auto CompIt = Components.CreateConstIterator(); CompIt; ++CompIt)
		{
			if (ThumbnailScene->IsValidComponentForVisualization(*CompIt))
			{
				return true;
			}
		}

		// Try to find any visible primitive components in the simple construction script
		// Do this for all parent blueprint generated classes as well
		UBlueprint* BlueprintToHarvestComponents = Blueprint;
		TSet<UBlueprint*> AllVisitedBlueprints;
		while (BlueprintToHarvestComponents)
		{
			AllVisitedBlueprints.Add(BlueprintToHarvestComponents);

			if (BlueprintToHarvestComponents->SimpleConstructionScript)
			{
				for (USCS_Node* Node : BlueprintToHarvestComponents->SimpleConstructionScript->GetAllNodes())
				{
					if (ThumbnailScene->IsValidComponentForVisualization(Node->ComponentTemplate))
					{
						return true;
					}
				}
			}

			UClass* ParentClass = BlueprintToHarvestComponents->ParentClass;
			BlueprintToHarvestComponents = nullptr;

			// If the parent class was a blueprint generated class, check it's simple construction script components as well
			if (ParentClass)
			{
				UBlueprint* ParentBlueprint = Cast<UBlueprint>(ParentClass->ClassGeneratedBy);

				// Also make sure we haven't visited the blueprint already. This would only happen if there was a loop of parent classes.
				if (ParentBlueprint && !AllVisitedBlueprints.Contains(ParentBlueprint))
				{
					BlueprintToHarvestComponents = ParentBlueprint;
				}
			}
		}
	}
	return false;
}

void UBSNBlueprintThumbnailRenderer::DrawNormal(UBlueprint* Blueprint, int32 X, int32 Y, uint32 Width, uint32 Height, FRenderTarget*RenderTarget, FCanvas* Canvas)
{
	if (Blueprint != nullptr)
	{
		if (ThumbnailScene == nullptr)
		{
			ThumbnailScene = new FBNSBlueprintThumbnailScene();
		}

		ThumbnailScene->SetBlueprint(Blueprint);
		FSceneViewFamilyContext ViewFamily(FSceneViewFamily::ConstructionValues(RenderTarget, ThumbnailScene->GetScene(), FEngineShowFlags(ESFIM_Game))
			.SetWorldTimes(FApp::GetCurrentTime() - GStartTime, FApp::GetDeltaTime(), FApp::GetCurrentTime() - GStartTime));

		ViewFamily.EngineShowFlags.DisableAdvancedFeatures();
		ViewFamily.EngineShowFlags.MotionBlur = 0;

		ThumbnailScene->GetView(&ViewFamily, X, Y, Width, Height);
		GetRendererModule().BeginRenderingViewFamily(Canvas, &ViewFamily);
	}
}


