
#pragma once

#define BSNEDITOR_MODULE_NAME "BSNEditor"

class IBNSEditorModuleInterface : public IModuleInterface
{
};

