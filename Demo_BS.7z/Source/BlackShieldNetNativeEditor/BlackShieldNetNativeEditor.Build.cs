// Fill out your copyright notice in the Description page of Project Settings.

using UnrealBuildTool;
using System.Collections.Generic;

namespace UnrealBuildTool.Rules
{
    public class BlackShieldNetNativeEditor : ModuleRules
    {
        public BlackShieldNetNativeEditor(TargetInfo Target)
        {
            PublicIncludePaths.AddRange(
                new string[] {
                "BlackShieldNetNativeEditor/Public"
                });

            PrivateIncludePaths.Add("BlackShieldNetNativeEditor/Private");

            PrivateDependencyModuleNames.AddRange(
                new string[] {
                "Core",
                "CoreUObject",
                "Engine",
                "UnrealEd",
                "BlackShieldNetNative"
                }
                );

            PrivateDependencyModuleNames.Add("UnrealEd");
        }
    }
}
